
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/administrative" | "/administrative/settings" | "/api" | "/api/administrative" | "/api/administrative/applications" | "/api/apply" | "/api/auth" | "/api/auth/google" | "/api/auth/login" | "/api/auth/logout" | "/api/auth/register" | "/api/auth/settings" | "/api/auth/verify" | "/api/change-information" | "/api/change-information/request" | "/api/change-vehicle" | "/api/change-vehicle/approve" | "/api/change-vehicle/request" | "/api/complaints" | "/api/complaints/[id]" | "/api/deans" | "/api/dean" | "/api/dean/applications" | "/api/departments" | "/api/departments/admin" | "/api/gate" | "/api/gate/entry" | "/api/gate/exit" | "/api/gate/logs" | "/api/gate/lookup-plate" | "/api/gate/lookup" | "/api/gate/manual" | "/api/gate/parking" | "/api/gate/stats" | "/api/gate/vip" | "/api/monitor" | "/api/monitor/actions" | "/api/monitor/revoke" | "/api/notifications" | "/api/notifications/create" | "/api/notifications/mark-all-read" | "/api/notifications/[notificationId]" | "/api/notifications/[notificationId]/read" | "/api/osa" | "/api/osa/admin" | "/api/osa/application-form" | "/api/osa/applications" | "/api/osa/bulk-actions" | "/api/qr" | "/api/receipt" | "/api/security" | "/api/security/capacity" | "/api/security/complaints" | "/api/security/complaints/[id]" | "/api/settings" | "/api/settings/gate-filter" | "/api/settings/registration" | "/complaints" | "/dean" | "/dean/settings" | "/entry" | "/login" | "/monitor" | "/osa" | "/osa/admin" | "/osa/admin/manage" | "/osa/change-requests" | "/osa/dashboard" | "/osa/deans" | "/osa/departments" | "/osa/settings" | "/otp" | "/security" | "/security/capacity" | "/security/complaints" | "/security/dashboard" | "/security/logs" | "/security/settings" | "/status";
		RouteParams(): {
			"/api/complaints/[id]": { id: string };
			"/api/notifications/[notificationId]": { notificationId: string };
			"/api/notifications/[notificationId]/read": { notificationId: string };
			"/api/security/complaints/[id]": { id: string }
		};
		LayoutParams(): {
			"/": { id?: string | undefined; notificationId?: string | undefined };
			"/administrative": Record<string, never>;
			"/administrative/settings": Record<string, never>;
			"/api": { id?: string | undefined; notificationId?: string | undefined };
			"/api/administrative": Record<string, never>;
			"/api/administrative/applications": Record<string, never>;
			"/api/apply": Record<string, never>;
			"/api/auth": Record<string, never>;
			"/api/auth/google": Record<string, never>;
			"/api/auth/login": Record<string, never>;
			"/api/auth/logout": Record<string, never>;
			"/api/auth/register": Record<string, never>;
			"/api/auth/settings": Record<string, never>;
			"/api/auth/verify": Record<string, never>;
			"/api/change-information": Record<string, never>;
			"/api/change-information/request": Record<string, never>;
			"/api/change-vehicle": Record<string, never>;
			"/api/change-vehicle/approve": Record<string, never>;
			"/api/change-vehicle/request": Record<string, never>;
			"/api/complaints": { id?: string | undefined };
			"/api/complaints/[id]": { id: string };
			"/api/deans": Record<string, never>;
			"/api/dean": Record<string, never>;
			"/api/dean/applications": Record<string, never>;
			"/api/departments": Record<string, never>;
			"/api/departments/admin": Record<string, never>;
			"/api/gate": Record<string, never>;
			"/api/gate/entry": Record<string, never>;
			"/api/gate/exit": Record<string, never>;
			"/api/gate/logs": Record<string, never>;
			"/api/gate/lookup-plate": Record<string, never>;
			"/api/gate/lookup": Record<string, never>;
			"/api/gate/manual": Record<string, never>;
			"/api/gate/parking": Record<string, never>;
			"/api/gate/stats": Record<string, never>;
			"/api/gate/vip": Record<string, never>;
			"/api/monitor": Record<string, never>;
			"/api/monitor/actions": Record<string, never>;
			"/api/monitor/revoke": Record<string, never>;
			"/api/notifications": { notificationId?: string | undefined };
			"/api/notifications/create": Record<string, never>;
			"/api/notifications/mark-all-read": Record<string, never>;
			"/api/notifications/[notificationId]": { notificationId: string };
			"/api/notifications/[notificationId]/read": { notificationId: string };
			"/api/osa": Record<string, never>;
			"/api/osa/admin": Record<string, never>;
			"/api/osa/application-form": Record<string, never>;
			"/api/osa/applications": Record<string, never>;
			"/api/osa/bulk-actions": Record<string, never>;
			"/api/qr": Record<string, never>;
			"/api/receipt": Record<string, never>;
			"/api/security": { id?: string | undefined };
			"/api/security/capacity": Record<string, never>;
			"/api/security/complaints": { id?: string | undefined };
			"/api/security/complaints/[id]": { id: string };
			"/api/settings": Record<string, never>;
			"/api/settings/gate-filter": Record<string, never>;
			"/api/settings/registration": Record<string, never>;
			"/complaints": Record<string, never>;
			"/dean": Record<string, never>;
			"/dean/settings": Record<string, never>;
			"/entry": Record<string, never>;
			"/login": Record<string, never>;
			"/monitor": Record<string, never>;
			"/osa": Record<string, never>;
			"/osa/admin": Record<string, never>;
			"/osa/admin/manage": Record<string, never>;
			"/osa/change-requests": Record<string, never>;
			"/osa/dashboard": Record<string, never>;
			"/osa/deans": Record<string, never>;
			"/osa/departments": Record<string, never>;
			"/osa/settings": Record<string, never>;
			"/otp": Record<string, never>;
			"/security": Record<string, never>;
			"/security/capacity": Record<string, never>;
			"/security/complaints": Record<string, never>;
			"/security/dashboard": Record<string, never>;
			"/security/logs": Record<string, never>;
			"/security/settings": Record<string, never>;
			"/status": Record<string, never>
		};
		Pathname(): "/" | "/administrative" | "/administrative/settings" | "/api/administrative/applications" | "/api/apply" | "/api/auth/google" | "/api/auth/login" | "/api/auth/logout" | "/api/auth/register" | "/api/auth/settings" | "/api/auth/verify" | "/api/change-information/request" | "/api/change-vehicle/approve" | "/api/change-vehicle/request" | "/api/complaints" | `/api/complaints/${string}` & {} | "/api/deans" | "/api/dean/applications" | "/api/departments" | "/api/departments/admin" | "/api/gate/entry" | "/api/gate/exit" | "/api/gate/logs" | "/api/gate/lookup-plate" | "/api/gate/lookup" | "/api/gate/manual" | "/api/gate/parking" | "/api/gate/stats" | "/api/gate/vip" | "/api/monitor/actions" | "/api/monitor/revoke" | "/api/notifications" | "/api/notifications/create" | "/api/notifications/mark-all-read" | `/api/notifications/${string}/read` & {} | "/api/osa/admin" | "/api/osa/application-form" | "/api/osa/applications" | "/api/osa/bulk-actions" | "/api/qr" | "/api/receipt" | "/api/security/capacity" | "/api/security/complaints" | `/api/security/complaints/${string}` & {} | "/api/settings" | "/api/settings/gate-filter" | "/api/settings/registration" | "/complaints" | "/dean" | "/dean/settings" | "/entry" | "/login" | "/monitor" | "/osa" | "/osa/admin" | "/osa/admin/manage" | "/osa/change-requests" | "/osa/dashboard" | "/osa/deans" | "/osa/departments" | "/osa/settings" | "/otp" | "/security" | "/security/capacity" | "/security/complaints" | "/security/dashboard" | "/security/logs" | "/security/settings" | "/status";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/liceo-logo.png" | "/robots.txt" | "/rodelsa-image.png" | string & {};
	}
}