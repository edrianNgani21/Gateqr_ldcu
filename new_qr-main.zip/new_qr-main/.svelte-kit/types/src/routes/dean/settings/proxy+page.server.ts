// @ts-nocheck
import { redirect } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';
import { supabase } from '$lib/server/supabase';

export const load = async ({ locals }: Parameters<PageServerLoad>[0]) => {
    if (!locals.user || (locals.user.role !== 'dean' && locals.user.role !== 'administrative')) {
        throw redirect(303, '/login');
    }

    const { data: userRow } = await supabase
        .from('users')
        .select(`
            user_id, 
            email, 
            user_type, 
            identification, 
            is_active, 
            created_at, 
            security_pin_hash,
            department_id,
            department:department_id(*)
        `)
        .eq('user_id', locals.user.user_id)
        .single();

    let departmentName = '';
    if (userRow?.department) {
        const d = userRow.department as any;
        departmentName = d.academic_department || d.administrative_department || d.department_name || d.department || '';
    }

    return {
        userEmail: locals.user.email,
        userRole: 'dean',
        adminUser: {
            user_id: userRow?.user_id || locals.user.user_id,
            email: userRow?.email || locals.user.email,
            user_type: 'Academic Department Head',
            identification: userRow?.identification || 'Faculty',
            department_name: departmentName,
            created_at: userRow?.created_at || null,
            is_active: userRow?.is_active ?? true,
            has_pin: !!userRow?.security_pin_hash
        }
    };
};
