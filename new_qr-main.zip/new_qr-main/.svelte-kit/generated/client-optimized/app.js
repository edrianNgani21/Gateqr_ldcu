// in dev, this makes Vite inject its client as this module's first dependency,
// so that global constant replacements are installed before any other module
// (including user hooks) evaluates. In build it's inert.
import.meta.hot;




export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22'),
	() => import('./nodes/23'),
	() => import('./nodes/24'),
	() => import('./nodes/25'),
	() => import('./nodes/26'),
	() => import('./nodes/27')
];

export const server_loads = [];

export const dictionary = {
		"/": [~3],
		"/administrative": [~4],
		"/administrative/settings": [~5],
		"/complaints": [~6],
		"/dean": [~7],
		"/dean/settings": [~8],
		"/entry": [9],
		"/login": [10],
		"/monitor": [~11],
		"/osa": [~12,[2]],
		"/osa/admin": [~13,[2]],
		"/osa/admin/manage": [~14,[2]],
		"/osa/change-requests": [~15,[2]],
		"/osa/dashboard": [~16,[2]],
		"/osa/deans": [~17,[2]],
		"/osa/departments": [~18,[2]],
		"/osa/settings": [~19,[2]],
		"/otp": [20],
		"/security": [~21],
		"/security/capacity": [~22],
		"/security/complaints": [~23],
		"/security/dashboard": [~24],
		"/security/logs": [~25],
		"/security/settings": [~26],
		"/status": [~27]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));
export const encoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.encode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';

export const get_error_template = () => import('../shared/error-template.js').then(m => m.default);