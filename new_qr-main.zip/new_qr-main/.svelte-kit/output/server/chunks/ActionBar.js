import { C as attr, r as derived, t as attr_class } from "./server.js";
//#region src/lib/components/ActionBar.svelte
function ActionBar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { tab, status = "", expiresAt = null, onaction } = $$props;
		let isExpired = derived(() => expiresAt ? new Date(expiresAt) < /* @__PURE__ */ new Date() : false);
		$$renderer.push(`<div class="action-bar svelte-q6aptv">`);
		if (tab === "validation") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button${attr_class("action-btn btn-reject svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg> Reject`);
			$$renderer.push(`<!--]--></button> <button${attr_class("action-btn btn-accept svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg> Accept`);
			$$renderer.push(`<!--]--></button>`);
		} else if (tab === "distribution" || tab === "overdue") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<button${attr_class("action-btn btn-deliver svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Verify Hardcopy`);
			$$renderer.push(`<!--]--></button> <button${attr_class("action-btn btn-reschedule svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Reschedule`);
			$$renderer.push(`<!--]--></button>`);
		} else if (tab === "Document Review") {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<button${attr_class("action-btn btn-deliver svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"></path></svg> Checked`);
			$$renderer.push(`<!--]--></button>`);
		} else if (tab === "Sticker Installation") {
			$$renderer.push("<!--[3-->");
			$$renderer.push(`<button${attr_class("action-btn btn-deliver svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Done Installed`);
			$$renderer.push(`<!--]--></button> <button${attr_class("action-btn btn-reschedule svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Reschedule`);
			$$renderer.push(`<!--]--></button>`);
		} else if (tab === "release") {
			$$renderer.push("<!--[4-->");
			$$renderer.push(`<button${attr_class("action-btn btn-deliver svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"></path></svg> Sticker Released`);
			$$renderer.push(`<!--]--></button>`);
		} else if (tab.toLowerCase().includes("register")) {
			$$renderer.push("<!--[5-->");
			$$renderer.push(`<button${attr_class("action-btn btn-revoke svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg> Revoke Access`);
			$$renderer.push(`<!--]--></button> <button${attr_class("action-btn btn-delete svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg> Delete`);
			$$renderer.push(`<!--]--></button>`);
		} else if (tab.toLowerCase().includes("reject") || tab.toLowerCase().includes("revoke")) {
			$$renderer.push("<!--[6-->");
			if (status === "revoked") {
				$$renderer.push("<!--[0-->");
				if (!isExpired()) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button${attr_class("action-btn btn-unrevoke svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path></svg> Unrevoke`);
					$$renderer.push(`<!--]--></button>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else if (status === "rejected") {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<button${attr_class("action-btn btn-revoke svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path></svg> Reconsider Application`);
				$$renderer.push(`<!--]--></button>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<button${attr_class("action-btn btn-revoke svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path></svg> Retract Approval`);
				$$renderer.push(`<!--]--></button>`);
			}
			$$renderer.push(`<!--]--> <button${attr_class("action-btn btn-delete svelte-q6aptv", void 0, { "btn-loading": false })}${attr("disabled", false, true)}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg> Delete`);
			$$renderer.push(`<!--]--></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
	});
}
//#endregion
export { ActionBar as t };
