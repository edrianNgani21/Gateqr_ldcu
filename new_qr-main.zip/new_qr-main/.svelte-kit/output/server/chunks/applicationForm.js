import { t as supabase } from "./supabase.js";
//#region src/lib/server/applicationForm.ts
/** Returns whether applicants may currently access/submit the application form. Defaults to open. */
async function isApplicationFormOpen() {
	try {
		return (await getApplicationFormStatus()).open;
	} catch {
		return true;
	}
}
/** Gets the detailed application form status including who updated it last. */
async function getApplicationFormStatus() {
	try {
		const { data, error } = await supabase.from("form_settings").select("*").order("application_form_settings_id", { ascending: false }).limit(1).maybeSingle();
		if (error || !data) return { open: true };
		if (data.status !== void 0 && data.status !== null) return {
			open: (data.status || "").toLowerCase() !== "closed",
			updatedByEmail: data.updated_by || null,
			updatedAt: data.updated_at || null
		};
		if (data.value !== void 0 && data.value !== null) return {
			open: data.value !== "false",
			updatedByEmail: data.updated_by_email || data.updated_by || null,
			updatedAt: data.updated_at || null
		};
		return { open: true };
	} catch {
		return { open: true };
	}
}
/** Opens or closes the application form, recording the user ID and email of the admin who performed the change. */
async function setApplicationFormOpen(open, userId, userEmail) {
	const updatedAt = (/* @__PURE__ */ new Date()).toISOString();
	const statusVal = open ? "open" : "closed";
	const emailVal = userEmail || "System";
	const { data: existing, error: fetchErr } = await supabase.from("form_settings").select("*").limit(1).maybeSingle();
	if (fetchErr) console.error("[ApplicationForm] fetch error:", fetchErr);
	if (existing && existing.application_form_settings_id !== void 0) {
		const { error: updateErr } = await supabase.from("form_settings").update({
			status: statusVal,
			updated_by: emailVal,
			updated_at: updatedAt,
			user_id: userId || null
		}).eq("application_form_settings_id", existing.application_form_settings_id);
		if (updateErr) {
			console.error("[ApplicationForm] update error:", updateErr);
			throw updateErr;
		}
	} else if (existing && existing.key !== void 0) {
		const { error: upsertErr } = await supabase.from("form_settings").upsert({
			key: "application_form_open",
			value: open ? "true" : "false",
			updated_by: userId,
			updated_by_email: emailVal,
			updated_at: updatedAt
		}, { onConflict: "key" });
		if (upsertErr) throw upsertErr;
	} else {
		const { error: insertErr } = await supabase.from("form_settings").insert({
			status: statusVal,
			updated_by: emailVal,
			updated_at: updatedAt,
			user_id: userId || null
		});
		if (insertErr) {
			const { error: fallbackErr } = await supabase.from("form_settings").insert({
				key: "application_form_open",
				value: open ? "true" : "false",
				updated_by: userId,
				updated_by_email: emailVal,
				updated_at: updatedAt
			});
			if (fallbackErr) throw fallbackErr;
		}
	}
	return {
		open,
		updatedByEmail: emailVal,
		updatedAt
	};
}
//#endregion
export { isApplicationFormOpen as n, setApplicationFormOpen as r, getApplicationFormStatus as t };
