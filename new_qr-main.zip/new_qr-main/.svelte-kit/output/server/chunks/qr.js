import { createCanvas, loadImage } from "@napi-rs/canvas";
import QRCode from "qrcode";
import { join } from "path";
import fs from "fs";
//#region src/lib/server/qr.ts
var cachedCleanLogoCanvas = null;
async function getCleanLogoCanvas() {
	if (cachedCleanLogoCanvas) return cachedCleanLogoCanvas;
	const logoPath = join(process.cwd(), "static", "liceo-logo.png");
	if (!fs.existsSync(logoPath)) return null;
	try {
		const rawLogo = await loadImage(logoPath);
		const w = rawLogo.width;
		const h = rawLogo.height;
		const logoCanvas = createCanvas(w, h);
		const lCtx = logoCanvas.getContext("2d");
		lCtx.drawImage(rawLogo, 0, 0);
		const imgData = lCtx.getImageData(0, 0, w, h);
		const data = imgData.data;
		const visited = new Uint8Array(w * h);
		const queue = [
			[0, 0],
			[w - 1, 0],
			[0, h - 1],
			[w - 1, h - 1]
		];
		for (const [qx, qy] of queue) visited[qy * w + qx] = 1;
		while (queue.length > 0) {
			const [x, y] = queue.pop();
			const idx = (y * w + x) * 4;
			if (data[idx] > 235 && data[idx + 1] > 235 && data[idx + 2] > 235) {
				data[idx + 3] = 0;
				const neighbors = [
					[x + 1, y],
					[x - 1, y],
					[x, y + 1],
					[x, y - 1]
				];
				for (const [nx, ny] of neighbors) if (nx >= 0 && nx < w && ny >= 0 && ny < h && !visited[ny * w + nx]) {
					visited[ny * w + nx] = 1;
					queue.push([nx, ny]);
				}
			}
		}
		lCtx.putImageData(imgData, 0, 0);
		cachedCleanLogoCanvas = logoCanvas;
		return cachedCleanLogoCanvas;
	} catch (err) {
		console.error("[QR] Failed to prepare clean logo:", err);
		return null;
	}
}
async function generateStyledQRBuffer(qrData, role = "student") {
	const qrSize = 400;
	const borderPadding = 20;
	const totalSize = 440;
	const qrDataUrl = await QRCode.toDataURL(qrData, {
		errorCorrectionLevel: "H",
		margin: 2,
		width: qrSize,
		color: {
			dark: "#000000",
			light: "#ffffff"
		}
	});
	const canvas = createCanvas(totalSize, totalSize);
	const ctx = canvas.getContext("2d");
	const normalizedRole = (role || "student").trim().toLowerCase();
	let borderColor = "#16a34a";
	if ([
		"faculty",
		"staff",
		"employee"
	].includes(normalizedRole)) borderColor = "#E5E0D8";
	else if ([
		"concessionaire",
		"concessionnaire",
		"supplier"
	].includes(normalizedRole)) borderColor = "#f97316";
	else if ([
		"administrator",
		"administrators",
		"admin",
		"osa"
	].includes(normalizedRole)) borderColor = "#dc2626";
	else if ([
		"vps",
		"vp",
		"vip"
	].includes(normalizedRole)) borderColor = "#d4af37";
	else if (normalizedRole === "visitor") borderColor = "#2563eb";
	else if (normalizedRole === "guest") borderColor = "#6b7280";
	ctx.fillStyle = borderColor;
	ctx.fillRect(0, 0, totalSize, totalSize);
	if (borderColor === "#E5E0D8" || borderColor === "#ffffff") {
		ctx.strokeStyle = "#c4beb5";
		ctx.lineWidth = 2;
		ctx.strokeRect(1, 1, 438, 438);
	}
	const qrImage = await loadImage(qrDataUrl);
	ctx.drawImage(qrImage, borderPadding, borderPadding, qrSize, qrSize);
	const cleanLogo = await getCleanLogoCanvas();
	if (cleanLogo) {
		const logoDrawSize = 90;
		const centerX = totalSize / 2;
		const centerY = totalSize / 2;
		ctx.save();
		ctx.drawImage(cleanLogo, centerX - logoDrawSize / 2, centerY - logoDrawSize / 2, logoDrawSize, logoDrawSize);
		ctx.restore();
	}
	return canvas.toBuffer("image/png");
}
//#endregion
export { generateStyledQRBuffer as t };
