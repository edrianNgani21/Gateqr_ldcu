//#region src/lib/server/capacityCache.ts
var cachedCapacity = null;
function getCachedCapacity() {
	if (cachedCapacity && Date.now() - cachedCapacity.timestamp < 5e3) return cachedCapacity.campuses;
	return null;
}
function setCachedCapacity(campuses) {
	cachedCapacity = {
		campuses,
		timestamp: Date.now()
	};
}
function invalidateCapacityServerCache() {
	cachedCapacity = null;
}
//#endregion
export { invalidateCapacityServerCache as n, setCachedCapacity as r, getCachedCapacity as t };
