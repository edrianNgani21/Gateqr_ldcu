import { C as attr, i as ensure_array_like, l as unsubscribe_stores, s as store_get, t as attr_class, w as escape_html } from "./server.js";
import { t as page } from "./stores.js";
//#region src/lib/components/NavBar.svelte
function NavBar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { title, links = [] } = $$props;
		$$renderer.push(`<div class="navbar svelte-q971rm"><h1 class="navbar-title svelte-q971rm">${escape_html(title)}</h1> `);
		if (links.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<nav class="navbar-links svelte-q971rm"><!--[-->`);
			const each_array = ensure_array_like(links);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let link = each_array[$$index];
				$$renderer.push(`<a${attr("href", link.href)}${attr_class("nav-link svelte-q971rm", void 0, { "active": store_get($$store_subs ??= {}, "$page", page).url.pathname === link.href })}>${escape_html(link.label)} `);
				if (link.badge) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge svelte-q971rm">${escape_html(link.badge > 99 ? "99+" : link.badge)}</span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></a>`);
			}
			$$renderer.push(`<!--]--></nav>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
export { NavBar as t };
