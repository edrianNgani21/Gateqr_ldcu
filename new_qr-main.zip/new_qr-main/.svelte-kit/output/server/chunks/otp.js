//#region src/lib/server/otp.ts
var otpStore = /* @__PURE__ */ new Map();
var OTP_TTL_MS = 3e5;
var MAX_ATTEMPTS = 5;
setInterval(() => {
	const now = Date.now();
	for (const [email, entry] of otpStore.entries()) if (now > entry.expiresAt) otpStore.delete(email);
}, 12e4);
/**
* Generate and store a secure 6-digit OTP for the given email
*/
function generateOtp(email) {
	const normalized = email.trim().toLowerCase();
	const code = Math.floor(1e5 + Math.random() * 9e5).toString();
	const expiresAt = Date.now() + OTP_TTL_MS;
	otpStore.set(normalized, {
		code,
		expiresAt,
		attempts: 0
	});
	console.log(`[OTP] Generated 6-digit code for ${normalized} (Expires in 5 mins). Code: ${code}`);
	return code;
}
/**
* Verify applicant OTP
*/
function verifyOtp(email, candidate) {
	const normalized = email.trim().toLowerCase();
	const cleanCode = (candidate || "").trim();
	const entry = otpStore.get(normalized);
	if (!entry) return {
		valid: false,
		reason: "No OTP requested or code has expired. Please request a new code."
	};
	if (Date.now() > entry.expiresAt) {
		otpStore.delete(normalized);
		return {
			valid: false,
			reason: "This verification code has expired. Please request a new code."
		};
	}
	if (entry.attempts >= MAX_ATTEMPTS) {
		otpStore.delete(normalized);
		return {
			valid: false,
			reason: "Too many incorrect attempts. Please request a new verification code."
		};
	}
	if (entry.code !== cleanCode) {
		entry.attempts += 1;
		const remaining = MAX_ATTEMPTS - entry.attempts;
		return {
			valid: false,
			reason: `Incorrect code. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`
		};
	}
	otpStore.delete(normalized);
	return { valid: true };
}
//#endregion
export { verifyOtp as n, generateOtp as t };
