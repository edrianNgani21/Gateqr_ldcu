import { C as attr, a as head, r as derived, w as escape_html } from "./server.js";
import { t as AppShell } from "./AppShell.js";
import "./navigation.js";
import { t as NavBar } from "./NavBar.js";
//#region src/lib/components/AdminSettingsView.svelte
function AdminSettingsView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data, userRole = "osa", showSidebar = true, pageTitle = "Settings", roleLabel = "" } = $$props;
		let admin = derived(() => data.adminUser);
		let currentPinForPassword = "";
		let newPassword = "";
		let confirmPassword = "";
		let passwordLoading = false;
		let currentPin = "";
		let newPin = "";
		let confirmPin = "";
		let pinLoading = false;
		let testPin = "";
		let testPinLoading = false;
		function formatDate(dateStr) {
			if (!dateStr) return "Not Available";
			return new Date(dateStr).toLocaleDateString("en-US", {
				year: "numeric",
				month: "long",
				day: "numeric",
				hour: "2-digit",
				minute: "2-digit",
				hour12: true
			});
		}
		let displayRoleName = derived(() => {
			if (roleLabel) return roleLabel;
			const ut = (admin().user_type || "").toLowerCase();
			if (ut === "osa") return "Office of Student Affairs (OSA)";
			if (ut.includes("security") || ut === "safety_security") return "Security Administrator";
			if (userRole === "dean") return "Academic Department Head";
			if (userRole === "administrative") return "Administrative Department Head";
			return admin().user_type || "Administrator";
		});
		head("1i2j74f", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>${escape_html(pageTitle)} — Administrator Account | GateQR</title>`);
			});
		});
		AppShell($$renderer, {
			userEmail: data.userEmail,
			showSidebar,
			userRole,
			children: ($$renderer) => {
				NavBar($$renderer, { title: pageTitle });
				$$renderer.push(`<!----> <div class="settings-page-wrapper svelte-1i2j74f"><section class="admin-account-card svelte-1i2j74f"><div class="card-top-header svelte-1i2j74f"><div class="header-icon-box svelte-1i2j74f"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><circle cx="12" cy="11" r="3"></circle></svg></div> <div class="header-titles svelte-1i2j74f"><h2 class="svelte-1i2j74f">Administrator Account</h2> <p class="svelte-1i2j74f">Current authorized administrator profile and database record</p></div> <span class="status-pill active svelte-1i2j74f"><span class="status-dot svelte-1i2j74f"></span> Active Session</span></div> <div class="admin-info-grid svelte-1i2j74f"><div class="info-field svelte-1i2j74f"><span class="field-label svelte-1i2j74f">Admin Email</span> <div class="field-value email-value svelte-1i2j74f"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg> <span>${escape_html(admin().email)}</span></div></div> <div class="info-field svelte-1i2j74f"><span class="field-label svelte-1i2j74f">Assigned Role</span> <div class="field-value svelte-1i2j74f"><span class="badge-role svelte-1i2j74f"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"></circle><path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"></path></svg> ${escape_html(displayRoleName())}</span></div></div> `);
				if (admin().department_name) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="info-field svelte-1i2j74f"><span class="field-label svelte-1i2j74f">Department</span> <div class="field-value svelte-1i2j74f"><span class="badge-dept svelte-1i2j74f"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg> ${escape_html(admin().department_name)}</span></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="info-field svelte-1i2j74f"><span class="field-label svelte-1i2j74f">Identification Classification</span> <div class="field-value svelte-1i2j74f"><span class="badge-id svelte-1i2j74f">${escape_html(admin().identification || "Administrator")}</span></div></div> <div class="info-field svelte-1i2j74f"><span class="field-label svelte-1i2j74f">Account Created At</span> <div class="field-value date-value svelte-1i2j74f"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> <span>${escape_html(formatDate(admin().created_at))}</span></div></div> <div class="info-field svelte-1i2j74f"><span class="field-label svelte-1i2j74f">4-Digit Security PIN</span> <div class="field-value svelte-1i2j74f">`);
				if (admin().has_pin) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge-pin-active svelte-1i2j74f">✓ PIN Configured</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span class="badge-pin-warning svelte-1i2j74f">⚠ PIN Not Configured</span>`);
				}
				$$renderer.push(`<!--]--></div></div></div></section> <div class="scroll-divider svelte-1i2j74f"><span class="scroll-line svelte-1i2j74f"></span> <span class="scroll-label svelte-1i2j74f"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg> Security Credentials Management</span> <span class="scroll-line svelte-1i2j74f"></span></div> <div class="security-grid svelte-1i2j74f"><div class="security-column-card left-card svelte-1i2j74f"><div class="col-header svelte-1i2j74f"><div class="col-icon left-icon svelte-1i2j74f"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></div> <div><h3 class="svelte-1i2j74f">Change Password</h3> <p class="svelte-1i2j74f">Authorize with your 4-digit security PIN to update account password</p></div></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <form class="form-body svelte-1i2j74f"><div class="form-group svelte-1i2j74f"><label for="pwd-pin" class="svelte-1i2j74f">4-Digit Security PIN <span class="required svelte-1i2j74f">*</span></label> <input id="pwd-pin" type="password" maxlength="4" inputmode="numeric" placeholder="••••"${attr("value", currentPinForPassword)} required="" class="input-field pin-masked svelte-1i2j74f"/> <span class="hint-text svelte-1i2j74f">Your security PIN is required to authorize password modifications</span></div> <div class="form-group svelte-1i2j74f"><label for="new-pwd" class="svelte-1i2j74f">New Password <span class="required svelte-1i2j74f">*</span></label> <div class="input-with-toggle svelte-1i2j74f"><input id="new-pwd"${attr("type", "password")} placeholder="Enter at least 6 characters"${attr("value", newPassword)} required="" class="input-field svelte-1i2j74f"/> <button type="button" class="eye-toggle svelte-1i2j74f" title="Toggle Visibility">`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`);
				$$renderer.push(`<!--]--></button></div></div> <div class="form-group svelte-1i2j74f"><label for="confirm-pwd" class="svelte-1i2j74f">Confirm New Password <span class="required svelte-1i2j74f">*</span></label> <div class="input-with-toggle svelte-1i2j74f"><input id="confirm-pwd"${attr("type", "password")} placeholder="Confirm your new password"${attr("value", confirmPassword)} required="" class="input-field svelte-1i2j74f"/> <button type="button" class="eye-toggle svelte-1i2j74f" title="Toggle Visibility">`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`);
				$$renderer.push(`<!--]--></button></div></div> <button type="submit" class="submit-btn maroon-btn svelte-1i2j74f"${attr("disabled", passwordLoading, true)}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg> Save New Password`);
				$$renderer.push(`<!--]--></button></form></div> <div class="security-column-card right-card svelte-1i2j74f"><div class="col-header svelte-1i2j74f"><div class="col-icon right-icon svelte-1i2j74f"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg></div> <div><h3 class="svelte-1i2j74f">4-Digit Security PIN</h3> <p class="svelte-1i2j74f">${escape_html(admin().has_pin ? "Update or manage your 4-digit administrative verification PIN" : "Configure a 4-digit security PIN for authorized approvals")}</p></div></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <form class="form-body svelte-1i2j74f">`);
				if (admin().has_pin) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="form-group svelte-1i2j74f"><label for="cur-pin" class="svelte-1i2j74f">Current 4-Digit PIN <span class="required svelte-1i2j74f">*</span></label> <input id="cur-pin" type="password" maxlength="4" inputmode="numeric" placeholder="••••"${attr("value", currentPin)} required="" class="input-field pin-masked svelte-1i2j74f"/></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="form-group svelte-1i2j74f"><label for="new-pin" class="svelte-1i2j74f">${escape_html(admin().has_pin ? "New 4-Digit PIN" : "Set 4-Digit PIN")} <span class="required svelte-1i2j74f">*</span></label> <input id="new-pin" type="password" maxlength="4" inputmode="numeric" placeholder="••••"${attr("value", newPin)} required="" class="input-field pin-masked svelte-1i2j74f"/> <span class="hint-text svelte-1i2j74f">Must be exactly 4 digits (e.g. 1234)</span></div> <div class="form-group svelte-1i2j74f"><label for="confirm-pin" class="svelte-1i2j74f">Confirm 4-Digit PIN <span class="required svelte-1i2j74f">*</span></label> <input id="confirm-pin" type="password" maxlength="4" inputmode="numeric" placeholder="••••"${attr("value", confirmPin)} required="" class="input-field pin-masked svelte-1i2j74f"/></div> <button type="submit" class="submit-btn gold-btn svelte-1i2j74f"${attr("disabled", pinLoading, true)}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>${escape_html(admin().has_pin ? "Update Security PIN" : "Save 4-Digit PIN")}`);
				$$renderer.push(`<!--]--></button></form> `);
				if (admin().has_pin) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="pin-tester-section svelte-1i2j74f"><h4 class="svelte-1i2j74f">Test &amp; Verify PIN</h4> <div class="tester-input-row svelte-1i2j74f"><input type="password" maxlength="4" inputmode="numeric" placeholder="Verify PIN..."${attr("value", testPin)} class="input-field tester-input svelte-1i2j74f"/> <button type="button" class="tester-btn svelte-1i2j74f"${attr("disabled", testPinLoading, true)}>${escape_html("Verify")}</button></div> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { AdminSettingsView as t };
