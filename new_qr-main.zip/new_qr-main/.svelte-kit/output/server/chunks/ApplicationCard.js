import { C as attr, c as stringify, i as ensure_array_like, n as attr_style, r as derived, t as attr_class, w as escape_html } from "./server.js";
//#region src/lib/components/StatusBadge.svelte
function StatusBadge($$renderer, $$props) {
	let { code, date, variant = "default" } = $$props;
	if (date) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`status-badge badge-${stringify(variant)}`, "svelte-12nqn7t")}><span class="badge-code svelte-12nqn7t">${escape_html(code)}</span> <span class="badge-date svelte-12nqn7t">${escape_html(date)}</span></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]-->`);
}
//#endregion
//#region src/lib/components/DocumentGrid.svelte
function DocumentGrid($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { role, owner, clickable = true, documents = {}, onopen } = $$props;
		const ltoFull = derived(() => !(role === "visitor" && owner === "yes"));
		function isValidDoc(url) {
			if (!url || typeof url !== "string") return false;
			const t = url.trim().toLowerCase();
			if ([
				"pending_or",
				"pending_cr",
				"pending_license",
				"pending_enrollment",
				"n/a",
				"pending",
				"null",
				"undefined",
				"not specified",
				"-",
				""
			].includes(t)) return false;
			if (/^\d{4}-\d+$/.test(t) || /^\d+$/.test(t)) return false;
			return t.startsWith("http://") || t.startsWith("https://") || t.startsWith("data:") || t.startsWith("/");
		}
		$$renderer.push(`<div class="doc-section svelte-nss7d3">`);
		if (role !== "visitor" && role !== "concessionaire") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="doc-grid svelte-nss7d3"${attr_style(`--cols: ${stringify(owner === "no" ? 3 : 2)}`)}><button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.id) })}${attr("disabled", !clickable || !isValidDoc(documents.id), true)}${attr("title", isValidDoc(documents.id) ? "View ID Document" : "ID Document Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><rect x="3" y="3" width="18" height="18" rx="2"></rect><path d="M9 9h6M9 13h6M9 17h4"></path></svg> <span>(Liceo) ${escape_html(role === "student" ? "Student ID" : "Employee ID")}</span></button> <button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.enrollment) })}${attr("disabled", !clickable || !isValidDoc(documents.enrollment), true)}${attr("title", isValidDoc(documents.enrollment) ? "View Enrollment Form" : "Enrollment Form Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg> <span>(Liceo) ${escape_html(role === "student" ? "Enrollment Form" : "Load Sheet / DTR")}</span></button> `);
			if (owner === "yes") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.letter) })}${attr("disabled", !clickable || !isValidDoc(documents.letter), true)}${attr("title", isValidDoc(documents.letter) ? "View Signed Letter" : "Authorization Letter Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"></path></svg> <span>Signed Letter / DOAS</span></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (role === "visitor" && owner === "yes") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="doc-grid svelte-nss7d3" style="--cols: 2"><button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.license) })}${attr("disabled", !clickable || !isValidDoc(documents.license), true)}${attr("title", isValidDoc(documents.license) ? "View Driver License" : "Driver License Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg> <span>(LTO) Driver's License</span></button> <button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.letter) })}${attr("disabled", !clickable || !isValidDoc(documents.letter), true)}${attr("title", isValidDoc(documents.letter) ? "View Signed Letter" : "Authorization Letter Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"></path></svg> <span>Signed Letter / DOAS</span></button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="doc-grid svelte-nss7d3"${attr_style(`--cols: ${stringify(ltoFull() ? 3 : 2)}`)}>`);
		if (ltoFull()) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.license) })}${attr("disabled", !clickable || !isValidDoc(documents.license), true)}${attr("title", isValidDoc(documents.license) ? "View Driver License" : "Driver License Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg> <span>(LTO) Driver's License</span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.or) })}${attr("disabled", !clickable || !isValidDoc(documents.or), true)}${attr("title", isValidDoc(documents.or) ? "View Vehicle OR" : "Vehicle OR Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg> <span>(LTO) Vehicle OR</span></button> <button${attr_class("doc-tile svelte-nss7d3", void 0, { "has-doc": isValidDoc(documents.cr) })}${attr("disabled", !clickable || !isValidDoc(documents.cr), true)}${attr("title", isValidDoc(documents.cr) ? "View Vehicle CR" : "Vehicle CR Not Uploaded")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-nss7d3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg> <span>(LTO) Vehicle CR</span></button></div></div>`);
	});
}
//#endregion
//#region src/lib/components/ApplicationCard.svelte
function ApplicationCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { tab = "validation", showQR = false, showDocs = true, data = {}, children, selectable = false, selected = false, onselect, startExpanded = false } = $$props;
		let expanded = startExpanded;
		let effectiveShowQR = derived(() => tab === "status" ? false : showQR);
		let showDocPopup = null;
		let defaults = derived(() => data);
		let role = derived(() => data.role?.toLowerCase() ?? "student");
		let ownerVal = derived(() => data.owner?.toLowerCase() === "yes" ? "yes" : "no");
		let rejectionReason = derived(() => data.rejection_reason ?? null);
		let appStatus = derived(() => data.status ?? null);
		let reasonLabel = derived(() => appStatus() === "revoked" ? "Revoked:" : "Rejected:");
		function formatDate(d) {
			if (!d || d === "-" || d === "N/A") return null;
			const dt = new Date(d);
			if (isNaN(dt.getTime())) return null;
			return dt.toLocaleDateString("en-US", {
				month: "short",
				day: "2-digit",
				year: "numeric"
			});
		}
		let statusLabel = derived(() => appStatus()?.replace(/_/g, " ")?.toUpperCase() || "UNKNOWN");
		let statusVariant = derived(() => appStatus() && [
			"approved",
			"completed",
			"Sticker_Installed",
			"sticker_installed",
			"Sticker_Released",
			"sticker_released",
			"security_checked",
			"osa_validated",
			"dept_validated",
			"distributed",
			"osa_val",
			"dept_val"
		].includes(appStatus()) ? "success" : appStatus() && [
			"rejected",
			"revoked",
			"expired"
		].includes(appStatus()) ? "danger" : "warning");
		const statusColors = {
			success: {
				bg: "#f0fdf4",
				text: "#15803d",
				border: "#86efac"
			},
			danger: {
				bg: "#fef2f2",
				text: "#b91c1c",
				border: "#fca5a5"
			},
			warning: {
				bg: "#fffbeb",
				text: "#b45309",
				border: "#fde68a"
			},
			default: {
				bg: "var(--surface)",
				text: "var(--text-secondary)",
				border: "var(--border)"
			}
		};
		let pill = derived(() => statusColors[statusVariant()] ?? statusColors.default);
		const roleColors = {
			student: "#3b82f6",
			employee: "#8b5cf6",
			visitor: "#f59e0b",
			concessionaire: "#10b981",
			guest: "#6b7280"
		};
		let roleColor = derived(() => roleColors[role()] ?? "#6b7280");
		const excludedKeys = [
			"documents",
			"owner",
			"rejection_reason",
			"status",
			"crd",
			"dpt",
			"osa",
			"sch",
			"hdc",
			"sec",
			"rel",
			"ins",
			"exp",
			"qr_code",
			"qr_unique_code",
			"change_vehicle_request",
			"is_change_vehicle"
		];
		function getQRImageUrl(qr = null, uniqueCode = null) {
			if (qr && typeof qr === "string") {
				const trimmed = qr.trim();
				if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("data:")) return trimmed;
				return `/api/qr?code=${encodeURIComponent(trimmed)}&role=${encodeURIComponent(role())}`;
			}
			if (uniqueCode && typeof uniqueCode === "string") {
				const trimmed = uniqueCode.trim();
				if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("data:")) return trimmed;
				return `/api/qr?code=${encodeURIComponent(trimmed)}&role=${encodeURIComponent(role())}`;
			}
			return `/api/qr?code=PENDING&role=${encodeURIComponent(role())}`;
		}
		function isPdf(url) {
			if (!url || typeof url !== "string") return false;
			return url.toLowerCase().includes(".pdf");
		}
		$$renderer.push(`<div${attr_class("app-card svelte-2bn5d4", void 0, {
			"expanded": expanded,
			"selected": selected,
			"selectable": selectable
		})}><div class="card-summary svelte-2bn5d4" role="button" tabindex="0"${attr("aria-expanded", expanded)}>`);
		if (selectable) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="checkbox-wrap svelte-2bn5d4"><input type="checkbox" class="sel-checkbox svelte-2bn5d4"${attr("checked", selected, true)}/></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="avatar svelte-2bn5d4"${attr_style(`background: ${stringify(roleColor())}22; color: ${stringify(roleColor())}; border-color: ${stringify(roleColor())}44;`)}>${escape_html((data.name || "?").split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase())}</div> <div class="summary-main svelte-2bn5d4"><span class="summary-name svelte-2bn5d4">${escape_html(data.name || "—")}</span> <div class="summary-meta svelte-2bn5d4">`);
		if ((data.department || data.Department) && (data.department || data.Department) !== "-") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="meta-chip svelte-2bn5d4">${escape_html(data.department || data.Department)}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.campus) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="meta-chip campus-chip svelte-2bn5d4">${escape_html(data.campus)}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="summary-right svelte-2bn5d4">`);
		if (data.change_vehicle_request || data.is_change_vehicle) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="change-veh-pill svelte-2bn5d4" title="This application is under the request to change registration details">Under Request to Change Registration Details</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (appStatus() === "rejected") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="indicator-pill indicator-rejected svelte-2bn5d4" title="Application is Rejected"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-2bn5d4"><circle cx="12" cy="12" r="10" class="svelte-2bn5d4"></circle><line x1="15" y1="9" x2="9" y2="15" class="svelte-2bn5d4"></line><line x1="9" y1="9" x2="15" y2="15" class="svelte-2bn5d4"></line></svg> REJECTED</span>`);
		} else if (appStatus() === "revoked") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<span class="indicator-pill indicator-revoked svelte-2bn5d4" title="Application/Vehicle is Revoked"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-2bn5d4"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" class="svelte-2bn5d4"></path><line x1="12" y1="9" x2="12" y2="13" class="svelte-2bn5d4"></line><line x1="12" y1="17" x2="12.01" y2="17" class="svelte-2bn5d4"></line></svg> REVOKED</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (rejectionReason() === "OVERDUE" || data.sch && (!data.hdc || data.hdc === "-") && new Date(data.sch) < /* @__PURE__ */ new Date()) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="indicator-pill indicator-overdue svelte-2bn5d4" title="Passed scheduled visit date"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-2bn5d4"><circle cx="12" cy="12" r="10" class="svelte-2bn5d4"></circle><polyline points="12 6 12 12 16 14" class="svelte-2bn5d4"></polyline></svg> OVERDUE SCHEDULE</span>`);
		} else if (rejectionReason() === "RESCHEDULED") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<span class="status-pill svelte-2bn5d4" style="background: #eff6ff; color: #1d4ed8; border-color: #bfdbfe;">RESCHEDULED</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <span class="role-badge svelte-2bn5d4"${attr_style(`background: ${stringify(roleColor())}18; color: ${stringify(roleColor())}; border-color: ${stringify(roleColor())}33;`)}>${escape_html(role())}</span> `);
		if (data.plate) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="plate-chip svelte-2bn5d4">${escape_html(data.plate)}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (appStatus() !== "rejected" && appStatus() !== "revoked") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="status-pill svelte-2bn5d4"${attr_style(`background: ${stringify(pill().bg)}; color: ${stringify(pill().text)}; border-color: ${stringify(pill().border)};`)}>${escape_html(statusLabel())}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <svg${attr_class("chevron svelte-2bn5d4", void 0, { "open": expanded })} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9" class="svelte-2bn5d4"></polyline></svg></div></div> `);
		if (expanded) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card-detail svelte-2bn5d4"><div class="detail-inner svelte-2bn5d4">`);
			if (appStatus() === "rejected") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="app-alert-banner alert-rejected-banner svelte-2bn5d4"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-2bn5d4"><circle cx="12" cy="12" r="10" class="svelte-2bn5d4"></circle><line x1="15" y1="9" x2="9" y2="15" class="svelte-2bn5d4"></line><line x1="9" y1="9" x2="15" y2="15" class="svelte-2bn5d4"></line></svg> <div class="svelte-2bn5d4"><strong class="svelte-2bn5d4">Rejected Application:</strong> This vehicle registration application was rejected. `);
				if (rejectionReason()) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="alert-reason-text svelte-2bn5d4"><strong class="svelte-2bn5d4">Reason:</strong> ${escape_html(rejectionReason())}</div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div>`);
			} else if (appStatus() === "revoked") {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<div class="app-alert-banner alert-revoked-banner svelte-2bn5d4"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-2bn5d4"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" class="svelte-2bn5d4"></path><line x1="12" y1="9" x2="12" y2="13" class="svelte-2bn5d4"></line><line x1="12" y1="17" x2="12.01" y2="17" class="svelte-2bn5d4"></line></svg> <div class="svelte-2bn5d4"><strong class="svelte-2bn5d4">Revoked Account / Application:</strong> Vehicle sticker privileges have been revoked. `);
				if (rejectionReason()) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="alert-reason-text svelte-2bn5d4"><strong class="svelte-2bn5d4">Revocation Reason:</strong> ${escape_html(rejectionReason())}</div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if ((rejectionReason() === "OVERDUE" || data.sch && (!data.hdc || data.hdc === "-") && new Date(data.sch) < /* @__PURE__ */ new Date()) && appStatus() !== "rejected" && appStatus() !== "revoked") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="app-alert-banner alert-overdue-banner svelte-2bn5d4"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-2bn5d4"><circle cx="12" cy="12" r="10" class="svelte-2bn5d4"></circle><line x1="12" y1="8" x2="12" y2="12" class="svelte-2bn5d4"></line><line x1="12" y1="16" x2="12.01" y2="16" class="svelte-2bn5d4"></line></svg> <div class="svelte-2bn5d4"><strong class="svelte-2bn5d4">Missed Submission Schedule:</strong> Scheduled visit date was ${escape_html(data.sch ? new Date(data.sch).toLocaleString("en-US", {
					dateStyle: "medium",
					timeStyle: "short"
				}) : "in the past")}. Click <em class="svelte-2bn5d4">Verify Hardcopy</em> to proceed if applicant has appeared, or <em class="svelte-2bn5d4">Reschedule</em> to set a new date.</div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.change_vehicle_request || data.is_change_vehicle) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="change-vehicle-banner svelte-2bn5d4"><div class="cvb-header svelte-2bn5d4"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-2bn5d4"><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5" class="svelte-2bn5d4"></path></svg> <strong class="svelte-2bn5d4">This application is undergo request to change registration details process</strong></div> `);
				if (data.change_vehicle_request?.reason) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="cvb-reason svelte-2bn5d4"><strong class="svelte-2bn5d4">Applicant's Reason:</strong> "${escape_html(data.change_vehicle_request.reason)}"</div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (data.change_vehicle_request?.new_vehicle_plate) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="cvb-details svelte-2bn5d4"><strong class="svelte-2bn5d4">Requested New Vehicle:</strong> ${escape_html(data.change_vehicle_request.new_vehicle_make || "")} (${escape_html(data.change_vehicle_request.new_vehicle_plate)})</div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="info-grid svelte-2bn5d4"><!--[-->`);
			const each_array = ensure_array_like(Object.entries(defaults()));
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let [key, val] = each_array[$$index];
				if (val !== void 0 && val !== null && val !== "-" && !excludedKeys.includes(key)) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="info-item svelte-2bn5d4"><span class="info-label svelte-2bn5d4">${escape_html(key)}</span> <span class="info-value svelte-2bn5d4">${escape_html(val)}</span></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--> `);
			if (rejectionReason() && rejectionReason() !== "OVERDUE" && rejectionReason() !== "RESCHEDULED") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="info-item info-item-full reason-item svelte-2bn5d4"><span class="info-label reason-label svelte-2bn5d4">${escape_html(reasonLabel())}</span> <span class="info-value reason-value svelte-2bn5d4">${escape_html(rejectionReason())}</span></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="timeline-badges svelte-2bn5d4">`);
			if (appStatus()) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "STS",
					date: statusLabel(),
					variant: statusVariant()
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.crd) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "CRD",
					date: formatDate(data.crd)
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.dpt) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "DPT",
					date: formatDate(data.dpt),
					variant: "success"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.osa) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "OSA",
					date: formatDate(data.osa),
					variant: "success"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.sch) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "SCH",
					date: formatDate(data.sch),
					variant: "warning"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.hdc) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "HDC",
					date: formatDate(data.hdc),
					variant: "success"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.sec) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "SEC",
					date: formatDate(data.sec),
					variant: "success"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.rel) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "REL",
					date: formatDate(data.rel),
					variant: "success"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.ins) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "INS",
					date: formatDate(data.ins),
					variant: "success"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (data.exp) {
				$$renderer.push("<!--[0-->");
				StatusBadge($$renderer, {
					code: "EXP",
					date: formatDate(data.exp),
					variant: "warning"
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> `);
			if (showDocs) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div${attr_class("detail-section svelte-2bn5d4", void 0, { "no-border": tab.toLowerCase() === "revoked" })}><span class="section-label svelte-2bn5d4">Documents</span> `);
				DocumentGrid($$renderer, {
					role: role(),
					owner: ownerVal(),
					documents: defaults().documents || {},
					onopen: (url) => showDocPopup = url
				});
				$$renderer.push(`<!----></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (effectiveShowQR()) {
				$$renderer.push("<!--[0-->");
				const qrImgUrl = getQRImageUrl(data.qr_code, data.qr_unique_code);
				$$renderer.push(`<div${attr_class("detail-section svelte-2bn5d4", void 0, { "no-border": tab.toLowerCase() === "revoked" })}><span class="section-label svelte-2bn5d4">QR Code</span> <div class="qr-body svelte-2bn5d4"><button type="button" class="qr-preview-trigger svelte-2bn5d4" title="Click to view full size QR code"><img${attr("src", qrImgUrl)} alt="Vehicle QR Code" width="96" height="96" class="qr-img svelte-2bn5d4"/></button> <div class="qr-meta svelte-2bn5d4"><span class="qr-code-text svelte-2bn5d4">Code: ${escape_html(data.qr_unique_code || (data.qr_code && !data.qr_code.startsWith("http") ? data.qr_code : "PENDING"))}</span> <a${attr("href", qrImgUrl)}${attr("download", `gateqr-${data.qr_unique_code || data.id || "code"}.png`)} class="qr-download-btn svelte-2bn5d4">Download QR</a></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (children) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div${attr_class("detail-section action-section svelte-2bn5d4", void 0, { "no-border": tab.toLowerCase() === "revoked" })}>`);
				children($$renderer);
				$$renderer.push(`<!----></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> `);
		if (showDocPopup) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="doc-modal-overlay svelte-2bn5d4" role="dialog" aria-modal="true" tabindex="-1"><div class="doc-modal-content svelte-2bn5d4"><button class="close-modal svelte-2bn5d4" aria-label="Close document viewer"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-2bn5d4"><line x1="18" y1="6" x2="6" y2="18" class="svelte-2bn5d4"></line><line x1="6" y1="6" x2="18" y2="18" class="svelte-2bn5d4"></line></svg></button> <div class="doc-image-wrap svelte-2bn5d4">`);
			if (isPdf(showDocPopup)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<iframe${attr("src", showDocPopup)} title="Document Preview" class="doc-preview-frame svelte-2bn5d4"></iframe> <div class="doc-pdf-fallback svelte-2bn5d4" style="padding-top: 0.5rem; text-align: center;"><a${attr("href", showDocPopup)} target="_blank" rel="noopener noreferrer" class="doc-open-link svelte-2bn5d4">Open original PDF in new tab ↗</a></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<img${attr("src", showDocPopup)} alt="Document Preview" class="doc-preview-img svelte-2bn5d4" onerror="this.__e=event"/> <a${attr("href", showDocPopup)} target="_blank" rel="noopener noreferrer" class="doc-open-link svelte-2bn5d4">Open original document in new tab ↗</a>`);
			}
			$$renderer.push(`<!--]--></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
export { ApplicationCard as t };
