import { n as public_env } from "./shared-server.js";
import { C as attr, d as html, i as ensure_array_like, l as unsubscribe_stores, r as derived, s as store_get, t as attr_class, w as escape_html } from "./server.js";
import { t as page } from "./stores.js";
import { createClient } from "@supabase/supabase-js";
//#region src/lib/supabaseClient.ts
var supabaseUrl = public_env.PUBLIC_SUPABASE_URL || "https://nrrbkvtwnoqshtzliijq.supabase.co";
var supabaseAnonKey = public_env.PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ycmJrdnR3bm9xc2h0emxpaWpxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0MDgyNTMsImV4cCI6MjEwNDk4NDI1M30.9qA0pJpfcxh4MAHkHChlrK7GuLlzOUKAOD9ltLOmgVY";
createClient(supabaseUrl, supabaseAnonKey);
//#endregion
//#region src/lib/components/AppShell.svelte
function AppShell($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { title = "GateQR", userEmail = "", children, showSidebar = false, userRole = "osa" } = $$props;
		let currentPath = derived(() => store_get($$store_subs ??= {}, "$page", page).url.pathname);
		derived(() => store_get($$store_subs ??= {}, "$page", page).url.searchParams.get("tab"));
		derived(() => currentPath() === "/osa" || currentPath().startsWith("/osa/change-requests"));
		derived(() => currentPath().startsWith("/osa/admin") || currentPath().startsWith("/osa/deans"));
		let manageAppsOpen = false;
		let mobileNavOpen = false;
		let notifications = [];
		let userInitials = derived(() => userRole === "applicant" ? "AP" : userEmail ? userEmail.slice(0, 2).toUpperCase() : "AD");
		let userDisplayName = derived(() => userRole === "applicant" ? "Applicant" : userEmail ? userEmail.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()) : "Admin User");
		let userRoleLabel = derived(() => userRole === "applicant" ? userEmail || "Applicant" : userRole === "security" ? "Security Administrator" : userRole === "administrative" ? "Administrative Department Head" : userRole === "dean" ? "Academic Department Head" : "OSA Administrator");
		let portalSubtitle = derived(() => userRole === "applicant" ? "Application Form" : userRole === "administrative" ? "Administrative Department Portal" : userRole === "dean" ? "Academic Department Head Portal" : userRole === "security" ? "Safety & Security Office" : "Office of Student Affairs");
		let unreadIncidentsCount = derived(() => notifications.filter((n) => !n.is_read && (n.notification_type === "incident_report" || n.notification_type?.includes("incident") || n.notification_type?.includes("complaint") || n.target_entity_type === "incident_report")).length);
		let unreadApplicationsCount = derived(() => notifications.filter((n) => !n.is_read && (n.target_entity_type === "registration" || n.notification_type?.includes("application") || n.notification_type?.includes("renewal"))).length);
		const securityActions = [
			{
				label: "Dashboard",
				href: "/security/dashboard",
				icon: `<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><line x1="10" y1="17" x2="10" y2="17"/>`,
				description: "View security dashboard and stats"
			},
			{
				label: "Application Review",
				href: "/security",
				icon: `<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>`,
				description: "Review applications and stickers"
			},
			{
				label: "Vehicle Log",
				href: "/security/logs",
				icon: `<path d="M12 2v20M2 12h20M12 2l4 4m-4-4l-4 4"/>`,
				description: "Gate entry and exit history logs"
			},
			{
				label: "Incident Report",
				href: "/security/complaints",
				icon: `<path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>`,
				description: "View and manage incident reports"
			},
			{
				label: "Parking Capacity Records",
				href: "/security/capacity",
				icon: `<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/><path d="M12 22v-7"/><path d="M20 22v-7"/>`,
				description: "Total Count of Registered Vehicles per Campus and Parking Capacities"
			},
			{
				label: "Settings",
				href: "/security/settings",
				icon: `<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>`,
				description: "Administrator account & security credentials"
			}
		];
		$$renderer.push(`<main${attr_class("app-shell theme-osa svelte-whg6dh", void 0, {
			"has-sidebar": showSidebar,
			"no-sidebar": !showSidebar
		})}>`);
		if (showSidebar) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<aside${attr_class("sidebar svelte-whg6dh", void 0, { "mobile-open": mobileNavOpen })}><div class="sidebar-brand svelte-whg6dh"><div class="brand-left-group svelte-whg6dh"><div class="brand-logo svelte-whg6dh"><img src="/liceo-logo.png" alt="LICEO DE CAGAYAN UNIVERSITY" class="svelte-whg6dh"/></div> <div class="brand-info svelte-whg6dh"><div class="brand-top-row svelte-whg6dh"><span class="brand-name svelte-whg6dh">GateQR</span> <span class="brand-tag svelte-whg6dh">ADMIN PORTAL</span></div> <span class="brand-sub svelte-whg6dh">${escape_html(portalSubtitle())}</span></div></div> <button type="button" class="mobile-menu-toggle-btn svelte-whg6dh"${attr("aria-label", "Open menu")}><span class="mobile-toggle-text">${escape_html("Menu")}</span> <svg class="mobile-toggle-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>`);
			$$renderer.push(`<!--]--></svg></button></div> <div class="sidebar-menu-wrapper svelte-whg6dh"><div class="sidebar-menu-heading svelte-whg6dh">MAIN MENU</div> <nav class="sidebar-nav-tree svelte-whg6dh">`);
			if (userRole === "osa") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<a href="/osa/dashboard"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/osa/dashboard" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1.5"></rect><rect x="14" y="3" width="7" height="7" rx="1.5"></rect><rect x="14" y="14" width="7" height="7" rx="1.5"></rect><rect x="3" y="14" width="7" height="7" rx="1.5"></rect></svg></div> <span class="menu-item-label svelte-whg6dh">Dashboard</span></a> <div${attr_class("dropdown-parent-group", void 0, { "is-open": manageAppsOpen })}><button type="button"${attr_class("menu-item-btn dropdown-toggle svelte-whg6dh", void 0, { "active-parent": currentPath() === "/osa" || currentPath().startsWith("/osa/change-requests") })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg></div> <span class="menu-item-label svelte-whg6dh">Manage Applications</span> `);
				if (unreadApplicationsCount() > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="menu-badge-indicator svelte-whg6dh">${escape_html(unreadApplicationsCount() > 99 ? "99+" : unreadApplicationsCount())}</span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <span${attr_class("dropdown-chevron svelte-whg6dh", void 0, { "rotated": manageAppsOpen })}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg></span></button> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <a href="/osa/admin"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/osa/admin" || currentPath().startsWith("/osa/deans") })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg></div> <span class="menu-item-label svelte-whg6dh">Accounts</span></a> <a href="/osa/departments"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/osa/departments" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div> <span class="menu-item-label svelte-whg6dh">Departments</span></a> <a href="/osa/settings"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/osa/settings" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></div> <span class="menu-item-label svelte-whg6dh">Settings</span></a>`);
			} else if (userRole === "dean") {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<a href="/dean"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/dean" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg></div> <span class="menu-item-label svelte-whg6dh">Agreement Form to Park</span></a> <a href="/dean/settings"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/dean/settings" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></div> <span class="menu-item-label svelte-whg6dh">Settings</span></a>`);
			} else if (userRole === "administrative") {
				$$renderer.push("<!--[2-->");
				$$renderer.push(`<a href="/administrative"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/administrative" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg></div> <span class="menu-item-label svelte-whg6dh">Agreement Form to Park</span></a> <a href="/administrative/settings"${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === "/administrative/settings" })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></div> <span class="menu-item-label svelte-whg6dh">Settings</span></a>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--[-->`);
				const each_array_1 = ensure_array_like(securityActions);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let action = each_array_1[$$index_1];
					$$renderer.push(`<a${attr("href", action.href)}${attr_class("menu-item-btn svelte-whg6dh", void 0, { "active": currentPath() === action.href })}><div class="menu-item-icon svelte-whg6dh"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${html(action.icon)}</svg></div> <span class="menu-item-label svelte-whg6dh">${escape_html(action.label)}</span> `);
					if (action.label === "Incident Report" && unreadIncidentsCount() > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="menu-badge-indicator svelte-whg6dh">${escape_html(unreadIncidentsCount() > 99 ? "99+" : unreadIncidentsCount())}</span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></a>`);
				}
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--></nav></div> <div class="sidebar-bottom-action svelte-whg6dh"><button class="bottom-logout-pill svelte-whg6dh" title="Logout of GateQR">Logout</button></div></aside> `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="shell-content svelte-whg6dh"><div class="content-header svelte-whg6dh"><div class="header-left-meta svelte-whg6dh">`);
		if (showSidebar) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button" class="topbar-mobile-hamburger svelte-whg6dh"${attr("aria-label", "Open menu")}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>`);
			$$renderer.push(`<!--]--></svg></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <span class="meta-system-badge svelte-whg6dh"><img src="/liceo-logo.png" alt="LDCU" class="badge-mini-logo svelte-whg6dh"/> <span class="meta-title svelte-whg6dh">GateQR</span> <span class="meta-sep svelte-whg6dh">•</span> <span class="meta-sub svelte-whg6dh">${escape_html(portalSubtitle())}</span></span></div> <div class="header-actions-group svelte-whg6dh">`);
		if (userRole === "applicant") {
			$$renderer.push("<!--[0-->");
			if (currentPath() === "/complaints") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<a href="/status" class="topbar-action-pill complaints-pill svelte-whg6dh"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg> <span>Application Status</span></a>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<a href="/complaints" class="topbar-action-pill complaints-pill svelte-whg6dh"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg> <span>Incident Report</span></a>`);
			}
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="notification-wrapper svelte-whg6dh"><button class="topbar-bell-btn svelte-whg6dh" aria-label="Toggle notifications"><svg class="bell-svg svelte-whg6dh" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="topbar-profile-pill svelte-whg6dh"><div class="profile-avatar-circle svelte-whg6dh"><span>${escape_html(userInitials())}</span></div> <div class="profile-info-block svelte-whg6dh"><span class="profile-name svelte-whg6dh">${escape_html(userDisplayName())}</span> <span class="profile-role-sub svelte-whg6dh">${escape_html(userRoleLabel())}</span></div></div> `);
		if (!showSidebar) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button class="topbar-logout-btn svelte-whg6dh" title="Logout of GateQR"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg> <span class="svelte-whg6dh">Logout</span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="page-body-container svelte-whg6dh">`);
		children($$renderer);
		$$renderer.push(`<!----></div></div></main>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
export { AppShell as t };
