import { t as private_env } from "./shared-server.js";
import { createClient } from "@supabase/supabase-js";
//#region src/lib/server/supabase.ts
var supabaseUrl = private_env.PRIVATE_SUPABASE_URL || private_env.SUPABASE_URL;
var supabaseServiceKey = private_env.PRIVATE_SUPABASE_SERVICE_ROLE_KEY || private_env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) throw new Error("Missing Supabase credentials. Please set PRIVATE_SUPABASE_URL and PRIVATE_SUPABASE_SERVICE_ROLE_KEY in your .env file");
var supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, { auth: {
	autoRefreshToken: false,
	persistSession: false
} });
var supabase = supabaseAdmin;
//#endregion
export { supabaseAdmin as n, supabase as t };
