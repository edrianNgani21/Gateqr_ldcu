import "../../../chunks/server.js";
//#region src/routes/entry/+page.svelte
function _page($$renderer) {}
//#endregion
export { _page as default };
