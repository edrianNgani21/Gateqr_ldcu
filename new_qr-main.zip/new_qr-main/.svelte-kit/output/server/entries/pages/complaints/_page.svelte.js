import "../../../chunks/internal.js";
import { C as attr, a as head, w as escape_html } from "../../../chunks/server.js";
import { t as AppShell } from "../../../chunks/AppShell.js";
import "../../../chunks/liveSync.js";
//#region src/routes/complaints/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let complaints = [];
		let message = "";
		let submitLoading = false;
		head("19ea2kf", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Incident Report — GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="View and submit incident reports."/>`);
		});
		AppShell($$renderer, {
			userRole: "applicant",
			userEmail: data.userEmail,
			showSidebar: false,
			children: ($$renderer) => {
				$$renderer.push(`<div class="welcome-banner svelte-19ea2kf"><div class="wb-content svelte-19ea2kf"><h1 class="wb-title svelte-19ea2kf">Incident Report</h1> <p class="wb-sub svelte-19ea2kf">Submit and track your incident reports to the Safety &amp; Security Office.</p></div> <div class="wb-actions-right"><a href="/status" class="btn-back svelte-19ea2kf"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"></path></svg> Back to Status</a></div></div> `);
				if (complaints.some((c) => c.schedule && c.status !== "resolved")) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="alert-schedule svelte-19ea2kf"><div class="alert-icon svelte-19ea2kf"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg></div> <div><strong>Meeting Scheduled</strong> — The security office has scheduled a meeting with you. Please check your incident report details below.</div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="layout-grid svelte-19ea2kf"><div class="submit-section"><div class="form-card svelte-19ea2kf"><div class="form-card-header svelte-19ea2kf"><h3 class="svelte-19ea2kf">New Incident Report</h3></div> <div class="form-card-body svelte-19ea2kf"><p class="svelte-19ea2kf">Your message will be sent securely to the security office. They will review it and may schedule a meeting with you.</p> <textarea placeholder="Describe your concern in detail…" class="complaint-textarea svelte-19ea2kf" rows="6"${attr("disabled", submitLoading, true)}>`);
				const $$body = escape_html(message);
				if ($$body) $$renderer.push(`${$$body}`);
				$$renderer.push(`</textarea> <button class="btn-submit svelte-19ea2kf"${attr("disabled", !message.trim(), true)}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg> Send to Security Office`);
				$$renderer.push(`<!--]--></button></div></div></div> <div class="history-section"><h3 class="section-heading svelte-19ea2kf">Incident Report History</h3> `);
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="loading-state svelte-19ea2kf"><svg class="loading-spinner svelte-19ea2kf" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2.5" stroke-dasharray="35 15" stroke-linecap="round"></circle></svg> Loading…</div>`);
				$$renderer.push(`<!--]--></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
