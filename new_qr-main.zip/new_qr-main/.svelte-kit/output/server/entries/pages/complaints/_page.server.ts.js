import { redirect } from "@sveltejs/kit";
//#region src/routes/complaints/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user) throw redirect(303, "/login");
	return { userEmail: locals.user.email };
};
//#endregion
export { load };
