import { C as attr, a as head, w as escape_html } from "../../../chunks/server.js";
import "../../../chunks/navigation.js";
//#region src/routes/login/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let applicantEmail = "";
		let loading = false;
		head("1x05zx6", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>GateQR — Liceo de Cagayan University | Apply Sticker &amp; Sign In</title>`);
			});
			$$renderer.push(`<meta name="description" content="Apply for a vehicle sticker for gate pass or sign in to GateQR at Liceo de Cagayan University." class="svelte-1x05zx6"/>`);
		});
		$$renderer.push(`<div class="login-page svelte-1x05zx6"><div class="bg-glow glow-top-left svelte-1x05zx6"></div> <div class="bg-glow glow-bottom-right svelte-1x05zx6"></div> <div class="bg-poly-texture svelte-1x05zx6"></div> <div class="split-card svelte-1x05zx6"><div class="card-form-side svelte-1x05zx6">`);
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div class="form-header svelte-1x05zx6"><div class="header-badge svelte-1x05zx6">Gate Pass Portal</div> <h1 class="main-form-title svelte-1x05zx6">Apply For Sticker</h1> <p class="main-form-subtitle svelte-1x05zx6">Enter your university email to apply for a vehicle gate pass sticker or track your status.</p></div> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <form class="auth-form svelte-1x05zx6"><div class="input-group svelte-1x05zx6"><label for="applicant-email" class="input-label svelte-1x05zx6">Applicant Email</label> <div class="input-field-wrap svelte-1x05zx6"><svg class="field-icon svelte-1x05zx6" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" class="svelte-1x05zx6"></path><polyline points="22,6 12,13 2,6" class="svelte-1x05zx6"></polyline></svg> <input id="applicant-email" type="email" inputmode="email"${attr("value", applicantEmail)} placeholder="e.g. yourname@liceo.edu.ph" autocomplete="email" required=""${attr("disabled", loading, true)} class="svelte-1x05zx6"/></div></div> <div class="form-action-row svelte-1x05zx6"><button type="submit" class="btn-primary-pill svelte-1x05zx6"${attr("disabled", loading, true)}><span class="svelte-1x05zx6">${escape_html("APPLY FOR STICKER")}</span> `);
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-1x05zx6"><path d="M5 12h14M12 5l7 7-7 7" class="svelte-1x05zx6"></path></svg>`);
		$$renderer.push(`<!--]--></button></div></form> <div class="switch-section svelte-1x05zx6"><div class="divider-line svelte-1x05zx6"><span class="svelte-1x05zx6">OR</span></div> <button type="button" class="btn-admin-switch svelte-1x05zx6"><div class="switch-icon svelte-1x05zx6"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1x05zx6"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" class="svelte-1x05zx6"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4" class="svelte-1x05zx6"></path></svg></div> <div class="switch-label-group svelte-1x05zx6"><span class="switch-primary svelte-1x05zx6">Admin Login</span> <span class="switch-secondary svelte-1x05zx6">Sign in for Security, OSA &amp; Deans</span></div> <svg class="switch-arrow svelte-1x05zx6" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 18l6-6-6-6" class="svelte-1x05zx6"></path></svg></button></div>`);
		$$renderer.push(`<!--]--></div> <div class="card-hero-side svelte-1x05zx6"><div class="hero-image-bg svelte-1x05zx6"></div> <div class="hero-poly-overlay svelte-1x05zx6"></div> <div class="hero-content svelte-1x05zx6"><div class="hero-logo-wrap svelte-1x05zx6"><img src="/liceo-logo.png" alt="Liceo de Cagayan University" class="hero-logo svelte-1x05zx6"/></div> <div class="hero-text-block svelte-1x05zx6"><span class="hero-tagline-pill svelte-1x05zx6">OFFICIAL GATE PASS PORTAL</span> <h2 class="hero-title svelte-1x05zx6">GateQR</h2> <p class="hero-university svelte-1x05zx6">Liceo de Cagayan University</p> <div class="hero-highlight-card svelte-1x05zx6"><div class="highlight-icon svelte-1x05zx6"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-1x05zx6"><rect x="3" y="3" width="7" height="7" rx="1" class="svelte-1x05zx6"></rect><rect x="14" y="3" width="7" height="7" rx="1" class="svelte-1x05zx6"></rect><rect x="3" y="14" width="7" height="7" rx="1" class="svelte-1x05zx6"></rect><circle cx="17.5" cy="17.5" r="2.5" class="svelte-1x05zx6"></circle></svg></div> <div class="highlight-info svelte-1x05zx6"><span class="highlight-title svelte-1x05zx6">Apply Sticker for Gate Pass</span></div></div></div> <div class="hero-footer-note svelte-1x05zx6"><span class="svelte-1x05zx6">Office of Student Affairs • Safety &amp; Security Office</span></div></div></div></div></div>`);
	});
}
//#endregion
export { _page as default };
