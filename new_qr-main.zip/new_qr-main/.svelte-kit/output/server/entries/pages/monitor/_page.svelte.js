import { C as attr, c as stringify, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../../chunks/server.js";
import { t as AppShell } from "../../../chunks/AppShell.js";
import "../../../chunks/liveSync.js";
import { t as NavBar } from "../../../chunks/NavBar.js";
//#region src/routes/monitor/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		const navLinks = [
			{
				label: "Dashboard",
				href: "/security/dashboard"
			},
			{
				label: "Operations",
				href: "/security"
			},
			{
				label: "Monitor",
				href: "/monitor"
			},
			{
				label: "Incident Report",
				href: "/security/complaints"
			}
		];
		let vehicles = data.vehicles || [];
		let searchQuery = "";
		const filteredVehicles = derived(() => vehicles.filter((v) => v.first_name.toLowerCase().includes(searchQuery.toLowerCase()) || v.last_name.toLowerCase().includes(searchQuery.toLowerCase()) || v.vehicle_plate.toLowerCase().includes(searchQuery.toLowerCase()) || (v.id || "").toLowerCase().includes(searchQuery.toLowerCase())));
		AppShell($$renderer, {
			children: ($$renderer) => {
				NavBar($$renderer, {
					title: "Safety & Security Monitor",
					links: navLinks
				});
				$$renderer.push(`<!----> <div class="card svelte-1hv0izl"><div class="header svelte-1hv0izl"><h2 class="title svelte-1hv0izl">Registered Vehicles</h2> <input type="text" placeholder="Search by name, plate, or QR..."${attr("value", searchQuery)} class="search-box svelte-1hv0izl"/></div> <div class="table-wrap svelte-1hv0izl"><table class="data-table svelte-1hv0izl"><thead><tr><th class="svelte-1hv0izl">Owner Name</th><th class="svelte-1hv0izl">Role</th><th class="svelte-1hv0izl">Vehicle</th><th class="svelte-1hv0izl">Plate No</th><th class="svelte-1hv0izl">Type</th><th class="svelte-1hv0izl">QR ID</th><th class="svelte-1hv0izl">Status</th>`);
				if (data.userRole === "security") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<th class="svelte-1hv0izl">Actions</th>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></tr></thead><tbody class="svelte-1hv0izl"><!--[-->`);
				const each_array = ensure_array_like(filteredVehicles());
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let v = each_array[$$index];
					$$renderer.push(`<tr class="svelte-1hv0izl"><td class="svelte-1hv0izl">${escape_html(v.first_name)} ${escape_html(v.last_name)}</td><td class="capitalize svelte-1hv0izl">${escape_html(v.role)}</td><td class="svelte-1hv0izl">${escape_html(v.vehicle_make)}</td><td class="svelte-1hv0izl">${escape_html(v.vehicle_plate)}</td><td class="svelte-1hv0izl">${escape_html(v.vehicle_type)}</td><td class="font-mono svelte-1hv0izl">${escape_html(v.id ? v.id : `REG-${v.vehicle_id}`)}</td><td class="svelte-1hv0izl"><span${attr_class(`status-badge ${stringify(v.status)}`, "svelte-1hv0izl")}>${escape_html(v.status)}</span></td>`);
					if (data.userRole === "security") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<td class="actions-cell svelte-1hv0izl">`);
						if (v.status === "revoked") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button class="btn-success svelte-1hv0izl">Restore QR</button>`);
						} else if (v.status === "distributed") {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<button class="btn-danger svelte-1hv0izl">Revoke QR</button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></td>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></tr>`);
				}
				$$renderer.push(`<!--]--></tbody></table></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
