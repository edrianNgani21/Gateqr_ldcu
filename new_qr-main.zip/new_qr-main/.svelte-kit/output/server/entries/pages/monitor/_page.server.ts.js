import { t as supabase } from "../../../chunks/supabase.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/monitor/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "security") throw redirect(303, "/auth/login");
	const { data: rows } = await supabase.from("registration").select(`
            *,
            user:user_id(
                email
            ),
            department:department_id(
                department_id,
                academic_department,
                administrative_department
            )
        `).order("created_at", { ascending: false });
	const vehicles = (rows || []).map((row) => ({
		...row,
		user_email: row.user?.email,
		department_name: row.department?.academic_department || row.department?.administrative_department || row.department?.department_name || row.department?.department || "-"
	}));
	return {
		userRole: locals.user.role,
		vehicles
	};
};
//#endregion
export { load };
