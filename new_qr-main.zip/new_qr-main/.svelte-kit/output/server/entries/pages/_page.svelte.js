import { C as attr, a as head, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../chunks/server.js";
import { t as AppShell } from "../../chunks/AppShell.js";
import "../../chunks/navigation.js";
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		const existing = data.existingApplicationData;
		const isRenewal = data.isRenewal;
		let role = existing?.role || "";
		let section = 1;
		existing?.vehicle_information?.authorization_letter;
		let dept = existing?.department?.academic_department || existing?.department?.administrative_department || "";
		let campus = existing?.campus || "";
		let year_level = existing?.year_level || "";
		let fname = existing?.first_name || "";
		let lname = existing?.last_name || "";
		let contact_number = existing?.mobile || "";
		let facebook = existing?.facebook || "";
		let vehicle = existing?.vehicle_information?.brand || "";
		let vehicle_type = existing?.vehicle_information?.type || "";
		let plate = existing?.vehicle_information?.plate_number || "";
		let color = existing?.vehicle_information?.color || "";
		let idno = existing?.school_id || "";
		const today = /* @__PURE__ */ new Date();
		const day = today.getDate();
		today.toLocaleString("default", { month: "long" });
		today.getFullYear();
		const daySuffix = (d) => {
			if (d > 3 && d < 21) return "TH";
			switch (d % 10) {
				case 1: return "ST";
				case 2: return "ND";
				case 3: return "RD";
				default: return "TH";
			}
		};
		`${day}${daySuffix(day)}`;
		existing?.doc_id, existing?.vehicle_information?.authorization_letter, existing?.vehicle_information?.or, existing?.vehicle_information?.cr, existing?.drivers_license;
		let canProceed = derived(() => (() => {
			if (!fname || !lname || !contact_number || !vehicle || !vehicle_type || !plate || !color || !role || !campus) return false;
			if (!dept || !idno) return false;
			if (contact_number.length !== 11 || !/^\d{11}$/.test(contact_number)) return false;
			if (idno.length !== 11 || !/^\d{11}$/.test(idno)) return false;
			if (role === "student" && !year_level) return false;
			return true;
		})());
		const totalSections = 4;
		const sectionTitles = [
			"Personal Information",
			"Document Evaluation",
			"Agreement to Park",
			"Parking Regulations"
		];
		head("1uha8ag", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Vehicle Sticker Application — GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Apply for a Liceo de Cagayan University vehicle parking sticker."/>`);
		});
		AppShell($$renderer, {
			userRole: "applicant",
			userEmail: data.userEmail,
			showSidebar: false,
			children: ($$renderer) => {
				if (data.applicationOpen === false) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="doc-closed-card svelte-1uha8ag"><svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#7A1734" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg> <h2 class="closed-title svelte-1uha8ag">Applications are currently closed</h2> <p class="closed-desc svelte-1uha8ag">The Office of Student Affairs is not accepting vehicle sticker applications right now. Please check back later or contact <a href="mailto:osa@liceo.edu.ph" class="footer-link svelte-1uha8ag">osa@liceo.edu.ph</a>.</p> <button type="button" class="nav-btn btn-back svelte-1uha8ag"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"></path></svg> Back</button></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="doc-page-wrapper svelte-1uha8ag"><div class="doc-sheet svelte-1uha8ag"><div class="doc-header-banner svelte-1uha8ag"><div class="banner-left-content svelte-1uha8ag"><h1 class="banner-main-title svelte-1uha8ag">${escape_html(isRenewal ? "Vehicle Sticker Renewal" : "Vehicle Sticker Application")}</h1> <div class="banner-sub-line-wrap svelte-1uha8ag"><span class="banner-subtitle-text svelte-1uha8ag">${escape_html(isRenewal ? "Renew your registration for the new School Year" : "Fill out the form to request a sticker")}</span> <div class="banner-ruler-dot svelte-1uha8ag"><span class="ruler-line svelte-1uha8ag"></span> <span class="ruler-dot svelte-1uha8ag"></span></div></div></div> <div class="banner-right-chevron svelte-1uha8ag"><div class="banner-brand-box svelte-1uha8ag"><img src="/liceo-logo.png" alt="Liceo Logo" class="banner-logo-img svelte-1uha8ag"/> <div class="banner-brand-meta svelte-1uha8ag"><span class="brand-name-bold svelte-1uha8ag">GateQR</span> <span class="brand-univ-sub svelte-1uha8ag">Liceo de Cagayan University</span></div></div></div></div> <div class="doc-step-bar svelte-1uha8ag"><!--[-->`);
					const each_array = ensure_array_like(Array(totalSections));
					for (let i = 0, $$length = each_array.length; i < $$length; i++) {
						each_array[i];
						$$renderer.push(`<div${attr_class("doc-step-item svelte-1uha8ag", void 0, {
							"step-done": section > i + 1,
							"step-active": section === i + 1,
							"step-pending": section < i + 1
						})}><div class="doc-step-badge svelte-1uha8ag">`);
						if (section > i + 1) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(i + 1)}`);
						}
						$$renderer.push(`<!--]--></div> <span class="doc-step-title svelte-1uha8ag">${escape_html(sectionTitles[i])}</span> `);
						if (i < 3) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="doc-step-connector svelte-1uha8ag"></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div>`);
					}
					$$renderer.push(`<!--]--></div> <div class="doc-body-content svelte-1uha8ag">`);
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="doc-form-table svelte-1uha8ag"><div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><span class="doc-row-title svelte-1uha8ag">Full Name <span class="req-star svelte-1uha8ag">*</span></span></div> <div class="doc-col-fields svelte-1uha8ag"><div class="doc-fields-duo svelte-1uha8ag"><div class="field-item svelte-1uha8ag"><input id="fname" type="text" placeholder="First Name"${attr("value", fname)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">First Name</span></div> <div class="field-item svelte-1uha8ag"><input id="lname" type="text" placeholder="Last Name"${attr("value", lname)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">Last Name</span></div></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><span class="doc-row-title svelte-1uha8ag">Email</span></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag"><input type="email"${attr("value", data.userEmail || "")} disabled="" class="doc-input-box doc-input-readonly svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">applicant@liceo.edu.ph</span></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="contact">Phone Number <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag"><input id="contact" type="tel" inputmode="numeric" maxlength="11" pattern="[0-9]11" placeholder="09123456789"${attr("value", contact_number)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">Mobile Number (11 digits only, e.g. 09123456789) `);
					if (contact_number.length > 0 && contact_number.length < 11) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="field-count-warn svelte-1uha8ag">(${escape_html(contact_number.length)}/11 digits)</span>`);
					} else if (contact_number.length === 11) {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`<span class="field-count-ok svelte-1uha8ag">(11/11 digits ✓)</span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></span></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="fb">Facebook</label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag"><input id="fb" type="text" placeholder="facebook.com/username (Optional)"${attr("value", facebook)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">Optional social profile</span></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="vehicle">Vehicle Details <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag"><input id="vehicle" type="text" placeholder="e.g. Honda Civic 2022 / Yamaha NMAX"${attr("value", vehicle)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">Vehicle Make &amp; Model</span></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><span class="doc-row-title svelte-1uha8ag">Vehicle Type <span class="req-star svelte-1uha8ag">*</span></span></div> <div class="doc-col-fields svelte-1uha8ag"><div class="doc-checkbox-group svelte-1uha8ag"><label${attr_class("doc-checkbox-pill svelte-1uha8ag", void 0, { "is-selected": vehicle_type === "2-Wheeler / Motorcycle" })}><input type="checkbox" class="doc-cb-hidden svelte-1uha8ag"${attr("checked", vehicle_type === "2-Wheeler / Motorcycle", true)}/> <span class="doc-cb-square svelte-1uha8ag"><svg class="cb-checkmark svelte-1uha8ag" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg></span> <span class="cb-text-label svelte-1uha8ag">2-Wheeler / Motorcycle</span></label> <label${attr_class("doc-checkbox-pill svelte-1uha8ag", void 0, { "is-selected": vehicle_type === "4-Wheeler / Car" })}><input type="checkbox" class="doc-cb-hidden svelte-1uha8ag"${attr("checked", vehicle_type === "4-Wheeler / Car", true)}/> <span class="doc-cb-square svelte-1uha8ag"><svg class="cb-checkmark svelte-1uha8ag" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg></span> <span class="cb-text-label svelte-1uha8ag">4-Wheeler / Car</span></label></div> <span class="doc-field-hint svelte-1uha8ag">Check your vehicle type</span></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><span class="doc-row-title svelte-1uha8ag">Plate &amp; Color <span class="req-star svelte-1uha8ag">*</span></span></div> <div class="doc-col-fields svelte-1uha8ag"><div class="doc-fields-duo svelte-1uha8ag"><div class="field-item svelte-1uha8ag"><input id="plate" type="text" placeholder="ABC-1234"${attr("value", plate)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">Plate Number</span></div> <div class="field-item svelte-1uha8ag"><input id="color" type="text" placeholder="e.g. Red, Blue, Black"${attr("value", color)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">Color</span></div></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="role">Role <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag">`);
					$$renderer.select({
						id: "role",
						value: role,
						class: "doc-select-box",
						onchange: () => {
							dept = "";
							year_level = "";
						}
					}, ($$renderer) => {
						$$renderer.option({
							value: "",
							disabled: true,
							hidden: true,
							selected: true
						}, ($$renderer) => {
							$$renderer.push(`Select role`);
						});
						$$renderer.option({ value: "student" }, ($$renderer) => {
							$$renderer.push(`Student`);
						});
						$$renderer.option({ value: "faculty" }, ($$renderer) => {
							$$renderer.push(`Faculty`);
						});
						$$renderer.option({ value: "staff" }, ($$renderer) => {
							$$renderer.push(`Staff`);
						});
						$$renderer.option({ value: "administrator" }, ($$renderer) => {
							$$renderer.push(`Administrator`);
						});
						$$renderer.option({ value: "concessionnaire" }, ($$renderer) => {
							$$renderer.push(`Concessionnaire`);
						});
						$$renderer.option({ value: "supplier" }, ($$renderer) => {
							$$renderer.push(`Supplier`);
						});
						$$renderer.option({ value: "vps" }, ($$renderer) => {
							$$renderer.push(`Vps`);
						});
					}, "svelte-1uha8ag", { "placeholder-sel": !role });
					$$renderer.push(` <span class="doc-field-hint svelte-1uha8ag">Affiliation status</span></div></div></div> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="campus">Campus <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag">`);
					$$renderer.select({
						id: "campus",
						value: campus,
						class: "doc-select-box"
					}, ($$renderer) => {
						$$renderer.option({
							value: "",
							disabled: true,
							hidden: true,
							selected: true
						}, ($$renderer) => {
							$$renderer.push(`Select campus`);
						});
						$$renderer.option({ value: "Liceo Main" }, ($$renderer) => {
							$$renderer.push(`Liceo Main`);
						});
						$$renderer.option({ value: "RNP" }, ($$renderer) => {
							$$renderer.push(`RNP`);
						});
						$$renderer.option({ value: "PASEO" }, ($$renderer) => {
							$$renderer.push(`PASEO`);
						});
					}, "svelte-1uha8ag", { "placeholder-sel": !campus });
					$$renderer.push(` <span class="doc-field-hint svelte-1uha8ag">Primary campus</span></div></div></div> `);
					if (role) {
						$$renderer.push("<!--[0-->");
						const isStudent = role === "student";
						const deptsList = isStudent ? data.academicDepartments && data.academicDepartments.length > 0 ? data.academicDepartments : data.departments : data.administrativeDepartments && data.administrativeDepartments.length > 0 ? data.administrativeDepartments : data.departments;
						$$renderer.push(`<div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="dept">${escape_html(isStudent ? "Academic Department" : "Administrative Department")} <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag">`);
						$$renderer.select({
							id: "dept",
							value: dept,
							class: "doc-select-box",
							onchange: () => year_level = ""
						}, ($$renderer) => {
							$$renderer.option({
								value: "",
								disabled: true,
								hidden: true,
								selected: true
							}, ($$renderer) => {
								$$renderer.push(`Select ${escape_html(isStudent ? "academic department" : "administrative department")}`);
							});
							$$renderer.push(`<!--[-->`);
							const each_array_1 = ensure_array_like(deptsList);
							for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
								let d = each_array_1[$$index_1];
								$$renderer.option({ value: d }, ($$renderer) => {
									$$renderer.push(`${escape_html(d)}`);
								});
							}
							$$renderer.push(`<!--]-->`);
						}, "svelte-1uha8ag", { "placeholder-sel": !dept });
						$$renderer.push(` <span class="doc-field-hint svelte-1uha8ag">${escape_html(isStudent ? "College / Academic Department" : "Office / Administrative Department")}</span></div></div></div> `);
						if (role === "student") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="year_level">Year Level <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag">`);
							$$renderer.select({
								id: "year_level",
								value: year_level,
								class: "doc-select-box"
							}, ($$renderer) => {
								$$renderer.option({
									value: "",
									disabled: true,
									hidden: true,
									selected: true
								}, ($$renderer) => {
									$$renderer.push(`Select year level`);
								});
								if (dept.toLowerCase().includes("senior highschool")) {
									$$renderer.push("<!--[0-->");
									$$renderer.option({ value: "Grade 11" }, ($$renderer) => {
										$$renderer.push(`Grade 11`);
									});
									$$renderer.push(` `);
									$$renderer.option({ value: "Grade 12" }, ($$renderer) => {
										$$renderer.push(`Grade 12`);
									});
								} else {
									$$renderer.push("<!--[-1-->");
									$$renderer.option({ value: "1st Year" }, ($$renderer) => {
										$$renderer.push(`1st Year`);
									});
									$$renderer.push(` `);
									$$renderer.option({ value: "2nd Year" }, ($$renderer) => {
										$$renderer.push(`2nd Year`);
									});
									$$renderer.push(` `);
									$$renderer.option({ value: "3rd Year" }, ($$renderer) => {
										$$renderer.push(`3rd Year`);
									});
									$$renderer.push(` `);
									$$renderer.option({ value: "4th Year" }, ($$renderer) => {
										$$renderer.push(`4th Year`);
									});
									$$renderer.push(` `);
									$$renderer.option({ value: "5th Year" }, ($$renderer) => {
										$$renderer.push(`5th Year`);
									});
								}
								$$renderer.push(`<!--]-->`);
							}, "svelte-1uha8ag", { "placeholder-sel": !year_level });
							$$renderer.push(` <span class="doc-field-hint svelte-1uha8ag">Academic year level</span></div></div></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> <div class="doc-form-row svelte-1uha8ag"><div class="doc-col-label svelte-1uha8ag"><label class="doc-row-title svelte-1uha8ag" for="idno">ID Number <span class="req-star svelte-1uha8ag">*</span></label></div> <div class="doc-col-fields svelte-1uha8ag"><div class="field-item full-width svelte-1uha8ag"><input id="idno" type="text" inputmode="numeric" maxlength="11" pattern="[0-9]11" placeholder="e.g. 20221234567"${attr("value", idno)} class="doc-input-box svelte-1uha8ag"/> <span class="doc-field-hint svelte-1uha8ag">University ID Number (11 digits only) `);
						if (idno.length > 0 && idno.length < 11) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="field-count-warn svelte-1uha8ag">(${escape_html(idno.length)}/11 digits)</span>`);
						} else if (idno.length === 11) {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<span class="field-count-ok svelte-1uha8ag">(11/11 digits ✓)</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></span></div></div></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
					$$renderer.push(`<!--]--> <div class="doc-bottom-accent-row svelte-1uha8ag"><div class="accent-dots-cluster svelte-1uha8ag"><span class="accent-dot svelte-1uha8ag"></span> <span class="accent-dot svelte-1uha8ag"></span> <span class="accent-dot svelte-1uha8ag"></span></div> <div class="accent-ruler-line svelte-1uha8ag"></div></div></div> <div${attr_class("doc-nav-row svelte-1uha8ag", void 0, { "has-multi-nav": false })}><button type="button" class="nav-btn btn-status-return svelte-1uha8ag"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg> Back to Status</button> <div class="doc-nav-forward-actions svelte-1uha8ag">`);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button type="button" class="nav-btn btn-next-step svelte-1uha8ag"${attr("disabled", !canProceed(), true)}><span>Next</span> <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"></path></svg></button>`);
					$$renderer.push(`<!--]--></div></div> <div class="doc-card-footer-help svelte-1uha8ag">Issues? Contact <a href="mailto:osa@liceo.edu.ph" class="footer-link svelte-1uha8ag">osa@liceo.edu.ph</a></div></div></div>`);
				}
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
