import { t as supabase } from "../../../chunks/supabase.js";
import { n as isApplicationFormOpen } from "../../../chunks/applicationForm.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/status/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user) throw redirect(303, "/login");
	try {
		const { data: users } = await supabase.from("users").select("user_id").eq("email", locals.user.email).single();
		if (!users) {
			console.error("Error fetching user");
			return {
				userEmail: locals.user.email,
				scheduledCount: 0,
				application: null
			};
		}
		const userId = users.user_id;
		const { data: applications } = await supabase.from("registration").select(`
                *,
                department:department_id(
                    department_id,
                    academic_department,
                    administrative_department
                ),
                vehicle_information:vehicle_information_id(
                    "or",
                    cr,
                    authorization_letter,
                    plate_number,
                    brand,
                    color,
                    type
                )
            `).eq("user_id", userId).order("created_at", { ascending: false }).limit(1).single();
		const { count: scheduledCount } = await supabase.from("incident_report").select("*", {
			count: "exact",
			head: true
		}).eq("user_id", userId).not("schedule", "is", null).neq("status", "resolved");
		const application = applications ? {
			...applications,
			id: applications.registration_id,
			department_name: applications.department?.academic_department || applications.department?.administrative_department || applications.department?.department_name || applications.department?.department || "-",
			user: { email: locals.user.email },
			doc_id: applications.doc_id || (applications.agreement_form && typeof applications.agreement_form === "string" && applications.agreement_form.startsWith("http") ? applications.agreement_form : null) || (applications.school_id && typeof applications.school_id === "string" && applications.school_id.startsWith("http") ? applications.school_id : null) || null,
			doc_load: applications.enrollment_form || null,
			doc_or: applications.vehicle_information?.or || applications.vehicle_information?.or_document || null,
			doc_cr: applications.vehicle_information?.cr || applications.vehicle_information?.cr_document || null,
			doc_license: applications.drivers_license || applications.vehicle_information?.drivers_license || null,
			doc_letter: applications.vehicle_information?.authorization_letter || null,
			invalid_reason: applications.rejection_reason || applications.revoke_reason || null,
			schedule: typeof applications.schedule === "string" ? applications.schedule : applications.schedule?.toISOString?.() || applications.dist_sched || null,
			dist_sched: typeof applications.schedule === "string" ? applications.schedule : applications.schedule?.toISOString?.() || applications.dist_sched || null,
			security_check_at: typeof applications.security_check_at === "string" ? applications.security_check_at : applications.security_check_at?.toISOString?.() || applications.security_checked_at || null,
			security_checked_at: typeof applications.security_check_at === "string" ? applications.security_check_at : applications.security_check_at?.toISOString?.() || applications.security_checked_at || null,
			vehicle_make: applications.vehicle_information?.brand || "Unknown",
			vehicle_color: applications.vehicle_information?.color || "-",
			vehicle_plate: applications.vehicle_information?.plate_number || "-",
			vehicle_type: applications.vehicle_information?.type || "-"
		} : null;
		if (application) {
			delete application.qr_code;
			delete application.qr_unique_code;
		}
		const { data: changeRequest } = await supabase.from("modification_request").select("*").eq("user_id", userId).order("request_at", { ascending: false }).limit(1).maybeSingle();
		const applicationOpen = await isApplicationFormOpen();
		return {
			userEmail: locals.user.email,
			scheduledCount: scheduledCount || 0,
			application,
			changeRequest: changeRequest || null,
			applicationOpen
		};
	} catch (error) {
		console.error("Error loading status:", error);
		return {
			userEmail: locals.user.email,
			scheduledCount: 0,
			application: null,
			changeRequest: null,
			applicationOpen: true
		};
	}
};
//#endregion
export { load };
