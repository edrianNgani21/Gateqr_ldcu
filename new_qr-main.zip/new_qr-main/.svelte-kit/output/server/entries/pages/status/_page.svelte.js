import { a as head, r as derived, t as attr_class, w as escape_html } from "../../../chunks/server.js";
import { t as AppShell } from "../../../chunks/AppShell.js";
import "../../../chunks/navigation.js";
import "../../../chunks/liveSync.js";
import { t as ApplicationCard } from "../../../chunks/ApplicationCard.js";
//#region src/routes/status/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let app = derived(() => data.application || null);
		let changeRequest = derived(() => data.changeRequest || null);
		let skipDean = derived(() => app() ? ["visitor", "concessionaire"].includes(app().role) : false);
		function stepStatus(app, stepNum) {
			if (!app) return "pending";
			const s = (app.status || "").toLowerCase();
			if (s === "rejected" || s === "revoked") return "rejected";
			if (stepNum === 1) {
				if (["visitor", "concessionaire"].includes(app.role)) return "done";
				if ([
					"dept_validated",
					"osa_val",
					"osa_validated",
					"security_checked",
					"sticker_released",
					"sticker_installed",
					"approved",
					"distributed",
					"completed",
					"expired"
				].includes(s) || app.dept_val_at) return "done";
				if (s === "dept_val" || s === "pending") return "active";
				return "pending";
			}
			if (stepNum === 2) {
				if ([
					"osa_validated",
					"security_checked",
					"sticker_released",
					"sticker_installed",
					"approved",
					"distributed",
					"completed",
					"expired"
				].includes(s) || app.osa_val_at || app.schedule || app.dist_sched) return "done";
				if (s === "dept_validated" || s === "osa_val" || ["visitor", "concessionaire"].includes(app.role) && s === "pending") return "active";
				return "pending";
			}
			if (stepNum === 3) {
				if (app.osa_dist_at || [
					"distributed",
					"security_checked",
					"sticker_released",
					"sticker_installed",
					"approved",
					"completed",
					"expired"
				].includes(s)) return "done";
				if (["osa_validated"].includes(s)) return "active";
				return "pending";
			}
			if (stepNum === 4) {
				if (app.security_check_at || app.security_checked_at || [
					"security_checked",
					"sticker_released",
					"sticker_installed",
					"completed",
					"approved",
					"expired"
				].includes(s)) return "done";
				if (s === "distributed" || app.osa_dist_at) return "active";
				return "pending";
			}
			if (stepNum === 5) {
				if (app.sticker_released_at || [
					"sticker_released",
					"sticker_installed",
					"completed",
					"approved"
				].includes(s)) return "done";
				if (s === "security_checked" || app.security_check_at || app.security_checked_at) return "active";
				return "pending";
			}
			if (stepNum === 6) {
				if (app.sticker_installed_at || ["sticker_installed", "approved"].includes(s)) return "done";
				if (s === "sticker_released" || s === "completed" || app.sticker_released_at) return "active";
				return "pending";
			}
			return "pending";
		}
		head("1xd49a3", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Application Status — GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Track the status of your vehicle sticker application at Liceo de Cagayan University." class="svelte-1xd49a3"/>`);
		});
		AppShell($$renderer, {
			userRole: "applicant",
			userEmail: data.userEmail,
			showSidebar: false,
			children: ($$renderer) => {
				$$renderer.push(`<div class="welcome-banner svelte-1xd49a3"><div class="wb-content svelte-1xd49a3"><h1 class="wb-title svelte-1xd49a3">Welcome to GateQR!</h1> <p class="wb-sub svelte-1xd49a3">Track your vehicle sticker application status in real-time.</p></div> <div class="wb-icon-shield svelte-1xd49a3"><svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1.75" class="svelte-1xd49a3"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" class="svelte-1xd49a3"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4" class="svelte-1xd49a3"></path></svg></div></div> `);
				if (app()) {
					$$renderer.push("<!--[0-->");
					if (app().status === "rejected" || app().status === "revoked") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="alert-box alert-error svelte-1xd49a3"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1xd49a3"><circle cx="12" cy="12" r="10" class="svelte-1xd49a3"></circle><line x1="12" y1="8" x2="12" y2="12" class="svelte-1xd49a3"></line><line x1="12" y1="16" x2="12.01" y2="16" class="svelte-1xd49a3"></line></svg> <div class="svelte-1xd49a3"><p class="alert-title svelte-1xd49a3">Application ${escape_html(app().status)}</p> <p class="alert-desc svelte-1xd49a3">${escape_html(app().invalid_reason || "No reason provided.")}</p></div></div> <a href="/" class="btn-reapply svelte-1xd49a3"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-1xd49a3"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" class="svelte-1xd49a3"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" class="svelte-1xd49a3"></path></svg> Submit New Application</a>`);
					} else if (app().status === "expired" || app().expires_at && new Date(app().expires_at).getTime() < Date.now()) {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`<div class="alert-box alert-warning svelte-1xd49a3"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1xd49a3"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" class="svelte-1xd49a3"></path><line x1="12" y1="9" x2="12" y2="13" class="svelte-1xd49a3"></line><line x1="12" y1="17" x2="12.01" y2="17" class="svelte-1xd49a3"></line></svg> <div class="svelte-1xd49a3"><p class="alert-title svelte-1xd49a3">Sticker Expired</p> <p class="alert-desc svelte-1xd49a3">Your parking sticker has expired${escape_html(app().expires_at ? ` on ${new Date(app().expires_at).toLocaleDateString("en-US", {
							month: "short",
							day: "2-digit",
							year: "numeric"
						})}` : "")}. Please renew your registration for the new School Year.</p></div></div> `);
						if (data.applicationOpen === false) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="alert-box alert-closed svelte-1xd49a3" style="margin-top: 1rem; background: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px; padding: 1rem; display: flex; align-items: flex-start; gap: 0.75rem;"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#be123c" stroke-width="2" class="svelte-1xd49a3"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" class="svelte-1xd49a3"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4" class="svelte-1xd49a3"></path></svg> <div class="svelte-1xd49a3"><p style="font-weight: 600; color: #9f1239; margin: 0 0 0.25rem 0; font-size: 0.95rem;" class="svelte-1xd49a3">Applications are Currently Closed</p> <p style="color: #be123c; margin: 0; font-size: 0.85rem; line-height: 1.4;" class="svelte-1xd49a3">The Office of Student Affairs (OSA) has temporarily closed vehicle registrations and renewals. Please check back later or contact OSA.</p></div></div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<a href="/?renew=true" class="btn-renew svelte-1xd49a3" style="display: inline-flex; align-items: center; gap: 0.5rem; background: #7A1734; color: white; padding: 0.75rem 1.25rem; border-radius: 8px; font-weight: 600; font-size: 0.9rem; text-decoration: none; margin-top: 1rem; transition: background 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-1xd49a3"><polyline points="23 4 23 10 17 10" class="svelte-1xd49a3"></polyline><polyline points="1 20 1 14 7 14" class="svelte-1xd49a3"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" class="svelte-1xd49a3"></path></svg> Renew Registration</a>`);
						}
						$$renderer.push(`<!--]-->`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<div class="progress-steps svelte-1xd49a3">`);
						if (!skipDean()) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div${attr_class("progress-step svelte-1xd49a3", void 0, {
								"step-done": stepStatus(app(), 1) === "done",
								"step-active": stepStatus(app(), 1) === "active",
								"step-pending": stepStatus(app(), 1) === "pending"
							})}><div class="ps-icon svelte-1xd49a3">`);
							if (stepStatus(app(), 1) === "done") {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="svelte-1xd49a3"><polyline points="20 6 9 17 4 12" class="svelte-1xd49a3"></polyline></svg>`);
							} else {
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`1`);
							}
							$$renderer.push(`<!--]--></div> <div class="ps-info svelte-1xd49a3"><span class="ps-label svelte-1xd49a3">Step 1 — Department Head or Dean Approval</span> <span class="ps-desc svelte-1xd49a3">Wait for your Department Head or Dean to approve your Parking Agreement Form.</span></div></div> <div class="ps-connector svelte-1xd49a3"></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> <div${attr_class("progress-step svelte-1xd49a3", void 0, {
							"step-done": stepStatus(app(), 2) === "done",
							"step-active": stepStatus(app(), 2) === "active",
							"step-pending": stepStatus(app(), 2) === "pending"
						})}><div class="ps-icon svelte-1xd49a3">`);
						if (stepStatus(app(), 2) === "done") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="svelte-1xd49a3"><polyline points="20 6 9 17 4 12" class="svelte-1xd49a3"></polyline></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(skipDean() ? 1 : 2)}`);
						}
						$$renderer.push(`<!--]--></div> <div class="ps-info svelte-1xd49a3"><span class="ps-label svelte-1xd49a3">Step ${escape_html(skipDean() ? 1 : 2)} — OSA Application Review</span> <span class="ps-desc svelte-1xd49a3">Wait for the Office of Student Affairs (OSA) to review your application details and schedule your office visit.</span> `);
						if (app().dist_sched || app().schedule) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div${attr_class("sched-pill svelte-1xd49a3", void 0, { "sched-overdue": !app().osa_dist_at && new Date(app().dist_sched || app().schedule) < /* @__PURE__ */ new Date() })}>Schedule: ${escape_html(new Date(app().dist_sched || app().schedule).toLocaleString("en-US", {
								dateStyle: "medium",
								timeStyle: "short"
							}))} `);
							if (!app().osa_dist_at && new Date(app().dist_sched || app().schedule) < /* @__PURE__ */ new Date()) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<span style="color: #dc2626; font-weight: bold; margin-left: 0.5rem;" class="svelte-1xd49a3">(OVERDUE)</span>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div> <div class="ps-connector svelte-1xd49a3"></div> <div${attr_class("progress-step svelte-1xd49a3", void 0, {
							"step-done": stepStatus(app(), 3) === "done",
							"step-active": stepStatus(app(), 3) === "active",
							"step-pending": stepStatus(app(), 3) === "pending"
						})}><div class="ps-icon svelte-1xd49a3">`);
						if (stepStatus(app(), 3) === "done") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="svelte-1xd49a3"><polyline points="20 6 9 17 4 12" class="svelte-1xd49a3"></polyline></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(skipDean() ? 2 : 3)}`);
						}
						$$renderer.push(`<!--]--></div> <div class="ps-info svelte-1xd49a3"><span class="ps-label svelte-1xd49a3">Step ${escape_html(skipDean() ? 2 : 3)} — OSA Document Verification</span> <span class="ps-desc svelte-1xd49a3">Visit the OSA Office and present your physical documents for verification against the information and files you submitted online.</span> `);
						if (app().osa_dist_at) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="sched-pill sched-done svelte-1xd49a3">Checked by OSA: ${escape_html(new Date(app().osa_dist_at).toLocaleString("en-US", {
								dateStyle: "medium",
								timeStyle: "short"
							}))}</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div> <div class="ps-connector svelte-1xd49a3"></div> <div${attr_class("progress-step svelte-1xd49a3", void 0, {
							"step-done": stepStatus(app(), 4) === "done",
							"step-active": stepStatus(app(), 4) === "active",
							"step-pending": stepStatus(app(), 4) === "pending"
						})}><div class="ps-icon svelte-1xd49a3">`);
						if (stepStatus(app(), 4) === "done") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="svelte-1xd49a3"><polyline points="20 6 9 17 4 12" class="svelte-1xd49a3"></polyline></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(skipDean() ? 3 : 4)}`);
						}
						$$renderer.push(`<!--]--></div> <div class="ps-info svelte-1xd49a3"><span class="ps-label svelte-1xd49a3">Step ${escape_html(skipDean() ? 3 : 4)} — Safety and Security Verification</span> <span class="ps-desc svelte-1xd49a3">Visit the Safety and Security Office to have your physical documents inspected and verified.</span> `);
						if (app().security_checked_at) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="sched-pill sched-done svelte-1xd49a3">Checked by Security: ${escape_html(new Date(app().security_checked_at).toLocaleString("en-US", {
								dateStyle: "medium",
								timeStyle: "short"
							}))}</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div> <div class="ps-connector svelte-1xd49a3"></div> <div${attr_class("progress-step svelte-1xd49a3", void 0, {
							"step-done": stepStatus(app(), 5) === "done",
							"step-active": stepStatus(app(), 5) === "active",
							"step-pending": stepStatus(app(), 5) === "pending"
						})}><div class="ps-icon svelte-1xd49a3">`);
						if (stepStatus(app(), 5) === "done") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="svelte-1xd49a3"><polyline points="20 6 9 17 4 12" class="svelte-1xd49a3"></polyline></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(skipDean() ? 4 : 5)}`);
						}
						$$renderer.push(`<!--]--></div> <div class="ps-info svelte-1xd49a3"><span class="ps-label svelte-1xd49a3">Step ${escape_html(skipDean() ? 4 : 5)} — Final Review and Sticker Release</span> <span class="ps-desc svelte-1xd49a3">Return to the OSA Office for a review of the verification marks from Safety and Security. Settle the required payment at the Registrar's Office and claim your vehicle sticker.</span> `);
						if (app().sticker_released_at) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="sched-pill sched-done svelte-1xd49a3">Released by OSA: ${escape_html(new Date(app().sticker_released_at).toLocaleString("en-US", {
								dateStyle: "medium",
								timeStyle: "short"
							}))}</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div> <div class="ps-connector svelte-1xd49a3"></div> <div${attr_class("progress-step svelte-1xd49a3", void 0, {
							"step-done": stepStatus(app(), 6) === "done",
							"step-active": stepStatus(app(), 6) === "active",
							"step-pending": stepStatus(app(), 6) === "pending"
						})}><div class="ps-icon svelte-1xd49a3">`);
						if (stepStatus(app(), 6) === "done") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="svelte-1xd49a3"><polyline points="20 6 9 17 4 12" class="svelte-1xd49a3"></polyline></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1xd49a3"><path d="M9 11l3 3L22 4" class="svelte-1xd49a3"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" class="svelte-1xd49a3"></path></svg>`);
						}
						$$renderer.push(`<!--]--></div> <div class="ps-info svelte-1xd49a3"><span class="ps-label svelte-1xd49a3">Step ${escape_html(skipDean() ? 5 : 6)} — Vehicle Sticker Installation (Mandatory)</span> <span class="ps-desc svelte-1xd49a3">Proceed to the Safety and Security Office to have your vehicle sticker installed. This step is mandatory to complete your vehicle registration process.</span> `);
						if (app().sticker_installed_at) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="sched-pill sched-done svelte-1xd49a3">Installed: ${escape_html(new Date(app().sticker_installed_at).toLocaleString("en-US", {
								dateStyle: "medium",
								timeStyle: "short"
							}))} — Registration Completed</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div></div>`);
					}
					$$renderer.push(`<!--]--> `);
					ApplicationCard($$renderer, {
						data: {
							id: app().id || "-",
							name: `${app().first_name} ${app().last_name}`,
							role: app().role,
							email: data.userEmail,
							department: app().department_name || "-",
							"dept. email": app().department_email || "-",
							campus: app().campus || "-",
							"year level": app().role === "student" ? app().year_level || "-" : void 0,
							vehicle: app().vehicle_make,
							color: app().vehicle_color,
							plate: app().vehicle_plate,
							owner: app().is_owner ? "Yes" : "No",
							status: app().status,
							crd: app().created_at,
							sgn: app().dept_val_at,
							apv: app().osa_val_at,
							sch: app().dist_sched,
							exp: app().expires_at,
							dlv: app().osa_dist_at,
							rejection_reason: app().invalid_reason || null,
							documents: {
								id: app().doc_id,
								enrollment: app().doc_load,
								or: app().doc_or,
								cr: app().doc_cr,
								license: app().doc_license,
								letter: app().doc_letter
							}
						},
						showQR: false,
						tab: "status",
						showDocs: true
					});
					$$renderer.push(`<!----> `);
					if (app() && ([
						"completed",
						"approved",
						"sticker_installed",
						"Sticker_Installed"
					].includes(app().status) || app().sticker_installed_at || changeRequest())) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="change-request-section svelte-1xd49a3">`);
						if (changeRequest() && ["pending", "Pending"].includes(changeRequest().status)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="cr-status-box cr-status-pending svelte-1xd49a3"><div class="crs-icon svelte-1xd49a3"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1xd49a3"><circle cx="12" cy="12" r="10" class="svelte-1xd49a3"></circle><polyline points="12 6 12 12 16 14" class="svelte-1xd49a3"></polyline></svg></div> <div class="crs-content svelte-1xd49a3"><strong class="svelte-1xd49a3">Pending Request to Change Registration Details</strong> <p class="svelte-1xd49a3">Your request to change registration details to <em class="svelte-1xd49a3">${escape_html(changeRequest().new_vehicle?.brand || "")} (${escape_html(changeRequest().new_vehicle?.plate_number || "")})</em> is currently under review by OSA.</p> <div class="crs-reason svelte-1xd49a3">Reason: "${escape_html(changeRequest().reason)}"</div></div></div>`);
						} else if (changeRequest() && [
							"approved",
							"Approved",
							"in_progress"
						].includes(changeRequest().status)) {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<div class="cr-status-box cr-status-approved svelte-1xd49a3"><div class="crs-icon svelte-1xd49a3"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1xd49a3"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" class="svelte-1xd49a3"></path><polyline points="22 4 12 14.01 9 11.01" class="svelte-1xd49a3"></polyline></svg></div> <div class="crs-content svelte-1xd49a3"><strong class="svelte-1xd49a3">Request to Change Vehicle Accepted!</strong> `);
							if (app().status === "approved" && app().sticker_released_at) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<p class="svelte-1xd49a3">Your request to change vehicle has been finalized and your new vehicle is now officially registered.</p>`);
							} else if (app().dist_sched || app().schedule) {
								$$renderer.push("<!--[1-->");
								$$renderer.push(`<p class="svelte-1xd49a3">Your request has been accepted! Please visit the OSA Office on <strong class="svelte-1xd49a3">${escape_html(new Date(app().dist_sched || app().schedule).toLocaleString("en-US", {
									dateStyle: "full",
									timeStyle: "short"
								}))}</strong> to comply with your hard copy requirements for your new vehicle.</p> <div class="crs-sched svelte-1xd49a3">Scheduled Visit for Hardcopy Compliance: <strong class="svelte-1xd49a3">${escape_html(new Date(app().dist_sched || app().schedule).toLocaleString("en-US", {
									dateStyle: "full",
									timeStyle: "short"
								}))}</strong></div>`);
							} else {
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`<p class="svelte-1xd49a3">Your request has been accepted! Please visit the OSA Office at your scheduled date and time to comply with your hard copy requirements for your new vehicle.</p>`);
							}
							$$renderer.push(`<!--]--></div></div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<div class="cr-action-bar svelte-1xd49a3"><div class="cr-action-info svelte-1xd49a3"><h4 class="svelte-1xd49a3">Need to change your registration details?</h4> <p class="svelte-1xd49a3">Submit a request with your new vehicle details and reason to update your registration.</p></div> <button class="btn-change-vehicle svelte-1xd49a3"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-1xd49a3"><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5" class="svelte-1xd49a3"></path></svg> Request to Change Registration Details</button></div>`);
						}
						$$renderer.push(`<!--]--></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="no-app svelte-1xd49a3"><p class="svelte-1xd49a3">You have not submitted a vehicle application yet.</p> <a href="/" class="btn-apply svelte-1xd49a3">Submit Application</a></div>`);
				}
				$$renderer.push(`<!--]--> <p class="form-footer svelte-1xd49a3">Issues? Contact <a href="mailto:osa@liceo.edu.ph" class="footer-link svelte-1xd49a3">osa@liceo.edu.ph</a></p>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
