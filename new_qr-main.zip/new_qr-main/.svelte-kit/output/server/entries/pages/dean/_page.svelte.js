import { C as attr, a as head, i as ensure_array_like, r as derived, w as escape_html } from "../../../chunks/server.js";
import { t as AppShell } from "../../../chunks/AppShell.js";
import "../../../chunks/navigation.js";
import "../../../chunks/liveSync.js";
//#region src/routes/dean/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let applicationsState = data.applications || [];
		let apps = derived(() => applicationsState);
		let searchQuery = "";
		let approvingId = null;
		let pendingApps = derived(() => apps().filter((a) => ["dept_val", "pending"].includes((a.status || "").toLowerCase())));
		let currentTabApps = derived(pendingApps);
		let displayedApps = derived(() => {
			return currentTabApps();
		});
		head("8bmigh", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>${escape_html(data.departmentType === "administrative" ? "Administrative Department Review" : "Dean Review")} — GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Review and approve vehicle sticker applications for your department."/>`);
		});
		AppShell($$renderer, {
			userEmail: data.userEmail,
			userRole: data.departmentType === "administrative" ? "administrative" : "dean",
			showSidebar: true,
			children: ($$renderer) => {
				$$renderer.push(`<div class="welcome-banner svelte-8bmigh"><div class="wb-content svelte-8bmigh"><div class="wb-badge svelte-8bmigh">${escape_html(data.departmentType === "administrative" ? "ADMINISTRATIVE DEPARTMENT REVIEW PORTAL" : "DEAN REVIEW PORTAL")} • ${escape_html(data.departmentName || (data.departmentType === "administrative" ? "ADMINISTRATIVE DEPARTMENT" : "ACADEMIC DEPARTMENT"))}</div> <h1 class="wb-title svelte-8bmigh">${escape_html(data.departmentType === "administrative" ? "Welcome back, Department Head!" : "Welcome back, Dean!")}</h1> <p class="wb-sub svelte-8bmigh">Review and verify department vehicle registration applications${escape_html(data.departmentName ? ` for ${data.departmentName}` : "")} today.</p></div> <div class="wb-icon-shield svelte-8bmigh"><svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1.75"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg></div></div> <div class="controls-row svelte-8bmigh"><div class="search-wrap svelte-8bmigh"><svg class="search-icon svelte-8bmigh" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg> <input type="text" placeholder="Search applicant name, email, or department…"${attr("value", searchQuery)} class="search-input svelte-8bmigh"/> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div> <div class="cards-list svelte-8bmigh">`);
				const each_array = ensure_array_like(displayedApps());
				if (each_array.length !== 0) {
					$$renderer.push("<!--[-->");
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let app = each_array[$$index];
						const appId = app.registration_id || app.id;
						const applicantName = `${app.first_name || ""} ${app.last_name || ""}`.trim() || "Unnamed Applicant";
						const applicantEmail = app.user_email || app.email || app.user?.email || "No email provided";
						const deptName = app.department_name || app.department?.department_name || app.department?.department || data.departmentName || "Department";
						const isApproving = approvingId === appId;
						const isPending = ["dept_val", "pending"].includes((app.status || "").toLowerCase());
						$$renderer.push(`<div class="dean-app-card svelte-8bmigh"><div class="card-left-section svelte-8bmigh"><div class="applicant-avatar svelte-8bmigh" aria-hidden="true">${escape_html(applicantName.charAt(0).toUpperCase())}</div> <div class="applicant-info svelte-8bmigh"><div class="applicant-name-row svelte-8bmigh"><h3 class="applicant-name svelte-8bmigh">${escape_html(applicantName)}</h3> <span class="agreement-badge svelte-8bmigh"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-8bmigh"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg> Agreement Form to Park</span></div> <div class="applicant-meta-grid svelte-8bmigh"><div class="meta-field svelte-8bmigh"><span class="meta-label svelte-8bmigh">Email:</span> <span class="meta-value svelte-8bmigh">${escape_html(applicantEmail)}</span></div> <div class="meta-field svelte-8bmigh"><span class="meta-label svelte-8bmigh">Department:</span> <span class="meta-value svelte-8bmigh">${escape_html(deptName)}</span></div></div></div></div> <div class="card-action-section svelte-8bmigh">`);
						if (isPending) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button type="button" class="btn-dean-approve svelte-8bmigh"${attr("disabled", isApproving || false, true)}>`);
							if (isApproving) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<svg class="btn-spinner svelte-8bmigh" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2.5" stroke-dasharray="35 15" stroke-linecap="round"></circle></svg> <span>Approving…</span>`);
							} else {
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> <span>Approve</span>`);
							}
							$$renderer.push(`<!--]--></button>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<span class="badge-status-approved svelte-8bmigh"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> ${escape_html(app.status === "dept_validated" ? "Validated by Dean" : app.status === "approved" ? "Approved & Registered" : app.status === "completed" ? "Completed" : app.status === "rejected" ? "Rejected" : app.status)}</span>`);
						}
						$$renderer.push(`<!--]--></div></div>`);
					}
				} else {
					$$renderer.push("<!--[!-->");
					$$renderer.push(`<div class="empty-state-box svelte-8bmigh"><div class="empty-icon-circle svelte-8bmigh"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><path d="M9 13l2 2 4-4"></path></svg></div> <h3 class="svelte-8bmigh">${escape_html("No pending agreement forms to park")}</h3> <p class="svelte-8bmigh">`);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`All department applications have been reviewed. New applicant submissions will appear here automatically.`);
					$$renderer.push(`<!--]--></p> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
