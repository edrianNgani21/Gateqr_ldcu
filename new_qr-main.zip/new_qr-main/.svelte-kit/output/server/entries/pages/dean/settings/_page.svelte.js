import "../../../../chunks/server.js";
import { t as AdminSettingsView } from "../../../../chunks/AdminSettingsView.js";
//#region src/routes/dean/settings/+page.svelte
function _page($$renderer, $$props) {
	let { data } = $$props;
	AdminSettingsView($$renderer, {
		data,
		userRole: "dean",
		showSidebar: true,
		pageTitle: "Settings",
		roleLabel: "Academic Department Head"
	});
}
//#endregion
export { _page as default };
