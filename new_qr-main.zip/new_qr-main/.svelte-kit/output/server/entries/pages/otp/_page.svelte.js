import "../../../chunks/internal.js";
import { C as attr, a as head, l as unsubscribe_stores, w as escape_html } from "../../../chunks/server.js";
import "../../../chunks/client.js";
import "../../../chunks/stores.js";
import "../../../chunks/navigation.js";
//#region src/routes/otp/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let email = "";
		let otp = "";
		let loading = false;
		let resending = false;
		head("n0uzqm", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Verify Email — GateQR | Liceo de Cagayan University</title>`);
			});
			$$renderer.push(`<meta name="description" content="Verify your applicant email address with a 6-digit OTP code to continue your vehicle sticker application." class="svelte-n0uzqm"/>`);
		});
		$$renderer.push(`<div class="otp-page svelte-n0uzqm"><div class="bg-glow svelte-n0uzqm"></div> <div class="bg-image svelte-n0uzqm"></div> <div class="bg-overlay svelte-n0uzqm"></div> <div class="otp-card svelte-n0uzqm"><div class="envelope-icon svelte-n0uzqm"><svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svelte-n0uzqm"><rect x="2" y="4" width="20" height="16" rx="2" class="svelte-n0uzqm"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" class="svelte-n0uzqm"></path></svg></div> <div class="header-text svelte-n0uzqm"><span class="sub-badge svelte-n0uzqm">APPLICANT VERIFICATION</span> <h1 class="otp-title svelte-n0uzqm">Verify Your Email</h1> <p class="otp-main svelte-n0uzqm">We sent a 6-digit verification code to <span class="user-email svelte-n0uzqm">${escape_html(email)}</span> to confirm your email is active.</p></div> <form class="otp-form svelte-n0uzqm">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="field-group svelte-n0uzqm"><label for="otp-input" class="input-label svelte-n0uzqm">Enter 6-Digit Code</label> <input id="otp-input" type="text" inputmode="numeric" pattern="[0-9]*"${attr("value", otp)} placeholder="••••••" maxlength="6" required="" class="otp-input svelte-n0uzqm"${attr("disabled", loading, true)} autocomplete="one-time-code" autofocus=""/> <span class="helper-text svelte-n0uzqm">Code expires in 5 minutes</span></div> <button type="submit" class="verify-btn svelte-n0uzqm"${attr("disabled", true, true)}>`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<span class="svelte-n0uzqm">Verify &amp; Continue</span> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-n0uzqm"><path d="M5 12h14M12 5l7 7-7 7" class="svelte-n0uzqm"></path></svg>`);
		$$renderer.push(`<!--]--></button></form> <div class="resend-section svelte-n0uzqm"><p class="resend-text svelte-n0uzqm">Didn't receive the verification email?</p> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<button type="button" class="resend-btn svelte-n0uzqm"${attr("disabled", resending, true)}>${escape_html("Resend Verification Code")}</button>`);
		$$renderer.push(`<!--]--></div> <div class="card-footer svelte-n0uzqm"><a href="/login" class="back-link svelte-n0uzqm"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="svelte-n0uzqm"><path d="M19 12H5M12 19l-7-7 7-7" class="svelte-n0uzqm"></path></svg> <span class="svelte-n0uzqm">Change Email / Back to Sign In</span></a></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
export { _page as default };
