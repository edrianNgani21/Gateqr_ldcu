import { redirect } from "@sveltejs/kit";
//#region src/routes/osa/admin/manage/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "osa") throw redirect(303, "/login");
	try {
		const res = await fetch("http://localhost:5173/api/osa/admin");
		if (res.ok) return {
			users: (await res.json()).users || [],
			userEmail: locals.user.email
		};
		return {
			users: [],
			userEmail: locals.user.email
		};
	} catch (error) {
		console.error("Error loading admin users:", error);
		return {
			users: [],
			userEmail: locals.user.email
		};
	}
};
//#endregion
export { load };
