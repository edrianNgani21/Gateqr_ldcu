import { a as head, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/navigation.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/osa/deans/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let deans = derived(() => data.deans);
		let userEmail = derived(() => data.userEmail);
		let filteredDeans = derived(() => {
			return deans();
		});
		function getDepartmentName(departmentId) {
			if (!departmentId) return "";
			const dept = data.departments.find((d) => d.department_id === departmentId);
			return dept ? dept.department_name || dept.department || "" : "";
		}
		head("ndv3t4", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Dean Management — OSA | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Manage dean accounts and department assignments for GateQR."/>`);
		});
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: userEmail(),
			children: ($$renderer) => {
				NavBar($$renderer, {
					title: "Dean Management",
					links: []
				});
				$$renderer.push(`<!----> <div class="deans-container svelte-ndv3t4"><div class="page-header svelte-ndv3t4"><div class="header-content svelte-ndv3t4"><h1 class="svelte-ndv3t4">Dean Management</h1> <p class="header-subtitle svelte-ndv3t4">Create dean accounts and assign them to departments</p></div> <div class="header-actions svelte-ndv3t4"><a href="/osa/departments" class="secondary-button svelte-ndv3t4"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg> Department Management</a> <button class="primary-button svelte-ndv3t4"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg> Add Dean</button></div></div> <div class="status-filter svelte-ndv3t4"><button${attr_class(`filter-tab active`, "svelte-ndv3t4")}>All Deans</button> <button${attr_class(`filter-tab `, "svelte-ndv3t4")}>Assigned</button> <button${attr_class(`filter-tab `, "svelte-ndv3t4")}>Unassigned</button></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="deans-grid svelte-ndv3t4"><!--[-->`);
				const each_array_1 = ensure_array_like(filteredDeans());
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let dean = each_array_1[$$index_1];
					$$renderer.push(`<div class="dean-card svelte-ndv3t4"><div class="card-header svelte-ndv3t4"><div class="dean-icon svelte-ndv3t4"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div> <div class="dean-info svelte-ndv3t4"><h3 class="svelte-ndv3t4">${escape_html(dean.email)}</h3> <p class="svelte-ndv3t4">${escape_html(dean.department_id ? getDepartmentName(dean.department_id) : "Unassigned")}</p></div> <div${attr_class(`status-badge ${dean.department_id ? "assigned" : "unassigned"}`, "svelte-ndv3t4")}>${escape_html(dean.department_id ? "✓ Assigned" : "○ Unassigned")}</div></div> <div class="card-body svelte-ndv3t4"><div class="info-row svelte-ndv3t4"><span class="label svelte-ndv3t4">Status</span> <span class="value svelte-ndv3t4">${escape_html(dean.department_id ? `🟢 ${getDepartmentName(dean.department_id)}` : "⚪ No Department")}</span></div> <div class="info-row svelte-ndv3t4"><span class="label svelte-ndv3t4">Created</span> <span class="value svelte-ndv3t4">${escape_html(new Date(dean.created_at).toLocaleDateString())}</span></div></div> <div class="card-footer svelte-ndv3t4"><button class="action-button edit-button svelte-ndv3t4"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg> Edit</button> <button class="action-button delete-button svelte-ndv3t4"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6"></path><path d="M14 11v6"></path><path d="M9 6V4h6v2"></path></svg> Delete</button></div></div>`);
				}
				$$renderer.push(`<!--]--></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
