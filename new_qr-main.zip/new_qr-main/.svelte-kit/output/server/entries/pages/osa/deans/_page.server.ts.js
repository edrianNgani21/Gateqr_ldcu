import { t as supabase } from "../../../../chunks/supabase.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/osa/deans/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "osa") throw redirect(303, "/login");
	try {
		const { data: deanRows } = await supabase.from("users").select("*").or("identification.eq.faculty,user_type.eq.dean").order("created_at", { ascending: false });
		const deans = (deanRows || []).map((dean) => ({
			user_id: dean.user_id,
			email: dean.email,
			department_id: dean.department_id,
			created_at: dean.created_at
		}));
		const { data: deptRows } = await supabase.from("department").select("*").order("department_id", { ascending: true });
		return {
			deans,
			departments: (deptRows || []).map((dept) => {
				const name = dept.academic_department || dept.administrative_department || dept.department_name || "Department";
				return {
					department_id: dept.department_id,
					department: name,
					department_name: name,
					is_active: dept.is_active ?? true
				};
			}),
			userEmail: locals.user.email
		};
	} catch (error) {
		console.error("Error loading deans:", error);
		return {
			deans: [],
			departments: [],
			userEmail: locals.user.email
		};
	}
};
//#endregion
export { load };
