import { a as head, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/navigation.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/osa/departments/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let departments = derived(() => data.departments);
		let userEmail = derived(() => data.userEmail);
		let showForm = false;
		let statusFilter = "active";
		let filteredAcademicDepartments = derived(() => {
			return departments().filter((d) => d.type === "academic").filter((dept) => dept.is_active);
		});
		let filteredAdministrativeDepartments = derived(() => {
			return departments().filter((d) => d.type === "administrative").filter((dept) => dept.is_active);
		});
		head("1a9kyfm", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Departments — OSA | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Manage college departments and administrative offices for GateQR."/>`);
		});
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: userEmail(),
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Departments" });
				$$renderer.push(`<!----> <div class="departments-container svelte-1a9kyfm"><div class="page-header svelte-1a9kyfm" style="justify-content: flex-end;"><div class="header-actions svelte-1a9kyfm"><button type="button"${attr_class("dept-header-btn svelte-1a9kyfm", void 0, { "active": showForm })}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg> Academic Department</button> <button type="button"${attr_class("dept-header-btn svelte-1a9kyfm", void 0, { "active": showForm })}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg> Administrative Department</button></div></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="table-controls-row svelte-1a9kyfm"><div class="table-type-selector svelte-1a9kyfm"><button type="button"${attr_class("type-toggle-btn svelte-1a9kyfm", void 0, { "active": true })}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg> Academic Department <span class="count-pill svelte-1a9kyfm">${escape_html(filteredAcademicDepartments().length)}</span></button> <button type="button"${attr_class("type-toggle-btn svelte-1a9kyfm", void 0, { "active": false })}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg> Administrative Department <span class="count-pill svelte-1a9kyfm">${escape_html(filteredAdministrativeDepartments().length)}</span></button></div> <div class="status-filter svelte-1a9kyfm"><button type="button"${attr_class(`filter-tab active`, "svelte-1a9kyfm")}>Active</button> <button type="button"${attr_class(`filter-tab `, "svelte-1a9kyfm")}>Inactive</button></div></div> `);
				{
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="course-list-section svelte-1a9kyfm"><div class="section-title-row svelte-1a9kyfm"><h2 class="svelte-1a9kyfm">Academic Department List</h2> <span class="count-badge svelte-1a9kyfm">${escape_html(filteredAcademicDepartments().length)}</span></div> <div class="course-list-items svelte-1a9kyfm"><!--[-->`);
					const each_array = ensure_array_like(filteredAcademicDepartments());
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let dept = each_array[$$index];
						$$renderer.push(`<div class="course-list-item svelte-1a9kyfm"><span class="course-name svelte-1a9kyfm">${escape_html(dept.name)}</span> <div class="course-actions svelte-1a9kyfm"><span${attr_class(`course-status-badge ${dept.is_active ? "active" : "inactive"}`, "svelte-1a9kyfm")}>${escape_html(dept.is_active ? "🟢 Active" : "⚪ Inactive")}</span> <button class="course-action-btn edit-btn svelte-1a9kyfm">Edit</button> `);
						if (dept.is_active) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button class="course-action-btn hide-btn svelte-1a9kyfm">Hide</button>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<button class="course-action-btn activate-btn svelte-1a9kyfm">Activate</button>`);
						}
						$$renderer.push(`<!--]--></div></div>`);
					}
					$$renderer.push(`<!--]--> `);
					if (filteredAcademicDepartments().length === 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<p class="no-courses svelte-1a9kyfm">No academic departments found (${escape_html(statusFilter)}).</p>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
