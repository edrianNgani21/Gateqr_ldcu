import { C as attr, c as stringify, i as ensure_array_like, n as attr_style, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/navigation.js";
import "../../../../chunks/liveSync.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/osa/dashboard/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		derived(() => data.stats || {
			totalApplications: 0,
			pendingValidation: 0,
			pendingDistribution: 0,
			completedToday: 0,
			rejectedToday: 0,
			totalDepartments: 0
		});
		let statusBreakdown = derived(() => data.statusBreakdown || {
			pending: 0,
			dept_val: 0,
			osa_val: 0,
			distributed: 0,
			completed: 0,
			rejected: 0,
			revoked: 0
		});
		const groupedStatus = derived(() => {
			const raw = statusBreakdown() || {};
			let pending = 0;
			let completed = 0;
			let rejected = 0;
			for (const [stKey, countVal] of Object.entries(raw)) {
				const k = stKey.toLowerCase();
				const count = Number(countVal) || 0;
				if ([
					"completed",
					"approved",
					"sticker_installed"
				].includes(k)) completed += count;
				else if (["rejected", "revoked"].includes(k)) rejected += count;
				else pending += count;
			}
			const total = pending + completed + rejected;
			const pendingPct = total > 0 ? pending / total * 100 : 0;
			const completedPct = total > 0 ? completed / total * 100 : 0;
			const rejectedPct = total > 0 ? rejected / total * 100 : 0;
			return {
				pending,
				completed,
				rejected,
				total,
				pendingPct,
				completedPct,
				rejectedPct,
				pendingPctFormatted: pendingPct % 1 === 0 ? pendingPct.toFixed(0) : pendingPct.toFixed(1),
				completedPctFormatted: completedPct % 1 === 0 ? completedPct.toFixed(0) : completedPct.toFixed(1),
				rejectedPctFormatted: rejectedPct % 1 === 0 ? rejectedPct.toFixed(0) : rejectedPct.toFixed(1)
			};
		});
		let recentApplications = derived(() => data.recentApplications || []);
		const statusLabels = {
			pending: "Pending",
			dept_val: "Dept Validated",
			dept_validated: "Dept Validated",
			osa_val: "OSA Validated",
			osa_validated: "OSA Validated",
			security_checked: "Security Checked",
			Sticker_Released: "Sticker Released",
			sticker_released: "Sticker Released",
			Sticker_Installed: "Sticker Installed",
			sticker_installed: "Sticker Installed",
			completed: "Completed",
			approved: "Approved",
			rejected: "Rejected",
			expired: "Expired",
			revoked: "Revoked",
			distributed: "Distributed"
		};
		derived(() => Math.max(...Object.values(statusBreakdown()), 1));
		let formOpen = data.applicationOpen !== false;
		data.formStatus?.updatedByEmail;
		let formSaving = false;
		AppShell($$renderer, {
			userEmail: data.userEmail,
			showSidebar: true,
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Office of Student Affairs Dashboard" });
				$$renderer.push(`<!----> <div class="dashboard-container svelte-12i94od"><div class="welcome-banner svelte-12i94od"><div class="wb-content svelte-12i94od"><h1 class="wb-title svelte-12i94od">Welcome back, Admin!</h1> <p class="wb-sub svelte-12i94od">Here's what's happening with GateQR vehicle sticker operations today.</p></div> <div class="wb-icon-shield svelte-12i94od"><svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1.75"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg></div></div> <div${attr_class("form-control-bar svelte-12i94od", void 0, { "is-closed": !formOpen })}><div class="form-control-info svelte-12i94od"><span class="form-status-dot svelte-12i94od"></span> <div><div class="form-control-title svelte-12i94od">Application Form: ${escape_html(formOpen ? "Open" : "Closed")}</div> <div class="form-control-desc svelte-12i94od">${escape_html(formOpen ? "Applicants can access and submit the application form." : "Applicants cannot access the Application form.")}</div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div> <button${attr_class("form-toggle-btn svelte-12i94od", void 0, { "close": formOpen })}${attr("disabled", formSaving, true)}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`${escape_html(formOpen ? "Close Application" : "Open Application")}`);
				$$renderer.push(`<!--]--></button></div> <div class="dashboard-grid svelte-12i94od"><div class="breakdown-section svelte-12i94od"><div class="section-header svelte-12i94od"><div class="section-title-wrap svelte-12i94od"><h2 class="svelte-12i94od">Application Status</h2> <span class="section-total-badge svelte-12i94od">Total Applications: <strong class="svelte-12i94od">${escape_html(groupedStatus().total)}</strong></span></div></div> <div class="diagram-container svelte-12i94od"><div class="donut-chart-box svelte-12i94od"><svg class="donut-svg svelte-12i94od" viewBox="0 0 140 140"><circle cx="70" cy="70" r="54" fill="none" stroke="#f1f5f9" stroke-width="12"></circle>`);
				if (groupedStatus().total > 0) {
					$$renderer.push("<!--[0-->");
					if (groupedStatus().pending > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<circle cx="70" cy="70" r="54" fill="none" stroke="#f59e0b" stroke-width="12"${attr("stroke-dasharray", `${stringify(groupedStatus().pendingPct / 100 * 339.29)} 339.29`)} stroke-dashoffset="0" class="donut-segment svelte-12i94od"></circle>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
					if (groupedStatus().completed > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<circle cx="70" cy="70" r="54" fill="none" stroke="#10b981" stroke-width="12"${attr("stroke-dasharray", `${stringify(groupedStatus().completedPct / 100 * 339.29)} 339.29`)}${attr("stroke-dashoffset", `-${stringify(groupedStatus().pendingPct / 100 * 339.29)}`)} class="donut-segment svelte-12i94od"></circle>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
					if (groupedStatus().rejected > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<circle cx="70" cy="70" r="54" fill="none" stroke="#ef4444" stroke-width="12"${attr("stroke-dasharray", `${stringify(groupedStatus().rejectedPct / 100 * 339.29)} 339.29`)}${attr("stroke-dashoffset", `-${stringify((groupedStatus().pendingPct + groupedStatus().completedPct) / 100 * 339.29)}`)} class="donut-segment svelte-12i94od"></circle>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></svg> <div class="donut-center-text svelte-12i94od"><span class="donut-total svelte-12i94od">${escape_html(groupedStatus().total)}</span> <span class="donut-sub svelte-12i94od">Total</span></div></div> <div class="status-legend-cards svelte-12i94od"><div class="legend-card legend-pending svelte-12i94od"><div class="legend-top svelte-12i94od"><div class="legend-title-row svelte-12i94od"><span class="indicator-dot dot-pending svelte-12i94od"></span> <span class="legend-title svelte-12i94od">Pending</span></div> <div class="legend-stats svelte-12i94od"><span class="legend-pct pct-pending svelte-12i94od">${escape_html(groupedStatus().pendingPctFormatted)}%</span> <span class="legend-count svelte-12i94od">(${escape_html(groupedStatus().pending)})</span></div></div> <div class="legend-progress-bar svelte-12i94od"><div class="progress-fill fill-pending svelte-12i94od"${attr_style(`width: ${stringify(groupedStatus().pendingPct)}%`)}></div></div></div> <div class="legend-card legend-completed svelte-12i94od"><div class="legend-top svelte-12i94od"><div class="legend-title-row svelte-12i94od"><span class="indicator-dot dot-completed svelte-12i94od"></span> <span class="legend-title svelte-12i94od">Completed</span></div> <div class="legend-stats svelte-12i94od"><span class="legend-pct pct-completed svelte-12i94od">${escape_html(groupedStatus().completedPctFormatted)}%</span> <span class="legend-count svelte-12i94od">(${escape_html(groupedStatus().completed)})</span></div></div> <div class="legend-progress-bar svelte-12i94od"><div class="progress-fill fill-completed svelte-12i94od"${attr_style(`width: ${stringify(groupedStatus().completedPct)}%`)}></div></div></div> <div class="legend-card legend-rejected svelte-12i94od"><div class="legend-top svelte-12i94od"><div class="legend-title-row svelte-12i94od"><span class="indicator-dot dot-rejected svelte-12i94od"></span> <span class="legend-title svelte-12i94od">Rejected</span></div> <div class="legend-stats svelte-12i94od"><span class="legend-pct pct-rejected svelte-12i94od">${escape_html(groupedStatus().rejectedPctFormatted)}%</span> <span class="legend-count svelte-12i94od">(${escape_html(groupedStatus().rejected)})</span></div></div> <div class="legend-progress-bar svelte-12i94od"><div class="progress-fill fill-rejected svelte-12i94od"${attr_style(`width: ${stringify(groupedStatus().rejectedPct)}%`)}></div></div></div></div></div> <div class="stacked-ratio-track svelte-12i94od"${attr("title", `Overall Distribution: ${stringify(groupedStatus().pendingPctFormatted)}% Pending | ${stringify(groupedStatus().completedPctFormatted)}% Completed | ${stringify(groupedStatus().rejectedPctFormatted)}% Rejected`)}>`);
				if (groupedStatus().pending > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="ratio-segment ratio-pending svelte-12i94od"${attr_style(`width: ${stringify(groupedStatus().pendingPct)}%`)}></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (groupedStatus().completed > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="ratio-segment ratio-completed svelte-12i94od"${attr_style(`width: ${stringify(groupedStatus().completedPct)}%`)}></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (groupedStatus().rejected > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="ratio-segment ratio-rejected svelte-12i94od"${attr_style(`width: ${stringify(groupedStatus().rejectedPct)}%`)}></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (groupedStatus().total === 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="ratio-segment ratio-empty svelte-12i94od" style="width: 100%"></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div> <div class="recent-section svelte-12i94od"><div class="section-header svelte-12i94od"><h2 class="svelte-12i94od">Recent Activity</h2> <span class="section-badge">Latest</span></div> `);
				if (recentApplications().length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="recent-list svelte-12i94od"><!--[-->`);
					const each_array = ensure_array_like(recentApplications());
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let app = each_array[$$index];
						$$renderer.push(`<div class="recent-item svelte-12i94od"><div class="recent-info svelte-12i94od"><div class="recent-email svelte-12i94od">${escape_html(app.user?.email || "Unknown")}</div> <div class="recent-dept svelte-12i94od">${escape_html(app.department?.department || app.department?.department_name || "No Department")}</div></div> <div${attr_class("recent-status svelte-12i94od", void 0, {
							"status-pending": app.status === "pending",
							"status-dept_val": app.status === "dept_val",
							"status-osa_val": app.status === "osa_val",
							"status-distributed": app.status === "distributed",
							"status-completed": app.status === "completed",
							"status-rejected": app.status === "rejected",
							"status-revoked": app.status === "revoked"
						})}>${escape_html(statusLabels[app.status] || app.status)}</div></div>`);
					}
					$$renderer.push(`<!--]--></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="no-data svelte-12i94od"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="svelte-12i94od"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg> <p class="svelte-12i94od">No recent applications</p></div>`);
				}
				$$renderer.push(`<!--]--></div></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
