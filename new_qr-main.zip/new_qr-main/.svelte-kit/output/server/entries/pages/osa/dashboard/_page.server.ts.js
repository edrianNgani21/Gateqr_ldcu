import { t as supabase } from "../../../../chunks/supabase.js";
import { t as getApplicationFormStatus } from "../../../../chunks/applicationForm.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/osa/dashboard/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "osa") throw redirect(303, "/login");
	const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
	const tomorrow = new Date(Date.now() + 864e5).toISOString().split("T")[0];
	const formStatus = await getApplicationFormStatus();
	try {
		const [totalApplicationsResult, pendingValidationResult, pendingDistributionResult, completedTodayResult, rejectedTodayResult, totalDepartmentsResult, statusBreakdownResult, recentApplicationsResult] = await Promise.all([
			supabase.from("registration").select("*", {
				count: "exact",
				head: true
			}),
			supabase.from("registration").select("*", {
				count: "exact",
				head: true
			}).in("status", [
				"pending",
				"dept_val",
				"dept_validated",
				"osa_val",
				"osa_validated"
			]),
			supabase.from("registration").select("*", {
				count: "exact",
				head: true
			}).in("status", [
				"distributed",
				"osa_validated",
				"security_checked"
			]).is("sticker_released_at", null),
			supabase.from("registration").select("*", {
				count: "exact",
				head: true
			}).in("status", ["approved", "completed"]),
			supabase.from("registration").select("*", {
				count: "exact",
				head: true
			}).eq("status", "rejected").gte("rejected_at", today).lt("rejected_at", tomorrow),
			supabase.from("department").select("*", {
				count: "exact",
				head: true
			}),
			supabase.from("registration").select("status").order("created_at", { ascending: false }),
			supabase.from("registration").select(`
                *,
                user:user_id(email),
                department:department_id(
                    department_id,
                    academic_department,
                    administrative_department
                )
            `).order("created_at", { ascending: false }).limit(5)
		]);
		const totalApplications = totalApplicationsResult?.count || 0;
		const pendingValidation = pendingValidationResult?.count || 0;
		const pendingDistribution = pendingDistributionResult?.count || 0;
		const completedToday = completedTodayResult?.count || 0;
		const rejectedToday = rejectedTodayResult?.count || 0;
		const totalDepartments = totalDepartmentsResult?.count || 0;
		const statusBreakdown = statusBreakdownResult?.data;
		const recentApplications = (recentApplicationsResult?.data || []).map((app) => ({
			...app,
			department: {
				...app.department,
				department_name: app.department?.academic_department || app.department?.administrative_department || "No Department"
			}
		}));
		const statusCounts = {
			pending: 0,
			dept_val: 0,
			dept_validated: 0,
			osa_val: 0,
			osa_validated: 0,
			security_checked: 0,
			approved: 0,
			distributed: 0,
			completed: 0,
			rejected: 0,
			revoked: 0
		};
		statusBreakdown?.forEach((app) => {
			if (statusCounts[app.status] !== void 0) statusCounts[app.status]++;
		});
		return {
			stats: {
				totalApplications,
				pendingValidation,
				pendingDistribution,
				completedToday,
				rejectedToday,
				totalDepartments
			},
			statusBreakdown: statusCounts,
			recentApplications: recentApplications || [],
			applicationOpen: formStatus.open,
			formStatus,
			userEmail: locals.user.email
		};
	} catch (e) {
		console.error("Failed to load OSA dashboard data:", e);
		return {
			stats: {
				totalApplications: 0,
				pendingValidation: 0,
				pendingDistribution: 0,
				completedToday: 0,
				rejectedToday: 0,
				totalDepartments: 0
			},
			statusBreakdown: {
				pending: 0,
				dept_val: 0,
				osa_val: 0,
				distributed: 0,
				completed: 0,
				rejected: 0,
				revoked: 0
			},
			recentApplications: [],
			applicationOpen: formStatus.open,
			formStatus,
			userEmail: locals.user.email
		};
	}
};
//#endregion
export { load };
