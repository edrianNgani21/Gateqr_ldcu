import { C as attr, a as head, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/navigation.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/osa/change-requests/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let requests = derived(() => data.requests || []);
		let searchQuery = "";
		let counts = derived(() => {
			return {
				all: requests().length,
				pending: requests().filter((r) => (r.status || "").toLowerCase() === "pending").length,
				approved: requests().filter((r) => ["approved", "completed"].includes((r.status || "").toLowerCase())).length,
				rejected: requests().filter((r) => (r.status || "").toLowerCase() === "rejected").length
			};
		});
		let displayedRequests = derived(() => {
			let list = requests();
			list = list.filter((r) => {
				return (r.status || "").toLowerCase() === "pending";
			});
			if (searchQuery.trim());
			return list;
		});
		function formatDateTime(str) {
			if (!str) return "—";
			const d = new Date(str);
			if (isNaN(d.getTime())) return "—";
			return d.toLocaleString("en-US", {
				month: "short",
				day: "numeric",
				year: "numeric",
				hour: "numeric",
				minute: "2-digit",
				hour12: true
			});
		}
		head("1wrmy7c", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Profile Update Requests — OSA | GateQR</title>`);
			});
		});
		AppShell($$renderer, {
			userEmail: data.userEmail,
			showSidebar: true,
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Profile Update Requests" });
				$$renderer.push(`<!----> <div class="page-container svelte-1wrmy7c"><div class="info-header svelte-1wrmy7c"><div class="ih-text"><h2 class="svelte-1wrmy7c">Profile Update Requests</h2> <p class="svelte-1wrmy7c">Review registered applicants requesting to update their profile, registration, and vehicle details. Accepting a request will schedule them for document submission and seamlessly move the application into the <strong>Manage Applications</strong> system flow.</p></div></div> <div class="stats-row svelte-1wrmy7c"><div${attr_class("stat-card svelte-1wrmy7c", void 0, { "active-card": true })} role="button" tabindex="0"><div class="sc-icon pending-icon svelte-1wrmy7c"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></div> <div class="sc-content"><div class="sc-count svelte-1wrmy7c">${escape_html(counts().pending)}</div> <div class="sc-label svelte-1wrmy7c">Pending Requests</div></div></div> <div${attr_class("stat-card svelte-1wrmy7c", void 0, { "active-card": false })} role="button" tabindex="0"><div class="sc-icon approved-icon svelte-1wrmy7c"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></div> <div class="sc-content"><div class="sc-count svelte-1wrmy7c">${escape_html(counts().approved)}</div> <div class="sc-label svelte-1wrmy7c">Accepted &amp; Scheduled</div></div></div> <div${attr_class("stat-card svelte-1wrmy7c", void 0, { "active-card": false })} role="button" tabindex="0"><div class="sc-icon rejected-icon svelte-1wrmy7c"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></div> <div class="sc-content"><div class="sc-count svelte-1wrmy7c">${escape_html(counts().rejected)}</div> <div class="sc-label svelte-1wrmy7c">Rejected Requests</div></div></div> <div${attr_class("stat-card svelte-1wrmy7c", void 0, { "active-card": false })} role="button" tabindex="0"><div class="sc-icon all-icon svelte-1wrmy7c"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg></div> <div class="sc-content"><div class="sc-count svelte-1wrmy7c">${escape_html(counts().all)}</div> <div class="sc-label svelte-1wrmy7c">All Requests</div></div></div></div> <div class="controls-bar svelte-1wrmy7c"><div class="search-box svelte-1wrmy7c"><svg class="search-icon svelte-1wrmy7c" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg> <input type="text" placeholder="Search by applicant name, plate number, or reason..."${attr("value", searchQuery)} class="svelte-1wrmy7c"/> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <div class="filter-tabs svelte-1wrmy7c"><button${attr_class("filter-tab svelte-1wrmy7c", void 0, { "active": true })}>Pending (${escape_html(counts().pending)})</button> <button${attr_class("filter-tab svelte-1wrmy7c", void 0, { "active": false })}>Accepted (${escape_html(counts().approved)})</button> <button${attr_class("filter-tab svelte-1wrmy7c", void 0, { "active": false })}>Rejected (${escape_html(counts().rejected)})</button> <button${attr_class("filter-tab svelte-1wrmy7c", void 0, { "active": false })}>All (${escape_html(counts().all)})</button></div></div> `);
				if (displayedRequests().length === 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="empty-state svelte-1wrmy7c"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"></path></svg> <h3 class="svelte-1wrmy7c">No Registration Change Requests Found</h3> <p>There are no change requests matching the selected filter.</p></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="requests-grid svelte-1wrmy7c"><!--[-->`);
					const each_array = ensure_array_like(displayedRequests());
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let req = each_array[$$index];
						$$renderer.push(`<div${attr_class("request-card svelte-1wrmy7c", void 0, { "is-pending": (req.status || "").toLowerCase() === "pending" })}><div class="rc-header svelte-1wrmy7c"><div class="rc-user-info svelte-1wrmy7c"><div class="rc-avatar svelte-1wrmy7c">${escape_html((req.applicant.name || "?").slice(0, 2).toUpperCase())}</div> <div><h3 class="applicant-name svelte-1wrmy7c">${escape_html(req.applicant.name)}</h3> <div class="applicant-meta svelte-1wrmy7c"><span class="role-tag svelte-1wrmy7c">${escape_html(req.applicant.role)}</span> <span class="meta-item svelte-1wrmy7c">${escape_html(req.applicant.email)}</span> `);
						if (req.applicant.department && req.applicant.department !== "-") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="meta-item svelte-1wrmy7c">${escape_html(req.applicant.department)}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (req.applicant.campus && req.applicant.campus !== "-") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="campus-tag svelte-1wrmy7c">${escape_html(req.applicant.campus)}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div></div> <div class="rc-status-box svelte-1wrmy7c">`);
						if ((req.status || "").toLowerCase() === "pending") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="status-badge badge-pending svelte-1wrmy7c">Pending Review</span>`);
						} else if (["approved", "completed"].includes((req.status || "").toLowerCase())) {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<span class="status-badge badge-approved svelte-1wrmy7c">Accepted &amp; Scheduled</span>`);
						} else if ((req.status || "").toLowerCase() === "rejected") {
							$$renderer.push("<!--[2-->");
							$$renderer.push(`<span class="status-badge badge-rejected svelte-1wrmy7c">Rejected</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> <span class="req-date svelte-1wrmy7c">Requested: ${escape_html(formatDateTime(req.requested_at))}</span></div></div> <div class="reason-banner svelte-1wrmy7c"><div class="rb-title svelte-1wrmy7c"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg> <span>Applicant's Reason for Registration Change:</span></div> <div class="rb-content svelte-1wrmy7c">"${escape_html(req.reason)}"</div></div> <div class="vehicle-comparison svelte-1wrmy7c"><div class="veh-box current-veh svelte-1wrmy7c"><div class="vb-header svelte-1wrmy7c"><span class="vb-tag old-tag svelte-1wrmy7c">CURRENT VEHICLE</span> <span class="vb-plate svelte-1wrmy7c">${escape_html(req.current_vehicle.plate_number)}</span></div> <div class="vb-details svelte-1wrmy7c"><div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Make / Model:</span> <span class="vbd-val svelte-1wrmy7c">${escape_html(req.current_vehicle.brand)}</span></div> <div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Color:</span> <span class="vbd-val svelte-1wrmy7c">${escape_html(req.current_vehicle.color)}</span></div> <div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Vehicle Type:</span> <span class="vbd-val svelte-1wrmy7c">${escape_html(req.current_vehicle.type)}</span></div></div></div> <div class="comparison-arrow svelte-1wrmy7c"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></div> <div class="veh-box new-veh svelte-1wrmy7c"><div class="vb-header svelte-1wrmy7c"><span class="vb-tag new-tag svelte-1wrmy7c">REQUESTED NEW VEHICLE</span> <span class="vb-plate highlight-plate svelte-1wrmy7c">${escape_html(req.new_vehicle.plate_number)}</span></div> <div class="vb-details svelte-1wrmy7c"><div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Make / Model:</span> <span class="vbd-val font-bold svelte-1wrmy7c">${escape_html(req.new_vehicle.brand)}</span></div> <div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Color:</span> <span class="vbd-val svelte-1wrmy7c">${escape_html(req.new_vehicle.color)}</span></div> <div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Vehicle Type:</span> <span class="vbd-val svelte-1wrmy7c">${escape_html(req.new_vehicle.type)}</span></div> <div class="vbd-item svelte-1wrmy7c"><span class="vbd-label svelte-1wrmy7c">Owner:</span> <span class="vbd-val svelte-1wrmy7c">${escape_html(req.new_vehicle.is_owner ? "Yes (Registered Owner)" : "No (Authorized)")}</span></div></div></div></div> <div class="documents-section svelte-1wrmy7c"><span class="docs-title svelte-1wrmy7c">Submitted Documents for New Vehicle:</span> <div class="docs-list svelte-1wrmy7c">`);
						if (req.new_vehicle.doc_or) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button class="doc-btn svelte-1wrmy7c">📄 Official Receipt (OR)</button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (req.new_vehicle.doc_cr) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button class="doc-btn svelte-1wrmy7c">📄 Cert. of Reg (CR)</button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (req.new_vehicle.doc_letter) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button class="doc-btn svelte-1wrmy7c">✉️ Authorization Letter</button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (!req.new_vehicle.doc_or && !req.new_vehicle.doc_cr && !req.new_vehicle.doc_letter) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="no-docs svelte-1wrmy7c">No new document uploads provided.</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div> <div class="rc-actions svelte-1wrmy7c">`);
						if ((req.status || "").toLowerCase() === "pending") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="action-buttons svelte-1wrmy7c"><button class="btn-reject svelte-1wrmy7c"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg> Reject Request</button> <button class="btn-accept svelte-1wrmy7c"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Accept &amp; Schedule for Hardcopy Compliance</button></div>`);
						} else if (["approved", "completed"].includes((req.status || "").toLowerCase())) {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<div class="approved-notice svelte-1wrmy7c"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> <span>Accepted and scheduled for Hardcopy Compliance: <strong>${escape_html(formatDateTime(req.applicant.dist_sched))}</strong>. This application is active in <strong>Manage Applications</strong>.</span> <a href="/osa" class="btn-view-manage svelte-1wrmy7c">View in Manage Applications →</a></div>`);
						} else if ((req.status || "").toLowerCase() === "rejected") {
							$$renderer.push("<!--[2-->");
							$$renderer.push(`<div class="rejected-notice svelte-1wrmy7c"><span>This registration details change request was rejected on ${escape_html(formatDateTime(req.processed_at))}.</span></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div>`);
					}
					$$renderer.push(`<!--]--></div>`);
				}
				$$renderer.push(`<!--]--></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
