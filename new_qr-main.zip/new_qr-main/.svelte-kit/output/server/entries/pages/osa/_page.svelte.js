import { C as attr, a as head, i as ensure_array_like, l as unsubscribe_stores, r as derived, t as attr_class, w as escape_html } from "../../../chunks/server.js";
import { n as invalidateAll } from "../../../chunks/client.js";
import "../../../chunks/stores.js";
import { t as AppShell } from "../../../chunks/AppShell.js";
import "../../../chunks/navigation.js";
import "../../../chunks/liveSync.js";
import { t as NavBar } from "../../../chunks/NavBar.js";
import { t as ApplicationCard } from "../../../chunks/ApplicationCard.js";
import { t as ActionBar } from "../../../chunks/ActionBar.js";
//#region src/routes/osa/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data } = $$props;
		let apps = derived(() => data.applications || []);
		let tab = "validation";
		const tabLabels = {
			"validation": "Screening of Applications",
			"distribution": "Submission of Documents",
			"release": "Sticker Releasing",
			"registered": "Registered Vehicles",
			"rejected": "Rejected or Revoked Accounts & Applications"
		};
		function isAppOverdue(a) {
			if (a.invalid_reason === "OVERDUE" || a.rejection_reason === "OVERDUE") return true;
			const s = a.schedule || a.dist_sched;
			if (!s) return false;
			return new Date(s).getTime() < Date.now();
		}
		function getAppsForTab(t) {
			if (t === "validation") return apps().filter((a) => [
				"pending",
				"dept_val",
				"dept_validated",
				"osa_val"
			].includes((a.status || "").toLowerCase()));
			if (t === "distribution") return apps().filter((a) => ["distributed", "osa_validated"].includes((a.status || "").toLowerCase()) && !a.sticker_released_at && (!a.security_check_at || !a.osa_dist_at));
			if (t === "overdue") return apps().filter((a) => ["distributed", "osa_validated"].includes((a.status || "").toLowerCase()) && !a.osa_dist_at && isAppOverdue(a));
			if (t === "release") return apps().filter((a) => [
				"distributed",
				"osa_validated",
				"security_checked"
			].includes((a.status || "").toLowerCase()) && (a.security_check_at || a.security_checked_at) && !a.sticker_released_at || (a.status || "").toLowerCase() === "security_checked" && !a.sticker_released_at);
			if (t === "registered") return apps().filter((a) => ["completed", "approved"].includes((a.status || "").toLowerCase()));
			if (t === "rejected" || t === "revoked") return apps().filter((a) => ["rejected", "revoked"].includes((a.status || "").toLowerCase()));
			return [];
		}
		let searchQuery = "";
		let roleFilter = "all";
		let vehicleTypeFilter = "all";
		let selectedCampus = "all";
		let selectedApplicationIds = /* @__PURE__ */ new Set();
		function toggleSelection(id, selected) {
			if (selected) selectedApplicationIds = /* @__PURE__ */ new Set([...selectedApplicationIds, id]);
			else selectedApplicationIds = new Set([...selectedApplicationIds].filter((x) => x !== id));
		}
		let displayedApps = derived(() => {
			let filtered = getAppsForTab(tab);
			console.log("Filtered apps for tab", tab, ":", filtered.length, "out of", apps().length);
			console.log("All apps before filtering:", apps().map((a) => ({
				id: a.id,
				status: a.status,
				role: a.role,
				campus: a.campus
			})));
			return filtered;
		});
		derived(() => {
			return [];
		});
		derived(() => {
			return {
				validation: getAppsForTab("validation").length,
				distribution: getAppsForTab("distribution").length,
				release: getAppsForTab("release").length,
				registered: getAppsForTab("registered").length,
				rejected: getAppsForTab("rejected").length
			};
		});
		derived(() => getAppsForTab("distribution").filter((a) => !isAppOverdue(a)).length);
		derived(() => getAppsForTab("distribution").filter((a) => isAppOverdue(a)).length);
		derived(() => getAppsForTab("rejected").filter((a) => (a.status || "").toLowerCase() === "rejected").length);
		derived(() => getAppsForTab("rejected").filter((a) => (a.status || "").toLowerCase() === "revoked").length);
		let scheduleModalOpen = false;
		let pendingAction = null;
		let confirmLoading = false;
		let singleSchedule = "";
		let schoolYearVal = "2025-2026";
		let expiryDateVal = "2026-05-31";
		let reasonModalOpen = false;
		let reasonAction = null;
		let reasonText = "";
		let reasonError = "";
		let reasonLoading = false;
		async function handleAction(registration_id, action) {
			if (action === "accept" || action === "reschedule") return new Promise((resolve) => {
				pendingAction = {
					id: registration_id,
					action,
					resolve
				};
				scheduleModalOpen = true;
			});
			if (action === "reject" || action === "revoke") {
				const app = apps().find((a) => (a.registration_id || a.id) === registration_id);
				const applicantName = app ? `${app.first_name || ""} ${app.last_name || ""}`.trim() : "";
				return new Promise((resolve) => {
					reasonAction = {
						id: registration_id,
						action,
						applicantName,
						resolve
					};
					reasonText = "";
					reasonError = "";
					reasonModalOpen = true;
				});
			}
			let reason = "";
			if (action === "proceed_overdue") {
				if (!confirm(`Are you sure you want to proceed this application directly to Hardcopies Compliance?`)) return;
			} else if (action === "delete" || action === "unrevoke") {
				if (!confirm(`Are you sure you want to ${action} this application?`)) return;
			}
			await submitAction(registration_id, action, reason);
		}
		async function submitAction(registration_id, action, reason = "", schedule = "", school_year = "", expires_at = "") {
			try {
				const res = await fetch("/api/osa/applications", {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
						registration_id,
						action,
						reason,
						schedule,
						school_year,
						expires_at
					})
				});
				if (res.ok) await invalidateAll();
				else {
					const err = await res.json();
					alert(err.error || "Action failed");
				}
			} catch (e) {
				alert("Network error");
			}
		}
		head("lpdtii", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Applications — OSA | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Manage vehicle sticker applications at the Office of Student Affairs."/>`);
		});
		AppShell($$renderer, {
			userEmail: data.userEmail,
			showSidebar: true,
			children: ($$renderer) => {
				NavBar($$renderer, { title: tabLabels[tab] || "Manage Applications" });
				$$renderer.push(`<!----> <div class="applications-container svelte-lpdtii">`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="filters-section svelte-lpdtii"><div class="search-container svelte-lpdtii"><svg class="search-icon svelte-lpdtii" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg> <input type="text" placeholder="Search by name, plate, vehicle..."${attr("value", searchQuery)} class="search-input svelte-lpdtii"/> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <div class="filter-group svelte-lpdtii">`);
				$$renderer.select({
					value: roleFilter,
					class: "filter-btn"
				}, ($$renderer) => {
					$$renderer.option({ value: "all" }, ($$renderer) => {
						$$renderer.push(`All Roles`);
					});
					$$renderer.option({ value: "student" }, ($$renderer) => {
						$$renderer.push(`Student`);
					});
					$$renderer.option({ value: "faculty" }, ($$renderer) => {
						$$renderer.push(`Faculty`);
					});
					$$renderer.option({ value: "staff" }, ($$renderer) => {
						$$renderer.push(`Staff`);
					});
				}, "svelte-lpdtii");
				$$renderer.push(` `);
				$$renderer.select({
					value: vehicleTypeFilter,
					class: "filter-btn"
				}, ($$renderer) => {
					$$renderer.option({ value: "all" }, ($$renderer) => {
						$$renderer.push(`All Vehicles`);
					});
					$$renderer.option({ value: "2-Wheeler / Motorcycle" }, ($$renderer) => {
						$$renderer.push(`2-Wheelers`);
					});
					$$renderer.option({ value: "4-Wheeler / Car" }, ($$renderer) => {
						$$renderer.push(`4-Wheelers`);
					});
				}, "svelte-lpdtii");
				$$renderer.push(` `);
				$$renderer.select({
					value: selectedCampus,
					class: "filter-btn"
				}, ($$renderer) => {
					$$renderer.option({ value: "all" }, ($$renderer) => {
						$$renderer.push(`All Campuses`);
					});
					$$renderer.option({ value: "Liceo Main" }, ($$renderer) => {
						$$renderer.push(`Liceo Main`);
					});
					$$renderer.option({ value: "RNP" }, ($$renderer) => {
						$$renderer.push(`RNP`);
					});
					$$renderer.option({ value: "PASEO" }, ($$renderer) => {
						$$renderer.push(`PASEO`);
					});
				}, "svelte-lpdtii");
				$$renderer.push(`</div></div> <div class="content-layout svelte-lpdtii">`);
				{
					$$renderer.push("<!--[-1-->");
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <div${attr_class("applications-list svelte-lpdtii", void 0, { "right-panel": false })}>`);
					const each_array_1 = ensure_array_like(displayedApps());
					if (each_array_1.length !== 0) {
						$$renderer.push("<!--[-->");
						for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
							let app = each_array_1[$$index_1];
							$$renderer.push("<!--[-1-->");
							{
								function children($$renderer) {
									ActionBar($$renderer, {
										tab,
										status: app.status,
										expiresAt: app.expires_at,
										onaction: (action) => handleAction(app.id, action)
									});
								}
								ApplicationCard($$renderer, {
									data: {
										id: app.id || "-",
										name: `${app.first_name} ${app.last_name}`,
										"dean approval": (app.status || "").toLowerCase() === "pending" ? "Pending" : "Approved",
										role: app.role,
										campus: app.campus,
										"year level": app.year_level || "-",
										email: app.user_email,
										contact: app.mobile || app.contact_number,
										facebook: app.facebook || "-",
										department: app.department_name || "-",
										"dept. email": app.department_email || "-",
										vehicle: app.vehicle_make,
										color: app.vehicle_color,
										"vehicle type": app.vehicle_type,
										plate: app.vehicle_plate,
										owner: app.is_owner ? "Yes" : "No",
										status: app.status,
										crd: app.created_at,
										dpt: app.dept_val_at,
										osa: app.osa_val_at,
										sch: app.dist_sched,
										hdc: app.osa_dist_at,
										sec: app.security_checked_at,
										rel: app.sticker_released_at,
										ins: app.sticker_installed_at,
										exp: app.expires_at,
										change_vehicle_request: app.change_vehicle_request,
										is_change_vehicle: app.is_change_vehicle,
										rejection_reason: app.invalid_reason || null,
										qr_code: app.qr_code,
										qr_unique_code: app.qr_unique_code,
										documents: {
											id: app.doc_id,
											enrollment: app.doc_load,
											or: app.doc_or,
											cr: app.doc_cr,
											license: app.doc_license,
											letter: app.doc_letter
										}
									},
									selectable: true,
									selected: selectedApplicationIds.has(app.id),
									onselect: (selected) => toggleSelection(app.id, selected),
									showQR: true,
									tab,
									children,
									$$slots: { default: true }
								});
							}
							$$renderer.push(`<!--]-->`);
						}
					} else {
						$$renderer.push("<!--[!-->");
						$$renderer.push(`<div class="empty-state svelte-lpdtii"><svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="svelte-lpdtii"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg> <h3 class="svelte-lpdtii">No applications found</h3> <p class="svelte-lpdtii">There are no applications matching your current filters.</p> <button class="clear-filters-btn svelte-lpdtii">Clear all filters</button></div>`);
					}
					$$renderer.push(`<!--]--></div> `);
					if (selectedApplicationIds.size > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="selected-apps-table svelte-lpdtii"><div class="table-header svelte-lpdtii"><span class="table-title svelte-lpdtii">Selected Applications</span> <span class="table-count svelte-lpdtii">${escape_html(selectedApplicationIds.size)}</span></div> <table class="mini-table svelte-lpdtii"><thead class="svelte-lpdtii"><tr><th class="svelte-lpdtii">Email</th><th class="svelte-lpdtii">Department</th></tr></thead><tbody class="svelte-lpdtii"><!--[-->`);
						const each_array_2 = ensure_array_like(displayedApps().filter((app) => selectedApplicationIds.has(app.id)));
						for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
							let app = each_array_2[$$index_2];
							$$renderer.push(`<tr class="svelte-lpdtii"><td class="svelte-lpdtii">${escape_html(app.user_email)}</td><td class="svelte-lpdtii">${escape_html(app.department_name)}</td></tr>`);
						}
						$$renderer.push(`<!--]--></tbody></table> <div class="table-actions svelte-lpdtii"><button class="table-btn table-accept svelte-lpdtii">Accept All</button> <button class="table-btn table-reject svelte-lpdtii">Reject All</button></div></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></div></div> `);
				if (scheduleModalOpen) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="modal-overlay svelte-lpdtii" role="dialog" aria-modal="true" tabindex="-1"><div class="modal-content svelte-lpdtii"><h3 class="svelte-lpdtii">${escape_html(pendingAction?.action === "reschedule" ? "Reschedule OSA Visit" : "Accept & Schedule Application")}</h3> <p class="svelte-lpdtii">${escape_html(pendingAction?.action === "reschedule" ? "Set a new OSA visit schedule for hardcopy submission" : "Set an OSA visit schedule for hardcopy submission")}</p> <div class="schedule-form svelte-lpdtii"><div class="schedule-row svelte-lpdtii"><div class="schedule-field svelte-lpdtii"><label class="schedule-label svelte-lpdtii">SET SCHEDULE</label> <input type="datetime-local"${attr("value", singleSchedule)} class="sched-input svelte-lpdtii"${attr("disabled", confirmLoading, true)}/></div></div> <div class="schedule-row svelte-lpdtii" style="margin-top: 0.85rem; display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;"><div class="schedule-field svelte-lpdtii"><label class="schedule-label svelte-lpdtii">SCHOOL YEAR</label> <input type="text"${attr("value", schoolYearVal)} placeholder="e.g. 2025-2026" class="sched-input svelte-lpdtii"${attr("disabled", confirmLoading, true)}/></div> <div class="schedule-field svelte-lpdtii"><label class="schedule-label svelte-lpdtii">STICKER EXPIRY DATE</label> <input type="date"${attr("value", expiryDateVal)} class="sched-input svelte-lpdtii"${attr("disabled", confirmLoading, true)}/></div></div></div> <div class="modal-actions svelte-lpdtii"><button class="btn-cancel svelte-lpdtii"${attr("disabled", confirmLoading, true)}>Cancel</button> <button${attr_class("btn-confirm svelte-lpdtii", void 0, { "btn-confirming": confirmLoading })}${attr("disabled", confirmLoading, true)}>`);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`Confirm Schedule`);
					$$renderer.push(`<!--]--></button></div></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (reasonModalOpen && reasonAction) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="modal-overlay svelte-lpdtii" role="dialog" aria-modal="true" tabindex="-1"><div class="modal-content reason-modal-card svelte-lpdtii"><div class="reason-modal-header svelte-lpdtii"><div${attr_class("reason-badge-icon svelte-lpdtii", void 0, { "is-revoke": reasonAction.action === "revoke" })}><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">`);
					if (reasonAction.action === "revoke") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>`);
					}
					$$renderer.push(`<!--]--></svg></div> <div class="reason-header-text svelte-lpdtii"><h3 class="reason-title svelte-lpdtii">${escape_html(reasonAction.action === "revoke" ? "Revoke Application / Sticker" : "Reject Application")}</h3> `);
					if (reasonAction.applicantName) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="reason-applicant-badge svelte-lpdtii">${escape_html(reasonAction.applicantName)}</span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div> <button type="button" class="reason-close-btn svelte-lpdtii"${attr("disabled", reasonLoading, true)} aria-label="Close">✕</button></div> <p class="reason-subtitle svelte-lpdtii">${escape_html(reasonAction.action === "revoke" ? "Provide an official explanation for revoking this registered vehicle. This reason will be logged and visible in application records." : "Specify why this application is being rejected. This explanation will be displayed directly to the applicant on their status dashboard.")}</p> <div class="reason-presets-section svelte-lpdtii"><span class="presets-label svelte-lpdtii">QUICK TEMPLATES</span> <div class="presets-chips svelte-lpdtii">`);
					if (reasonAction.action === "revoke") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<button type="button" class="preset-chip svelte-lpdtii">Expired Registration</button> <button type="button" class="preset-chip svelte-lpdtii">Transfer Violation</button> <button type="button" class="preset-chip svelte-lpdtii">Traffic Violation</button> <button type="button" class="preset-chip svelte-lpdtii">OSA Order</button>`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<button type="button" class="preset-chip svelte-lpdtii">Incomplete Docs</button> <button type="button" class="preset-chip svelte-lpdtii">Expired OR/CR</button> <button type="button" class="preset-chip svelte-lpdtii">Unmatched Info</button> <button type="button" class="preset-chip svelte-lpdtii">Enrollment Mismatch</button>`);
					}
					$$renderer.push(`<!--]--></div></div> <div class="reason-input-group svelte-lpdtii"><label class="reason-input-label svelte-lpdtii" for="reason-textarea">Reason / Evaluation Remarks <span class="req svelte-lpdtii">*</span></label> <textarea id="reason-textarea" class="reason-textarea svelte-lpdtii"${attr("placeholder", reasonAction.action === "revoke" ? "State the specific reason for revoking this sticker..." : "State the specific reason for rejecting this application...")}${attr("disabled", reasonLoading, true)} rows="3">`);
					const $$body_1 = escape_html(reasonText);
					if ($$body_1) $$renderer.push(`${$$body_1}`);
					$$renderer.push(`</textarea></div> `);
					if (reasonError) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="reason-error-alert svelte-lpdtii"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg> <span>${escape_html(reasonError)}</span></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <div class="modal-actions reason-modal-actions svelte-lpdtii"><button type="button" class="btn-cancel svelte-lpdtii"${attr("disabled", reasonLoading, true)}>Cancel</button> <button type="button"${attr_class("btn-confirm-reason svelte-lpdtii", void 0, { "is-revoke": reasonAction.action === "revoke" })}${attr("disabled", reasonLoading, true)}>`);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span>${escape_html(reasonAction.action === "revoke" ? "Confirm Revocation" : "Confirm Rejection")}</span>`);
					$$renderer.push(`<!--]--></button></div></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
export { _page as default };
