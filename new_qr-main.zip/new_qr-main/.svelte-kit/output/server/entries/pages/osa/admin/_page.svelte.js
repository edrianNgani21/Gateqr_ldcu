import { C as attr, a as head, c as stringify, i as ensure_array_like, n as attr_style, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/osa/admin/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let admins = [];
		let loadingAdmins = false;
		const isPrimaryAdmin = derived(() => (data?.userEmail || "").trim().toLowerCase() === "aluban98304@liceo.edu.ph");
		const adminTypeCategories = [
			{
				key: "Office of Student Affairs",
				label: "Office of Student Affairs",
				badgeBg: "rgba(107, 26, 42, 0.1)",
				badgeColor: "#6b1a2a",
				icon: "osa"
			},
			{
				key: "Safety and Security",
				label: "Safety and Security",
				badgeBg: "rgba(30, 64, 175, 0.1)",
				badgeColor: "#1e40af",
				icon: "security"
			},
			{
				key: "Academic Department Head",
				label: "Academic Department Head",
				badgeBg: "rgba(21, 128, 61, 0.1)",
				badgeColor: "#15803d",
				icon: "academic"
			},
			{
				key: "Administrative Department",
				label: "Administrative Department",
				badgeBg: "rgba(180, 83, 9, 0.1)",
				badgeColor: "#b45309",
				icon: "administrative"
			}
		];
		function getAdminCategoryKey(admin) {
			const ut = (admin?.user_type || "").toLowerCase();
			const id = (admin?.identification || "").toLowerCase();
			const dept = admin?.department;
			const isAdminDept = id === "staff" || dept && (dept.administrative_department || dept["Administrative Department"]);
			if (ut === "osa") return "Office of Student Affairs";
			if (ut === "safety_security" || ut.includes("security")) return "Safety and Security";
			if (ut === "office head" || ut === "administrative") return "Administrative Department";
			if (ut === "academic head" || ut === "dean" || id === "faculty" || id === "staff") {
				if (isAdminDept) return "Administrative Department";
				return "Academic Department Head";
			}
			return "Office of Student Affairs";
		}
		function getDepartmentDisplay(admin) {
			return admin?.department?.academic_department || admin?.department?.["Academic Department"] || admin?.department?.administrative_department || admin?.department?.["Administrative Department"] || admin?.department?.department_name || "—";
		}
		head("lrquui", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Accounts — OSA | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Manage administrative and department head accounts in GateQR."/>`);
		});
		AppShell($$renderer, {
			userEmail: data.userEmail,
			showSidebar: true,
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Accounts" });
				$$renderer.push(`<!----> <div class="admin-container svelte-lrquui">`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (!isPrimaryAdmin()) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="restriction-notice-card svelte-lrquui"><div class="restriction-badge svelte-lrquui"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg> <span>RESTRICTED ACCESS</span></div> <h2 class="svelte-lrquui">Admin Management Restricted</h2> <p class="svelte-lrquui">Only the primary OSA administrator (<strong>aluban98304@liceo.edu.ph</strong>) is authorized to create, activate, deactivate, or delete administrator accounts. You have view-only access to the administrator directory below.</p></div>`);
				} else {
					$$renderer.push("<!--[1-->");
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <div class="empty-state-card svelte-lrquui"><div class="empty-icon svelte-lrquui"><svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg></div> <h2 class="svelte-lrquui">No Admin Creation in Progress</h2> <p class="svelte-lrquui">Click the button below to create a new admin account (4-digit PIN required)</p> <button class="primary-btn svelte-lrquui"${attr("disabled", true, true)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg> Add New Admin</button></div>`);
				}
				$$renderer.push(`<!--]--> <div class="admin-list-section svelte-lrquui"><div class="section-header svelte-lrquui"><h2 class="svelte-lrquui">Active Admin Accounts</h2> <button class="refresh-btn svelte-lrquui"${attr("disabled", loadingAdmins, true)}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6"></path><path d="M1 20v-6h6"></path><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg> Refresh</button></div> `);
				if (admins.length === 0) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<div class="empty-state svelte-lrquui"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="svelte-lrquui"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><line x1="23" y1="11" x2="17" y2="11"></line><line x1="20" y1="8" x2="20" y2="14"></line></svg> <p>No admin accounts found.</p></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="admin-type-sections svelte-lrquui"><!--[-->`);
					const each_array_3 = ensure_array_like(adminTypeCategories);
					for (let $$index_4 = 0, $$length = each_array_3.length; $$index_4 < $$length; $$index_4++) {
						let category = each_array_3[$$index_4];
						const groupAdmins = admins.filter((a) => getAdminCategoryKey(a) === category.key);
						$$renderer.push(`<div class="admin-type-section-card svelte-lrquui"><div class="admin-type-section-header svelte-lrquui"><div class="type-header-left svelte-lrquui"><span class="type-icon-bubble svelte-lrquui"${attr_style(`background: ${stringify(category.badgeBg)}; color: ${stringify(category.badgeColor)};`)}>`);
						if (category.key === "Office of Student Affairs") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`);
						} else if (category.key === "Safety and Security") {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`);
						} else if (category.key === "Academic Department Head") {
							$$renderer.push("<!--[2-->");
							$$renderer.push(`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>`);
						}
						$$renderer.push(`<!--]--></span> <h3 class="svelte-lrquui">${escape_html(category.label)}</h3> <span class="type-count-badge svelte-lrquui">${escape_html(groupAdmins.length)}</span></div></div> `);
						if (groupAdmins.length === 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="empty-category-row svelte-lrquui"><span>No accounts currently registered under ${escape_html(category.label)}.</span></div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							const hasDeptCol = category.key !== "Office of Student Affairs" && category.key !== "Safety and Security";
							$$renderer.push(`<div${attr_class("admin-row-table svelte-lrquui", void 0, { "no-dept": !hasDeptCol })}><div class="row-table-header svelte-lrquui"><span class="col-account svelte-lrquui">Account Email</span> `);
							if (hasDeptCol) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<span class="col-dept">Department / Affiliation</span>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> <span class="col-date">Date Created</span> <span class="col-status">Status</span> <span class="col-actions svelte-lrquui">Actions</span></div> <div class="row-table-body svelte-lrquui"><!--[-->`);
							const each_array_4 = ensure_array_like(groupAdmins);
							for (let $$index_3 = 0, $$length = each_array_4.length; $$index_3 < $$length; $$index_3++) {
								let admin = each_array_4[$$index_3];
								$$renderer.push(`<div class="admin-table-row svelte-lrquui"><div class="col-account svelte-lrquui"><div${attr_class("admin-avatar svelte-lrquui", void 0, {
									"active": admin.is_active,
									"inactive": !admin.is_active
								})}>${escape_html(admin.email.charAt(0).toUpperCase())}</div> <div class="account-meta svelte-lrquui"><span class="account-email svelte-lrquui"${attr("title", admin.email)}>${escape_html(admin.email)}</span></div></div> `);
								if (hasDeptCol) {
									$$renderer.push("<!--[0-->");
									$$renderer.push(`<div class="col-dept svelte-lrquui"><span class="dept-text svelte-lrquui">${escape_html(getDepartmentDisplay(admin))}</span></div>`);
								} else $$renderer.push("<!--[-1-->");
								$$renderer.push(`<!--]--> <div class="col-date svelte-lrquui"><span class="date-text svelte-lrquui">${escape_html(new Date(admin.created_at).toLocaleDateString())}</span></div> <div class="col-status svelte-lrquui"><span${attr_class("status-pill svelte-lrquui", void 0, {
									"active": admin.is_active,
									"inactive": !admin.is_active
								})}><span class="status-dot svelte-lrquui"></span> ${escape_html(admin.is_active ? "Active" : "Inactive")}</span></div> <div class="col-actions svelte-lrquui">`);
								if (isPrimaryAdmin()) {
									$$renderer.push("<!--[0-->");
									$$renderer.push(`<button${attr_class("row-action-btn toggle-btn svelte-lrquui", void 0, {
										"activate": !admin.is_active,
										"deactivate": admin.is_active
									})}${attr("title", admin.is_active ? "Deactivate account" : "Activate account")}>${escape_html(admin.is_active ? "Deactivate" : "Activate")}</button> <button class="row-action-btn delete-btn svelte-lrquui" title="Delete admin">Delete</button>`);
								} else {
									$$renderer.push("<!--[-1-->");
									$$renderer.push(`<span class="read-only-badge svelte-lrquui">View Only</span>`);
								}
								$$renderer.push(`<!--]--></div></div>`);
							}
							$$renderer.push(`<!--]--></div></div>`);
						}
						$$renderer.push(`<!--]--></div>`);
					}
					$$renderer.push(`<!--]--></div>`);
				}
				$$renderer.push(`<!--]--></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
