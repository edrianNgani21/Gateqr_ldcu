import { C as attr, a as head, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../../chunks/server.js";
import { n as invalidateAll } from "../../../chunks/client.js";
import { t as AppShell } from "../../../chunks/AppShell.js";
import "../../../chunks/navigation.js";
import "../../../chunks/liveSync.js";
import { t as NavBar } from "../../../chunks/NavBar.js";
import { t as ApplicationCard } from "../../../chunks/ApplicationCard.js";
import { t as ActionBar } from "../../../chunks/ActionBar.js";
//#region src/lib/components/TabBar.svelte
function TabBar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { tabs, active, counts = [], labels = {}, onchange } = $$props;
		$$renderer.push(`<div class="tab-bar svelte-1wwzsr0" role="tablist"><!--[-->`);
		const each_array = ensure_array_like(tabs);
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			let tab = each_array[i];
			$$renderer.push(`<button role="tab"${attr("aria-selected", active === tab)}${attr_class("tab-btn svelte-1wwzsr0", void 0, { "tab-active": active === tab })}><span class="tab-label">${escape_html(labels[tab] || tab)}</span> `);
			if (counts && counts[i] !== void 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="tab-badge-pill svelte-1wwzsr0">${escape_html(counts[i])}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></button>`);
		}
		$$renderer.push(`<!--]--></div>`);
	});
}
//#endregion
//#region src/routes/security/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let userRole = derived(() => data.userRole || "security");
		let tab = data.initialTab || "Document Review";
		function switchTab(newTab) {
			tab = newTab;
			if (typeof window !== "undefined") {
				const u = new URL(window.location.href);
				u.searchParams.set("tab", newTab);
				window.history.replaceState({}, "", u.toString());
			}
		}
		const tabs = [
			"Document Review",
			"Sticker Installation",
			"Registered Vehicles",
			"Rejected or Revoked Accounts & Applications"
		];
		const tabLabels = {
			"Document Review": "Document Review",
			"Sticker Installation": "Sticker Installation",
			"Registered Vehicles": "Registered Vehicles",
			"Rejected or Revoked Accounts & Applications": "Rejected or Revoked"
		};
		let vehicles = data.vehicles;
		function getAppsForTab(t) {
			if (t === "Document Review") return vehicles.filter((v) => ((v.status || "").toLowerCase() === "distributed" || v.osa_dist_at) && !v.security_check_at && !v.security_checked_at);
			if (t === "Sticker Installation") return vehicles.filter((v) => (v.status || "").toLowerCase() === "completed" || v.sticker_released_at && (v.status || "").toLowerCase() !== "approved");
			if (t === "Registered Vehicles" || t === "Registered") return vehicles.filter((v) => (v.status || "").toLowerCase() === "approved");
			if (t === "Rejected or Revoked Accounts & Applications" || t === "Revoked Registered") return vehicles.filter((v) => ["revoked", "rejected"].includes((v.status || "").toLowerCase()));
			return [];
		}
		let tabCounts = derived(() => [
			getAppsForTab("Document Review").length,
			getAppsForTab("Sticker Installation").length,
			getAppsForTab("Registered Vehicles").length,
			getAppsForTab("Rejected or Revoked Accounts & Applications").length
		]);
		let searchQuery = "";
		let roleFilter = "all";
		let vehicleTypeFilter = "all";
		data.stats.maxCapacity;
		let logs = [];
		let totalLogs = 0;
		let currentPage = 1;
		let totalPages = 1;
		const pageSize = 25;
		let loading = false;
		let selectedDate = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		let boundFilter = "all";
		let selectedCampus = "all";
		let selectedLogs = /* @__PURE__ */ new Set();
		const allRoles = [
			"student",
			"faculty",
			"staff",
			"administrator",
			"concessionaire",
			"supplier",
			"vps",
			"vip"
		];
		let selectedRoles = [];
		let roleDropdownOpen = false;
		function formatRoleLabel(role) {
			const lower = (role || "").toLowerCase();
			if (lower === "vps") return "VPS";
			if (lower === "vip") return "VIP";
			if (lower === "administrator") return "Administrator";
			if (lower === "concessionaire" || lower === "concecioonaire") return "Concessionaire";
			return role.charAt(0).toUpperCase() + role.slice(1);
		}
		function getRoleDropdownLabel() {
			if (selectedRoles.length === 0 || selectedRoles.length === allRoles.length) return "All Roles";
			if (selectedRoles.length === 1) return formatRoleLabel(selectedRoles[0]);
			return formatRoleLabel(selectedRoles[0]);
		}
		function toDocUrl(val) {
			if (!val || typeof val !== "string") return null;
			const trimmed = val.trim();
			if (trimmed.startsWith("/") || trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("data:")) return trimmed;
			return null;
		}
		derived(() => vehicles.filter((v) => {
			return ((v.first_name?.toLowerCase() || "").includes(searchQuery.toLowerCase()) || (v.last_name?.toLowerCase() || "").includes(searchQuery.toLowerCase()) || (v.vehicle_plate?.toLowerCase() || "").includes(searchQuery.toLowerCase()) || (v.id || "").toLowerCase().includes(searchQuery.toLowerCase())) && true;
		}));
		let displayedApps = derived(() => {
			let filtered = [...vehicles];
			if (tab === "Document Review") filtered = filtered.filter((v) => ((v.status || "").toLowerCase() === "distributed" || v.osa_dist_at) && !v.security_check_at && !v.security_checked_at);
			else if (tab === "Sticker Installation") filtered = filtered.filter((v) => (v.status || "").toLowerCase() === "completed" || v.sticker_released_at && (v.status || "").toLowerCase() !== "approved");
			else if (tab === "Registered Vehicles" || tab === "Registered") filtered = filtered.filter((v) => (v.status || "").toLowerCase() === "approved");
			else if (tab === "Rejected or Revoked Accounts & Applications" || tab === "Revoked Registered") filtered = filtered.filter((v) => ["revoked", "rejected"].includes((v.status || "").toLowerCase()));
			return filtered;
		});
		async function revokeQR(registrationId) {
			if (!confirm("Are you sure you want to revoke this QR code? The vehicle will be denied access.")) return;
			const previous = vehicles;
			vehicles = vehicles.map((v) => v.registration_id === registrationId ? {
				...v,
				status: "revoked"
			} : v);
			try {
				if ((await fetch(`/api/monitor/revoke`, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({ registration_id: registrationId })
				})).ok) invalidateAll();
				else {
					vehicles = previous;
					alert("Failed to revoke QR code.");
				}
			} catch (e) {
				vehicles = previous;
				console.error(e);
				alert("Error revoking QR code.");
			}
		}
		async function unrevokeQR(registrationId) {
			if (!confirm("Restore access for this vehicle? Their QR code will be reactivated.")) return;
			const previous = vehicles;
			vehicles = vehicles.map((v) => v.registration_id === registrationId ? {
				...v,
				status: "approved"
			} : v);
			try {
				if ((await fetch(`/api/monitor/revoke`, {
					method: "DELETE",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({ registration_id: registrationId })
				})).ok) invalidateAll();
				else {
					vehicles = previous;
					alert("Failed to restore QR code.");
				}
			} catch (e) {
				vehicles = previous;
				console.error(e);
				alert("Error restoring QR code.");
			}
		}
		async function deleteApp(registrationId) {
			if (!confirm("Are you sure you want to permanently delete this registration?")) return;
			const previous = vehicles;
			vehicles = vehicles.filter((v) => v.registration_id !== registrationId);
			try {
				if ((await fetch("/api/osa/applications", {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
						registration_id: registrationId,
						action: "delete"
					})
				})).ok) invalidateAll();
				else {
					vehicles = previous;
					alert("Failed to delete registration.");
				}
			} catch (e) {
				vehicles = previous;
				console.error(e);
				alert("Error deleting registration.");
			}
		}
		async function fetchLogs() {
			loading = true;
			try {
				const params = new URLSearchParams({
					date: selectedDate,
					search: searchQuery,
					bound: boundFilter,
					page: String(currentPage),
					limit: String(pageSize)
				});
				if (selectedRoles.length > 0) params.append("roles", selectedRoles.join(","));
				const res = await fetch(`/api/gate/logs?${params}`);
				if (res.ok) {
					const json = await res.json();
					logs = json.logs;
					totalLogs = json.total;
					currentPage = json.page;
					totalPages = json.totalPages;
				}
			} catch (e) {
				console.error(e);
			}
			loading = false;
		}
		let installationSearch = "";
		let installationLoading = null;
		let installationVehicles = derived(() => vehicles.filter((v) => v.status === "completed" && v.sticker_released_at && !v.sticker_installed_at));
		let filteredInstallationVehicles = derived(() => installationVehicles().filter((v) => {
			return true;
		}));
		head("4rm2pb", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Application Review — Security | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Security vehicle monitoring dashboard for Liceo de Cagayan University." class="svelte-4rm2pb"/>`);
		});
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: data.userEmail,
			userRole: userRole(),
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Application Review" });
				$$renderer.push(`<!----> `);
				TabBar($$renderer, {
					tabs,
					active: tab,
					counts: tabCounts(),
					labels: tabLabels,
					onchange: switchTab
				});
				$$renderer.push(`<!----> `);
				if (tab === "Document Review" || tab === "Sticker Installation" || tab === "Registered" || tab === "Registered Vehicles" || tab === "Revoked Registered" || tab === "Rejected or Revoked Accounts & Applications") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="controls-row svelte-4rm2pb"><div class="search-wrap svelte-4rm2pb"><svg class="search-icon svelte-4rm2pb" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8" class="svelte-4rm2pb"></circle><path d="m21 21-4.35-4.35" class="svelte-4rm2pb"></path></svg> <input type="text" placeholder="Search name, plate, vehicle…"${attr("value", searchQuery)} class="search-input svelte-4rm2pb"/> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div> <div class="filters svelte-4rm2pb">`);
					$$renderer.select({
						value: roleFilter,
						class: "filter-select"
					}, ($$renderer) => {
						$$renderer.option({
							value: "all",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`All Roles`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "student",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Student`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "faculty",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Faculty`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "staff",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Staff`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "administrator",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Administrator`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "concessionaire",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Concessionaire`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "supplier",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Supplier`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "vps",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`VPS`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "vip",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`VIP`);
						}, "svelte-4rm2pb");
					}, "svelte-4rm2pb");
					$$renderer.push(` `);
					$$renderer.select({
						value: vehicleTypeFilter,
						class: "filter-select"
					}, ($$renderer) => {
						$$renderer.option({
							value: "all",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`All Vehicles`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "2-Wheeler / Motorcycle",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`2-Wheelers`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "4-Wheeler / Car",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`4-Wheelers`);
						}, "svelte-4rm2pb");
					}, "svelte-4rm2pb");
					$$renderer.push(` `);
					$$renderer.select({
						value: selectedCampus,
						class: "filter-select"
					}, ($$renderer) => {
						$$renderer.option({
							value: "all",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`All Campuses`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "Liceo Main",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Liceo Main`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "RNP",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`RNP`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "PASEO",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`PASEO`);
						}, "svelte-4rm2pb");
					}, "svelte-4rm2pb");
					$$renderer.push(`</div></div> <div class="cards-list svelte-4rm2pb">`);
					const each_array = ensure_array_like(displayedApps());
					if (each_array.length !== 0) {
						$$renderer.push("<!--[-->");
						for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
							let app = each_array[$$index];
							{
								function children($$renderer) {
									ActionBar($$renderer, {
										tab,
										status: app.status,
										expiresAt: app.expires_at,
										onaction: async (action, schedule) => {
											if (action === "revoke") await revokeQR(app.registration_id);
											else if (action === "unrevoke") await unrevokeQR(app.registration_id);
											else if (action === "delete") await deleteApp(app.registration_id);
											else if (action === "security_check" || action === "install_sticker") {
												const previousVehicles = vehicles;
												if (action === "security_check") vehicles = vehicles.map((v) => v.registration_id === app.registration_id ? {
													...v,
													security_check_at: (/* @__PURE__ */ new Date()).toISOString(),
													security_checked_at: (/* @__PURE__ */ new Date()).toISOString(),
													status: "security_checked"
												} : v);
												else if (action === "install_sticker") vehicles = vehicles.map((v) => v.registration_id === app.registration_id ? {
													...v,
													sticker_installed_at: (/* @__PURE__ */ new Date()).toISOString(),
													status: "approved"
												} : v);
												try {
													const res = await fetch(`/api/monitor/actions`, {
														method: "POST",
														headers: { "Content-Type": "application/json" },
														body: JSON.stringify({
															vehicle_id: app.registration_id,
															action
														})
													});
													if (res.ok) invalidateAll();
													else {
														vehicles = previousVehicles;
														const errData = await res.json();
														alert(errData.error || "Failed to perform action.");
													}
												} catch (e) {
													vehicles = previousVehicles;
													alert("Error performing action.");
												}
											}
										}
									});
								}
								ApplicationCard($$renderer, {
									showDocs: true,
									data: {
										id: app.registration_id || "-",
										name: `${app.first_name} ${app.last_name}`,
										role: app.role,
										campus: app.campus || "-",
										"year level": app.year_level || "-",
										email: app.user_email || "-",
										contact: app.mobile || "-",
										department: app.department_name || "-",
										"dept. email": app.department_email || "-",
										vehicle: app.vehicle_information?.brand || "-",
										"vehicle type": app.vehicle_information?.type || "-",
										color: app.vehicle_information?.color || "-",
										plate: app.vehicle_information?.plate_number || "-",
										owner: app.is_owner ? "Yes" : "No",
										status: app.status,
										"dean status": app.dept_val_at ? "Approved" : app.status === "rejected" ? "Rejected" : app.status === "dept_val" ? "Pending" : "N/A",
										crd: app.created_at,
										dpt: app.dept_val_at,
										osa: app.osa_val_at,
										sch: app.dist_sched,
										hdc: app.osa_dist_at,
										sec: app.security_checked_at,
										rel: app.sticker_released_at,
										ins: app.sticker_installed_at,
										exp: app.expires_at,
										rejection_reason: app.invalid_reason || null,
										is_change_vehicle: app.is_change_vehicle,
										qr_code: app.qr_code,
										qr_unique_code: app.qr_unique_code,
										documents: {
											id: toDocUrl(app.doc_id) || toDocUrl(app.vehicle_information?.school_id),
											enrollment: toDocUrl(app.doc_load) || toDocUrl(app.enrollment_form),
											or: toDocUrl(app.doc_or) || toDocUrl(app.vehicle_information?.or_document),
											cr: toDocUrl(app.doc_cr) || toDocUrl(app.vehicle_information?.cr_document),
											license: toDocUrl(app.doc_license) || toDocUrl(app.vehicle_information?.drivers_license),
											letter: toDocUrl(app.doc_letter) || toDocUrl(app.vehicle_information?.authorization_letter)
										}
									},
									showQR: true,
									children,
									$$slots: { default: true }
								});
							}
						}
					} else {
						$$renderer.push("<!--[!-->");
						$$renderer.push(`<p class="empty-state svelte-4rm2pb">No vehicles found.</p>`);
					}
					$$renderer.push(`<!--]--></div>`);
				} else if (tab === "Vehicle Log") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<div class="card svelte-4rm2pb"><div class="header svelte-4rm2pb"><div class="header-left svelte-4rm2pb"><h2 class="title svelte-4rm2pb">Gate History</h2></div> <div class="filters svelte-4rm2pb"><div class="dropdown-wrap svelte-4rm2pb"><button type="button" class="filter-select dropdown-btn svelte-4rm2pb" aria-haspopup="listbox"${attr("aria-expanded", roleDropdownOpen)}><span class="svelte-4rm2pb">${escape_html(getRoleDropdownLabel())}</span> <svg${attr_class("dropdown-arrow svelte-4rm2pb", void 0, { "rotated": roleDropdownOpen })} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9" class="svelte-4rm2pb"></polyline></svg></button> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div> `);
					$$renderer.select({
						value: boundFilter,
						onchange: () => {
							currentPage = 1;
							fetchLogs();
						},
						class: "filter-select"
					}, ($$renderer) => {
						$$renderer.option({
							value: "all",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`In &amp; Out`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "in",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Entry Only`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "out",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Exit Only`);
						}, "svelte-4rm2pb");
					}, "svelte-4rm2pb");
					$$renderer.push(` <input type="date"${attr("value", selectedDate)} class="filter-select svelte-4rm2pb"/> <input type="text" placeholder="Search…"${attr("value", searchQuery)} class="search-box svelte-4rm2pb"/> <button class="print-btn svelte-4rm2pb">${escape_html("Print Selected")}</button> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <div class="table-total-badge svelte-4rm2pb" title="Total logs"><span class="total-badge-label svelte-4rm2pb">Total Logs:</span> <span class="total-badge-count svelte-4rm2pb">${escape_html(totalLogs)}</span></div></div></div> `);
					if (loading) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="loading-row svelte-4rm2pb"><div class="spinner svelte-4rm2pb"></div> Loading…</div>`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<div class="table-wrap svelte-4rm2pb"><table class="data-table svelte-4rm2pb"><thead class="svelte-4rm2pb"><tr class="svelte-4rm2pb">`);
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--><th class="svelte-4rm2pb">Log ID</th><th class="svelte-4rm2pb">Plate Number</th><th class="svelte-4rm2pb">Driver / Role</th><th class="svelte-4rm2pb">Check In</th><th class="svelte-4rm2pb">Check Out</th><th class="svelte-4rm2pb">Campus</th><th class="svelte-4rm2pb">Status</th></tr></thead><tbody class="svelte-4rm2pb">`);
						const each_array_2 = ensure_array_like(logs);
						if (each_array_2.length !== 0) {
							$$renderer.push("<!--[-->");
							for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
								let log = each_array_2[$$index_2];
								$$renderer.push(`<tr${attr_class("svelte-4rm2pb", void 0, { "selected-row": selectedLogs.has(log.vehicle_log_id) })}>`);
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`<!--]--><td class="td-id svelte-4rm2pb"><span class="id-text svelte-4rm2pb">#${escape_html(log.vehicle_log_id)}</span></td><td class="svelte-4rm2pb"><span class="plate-badge svelte-4rm2pb">${escape_html(log.plate || log.vehicle_plate || "No Plate")}</span></td><td class="svelte-4rm2pb"><div class="driver-cell svelte-4rm2pb"><span class="driver-name-text svelte-4rm2pb">${escape_html(log.driver_name || log.name || "Driver")}</span> <span class="driver-role-chip svelte-4rm2pb">${escape_html(log.role || "Visitor")}</span></div></td><td class="td-time svelte-4rm2pb"><span class="time-main svelte-4rm2pb">${escape_html(log.check_in ? new Date(log.check_in).toLocaleString() : "—")}</span></td><td class="td-time svelte-4rm2pb"><span class="time-main svelte-4rm2pb">${escape_html(log.check_out ? new Date(log.check_out).toLocaleString() : "Still Inside")}</span></td><td class="svelte-4rm2pb"><span class="campus-badge svelte-4rm2pb">${escape_html(log.campus || "Main Campus")}</span></td><td class="svelte-4rm2pb"><span class="chip chip-status svelte-4rm2pb">${escape_html(log.logged_status || (log.check_out ? "Exited" : "Inside"))}</span></td></tr>`);
							}
						} else {
							$$renderer.push("<!--[!-->");
							$$renderer.push(`<tr class="svelte-4rm2pb"><td${attr("colspan", 7)} class="empty-cell svelte-4rm2pb">No logs found for the selected filters.</td></tr>`);
						}
						$$renderer.push(`<!--]--></tbody></table></div> `);
						if (totalPages > 1) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="paginator svelte-4rm2pb"><button class="page-btn svelte-4rm2pb"${attr("disabled", currentPage <= 1, true)}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><polyline points="15 18 9 12 15 6" class="svelte-4rm2pb"></polyline></svg> Prev</button> <span class="page-info svelte-4rm2pb">Page ${escape_html(currentPage)} of ${escape_html(totalPages)}</span> <button class="page-btn svelte-4rm2pb"${attr("disabled", currentPage >= totalPages, true)}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><polyline points="9 18 15 12 9 6" class="svelte-4rm2pb"></polyline></svg> Next</button></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					}
					$$renderer.push(`<!--]--> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				} else if (tab === "History") {
					$$renderer.push("<!--[2-->");
					$$renderer.push(`<div class="card svelte-4rm2pb"><div class="header svelte-4rm2pb"><div class="header-left svelte-4rm2pb"><h2 class="title svelte-4rm2pb">Gate History</h2></div> <div class="filters svelte-4rm2pb"><div class="dropdown-wrap svelte-4rm2pb"><button type="button" class="filter-select dropdown-btn svelte-4rm2pb" aria-haspopup="listbox"${attr("aria-expanded", roleDropdownOpen)}><span class="svelte-4rm2pb">${escape_html(getRoleDropdownLabel())}</span> <svg${attr_class("dropdown-arrow svelte-4rm2pb", void 0, { "rotated": roleDropdownOpen })} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9" class="svelte-4rm2pb"></polyline></svg></button> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div> `);
					$$renderer.select({
						value: boundFilter,
						onchange: () => {
							currentPage = 1;
							fetchLogs();
						},
						class: "filter-select"
					}, ($$renderer) => {
						$$renderer.option({
							value: "all",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`In &amp; Out`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "in",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`In Only`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "out",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Out Only`);
						}, "svelte-4rm2pb");
					}, "svelte-4rm2pb");
					$$renderer.push(` <input type="date"${attr("value", selectedDate)} class="filter-select svelte-4rm2pb"/> `);
					$$renderer.select({
						value: selectedCampus,
						onchange: () => {
							currentPage = 1;
							fetchLogs();
						},
						class: "filter-select"
					}, ($$renderer) => {
						$$renderer.option({
							value: "all",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`All Campuses`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "Liceo Main",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`Liceo Main`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "RNP",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`RNP`);
						}, "svelte-4rm2pb");
						$$renderer.option({
							value: "PASEO",
							class: ""
						}, ($$renderer) => {
							$$renderer.push(`PASEO`);
						}, "svelte-4rm2pb");
					}, "svelte-4rm2pb");
					$$renderer.push(` <input type="text" placeholder="Search name, plate, vehicle…"${attr("value", searchQuery)} class="search-box svelte-4rm2pb"/></div></div> `);
					if (loading) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="loading-row svelte-4rm2pb"><div class="spinner svelte-4rm2pb"></div> Loading…</div>`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<div class="table-wrap svelte-4rm2pb"><table class="data-table svelte-4rm2pb"><thead class="svelte-4rm2pb"><tr class="svelte-4rm2pb"><th class="svelte-4rm2pb">TIME</th><th class="svelte-4rm2pb">TYPE</th><th class="svelte-4rm2pb">NAME / ROLE</th><th class="svelte-4rm2pb">VEHICLE</th><th class="svelte-4rm2pb">BOUND</th><th class="svelte-4rm2pb">STATUS</th></tr></thead><tbody class="svelte-4rm2pb">`);
						const each_array_5 = ensure_array_like(logs);
						if (each_array_5.length !== 0) {
							$$renderer.push("<!--[-->");
							for (let $$index_5 = 0, $$length = each_array_5.length; $$index_5 < $$length; $$index_5++) {
								let log = each_array_5[$$index_5];
								$$renderer.push(`<tr class="svelte-4rm2pb"><td class="td-time svelte-4rm2pb"><span class="time-main svelte-4rm2pb">${escape_html(log.time)}</span> <span class="time-sub svelte-4rm2pb">${escape_html(log.date)}</span></td><td class="svelte-4rm2pb"><span class="type-badge svelte-4rm2pb">${escape_html(log.type)}</span></td><td class="td-name svelte-4rm2pb"><span class="name-text svelte-4rm2pb">${escape_html(log.name)}</span> <span class="role-badge svelte-4rm2pb">${escape_html(log.role)}</span></td><td class="td-vehicle svelte-4rm2pb">${escape_html(log.make)}
                    ${escape_html(log.vehicle_type)} <span class="plate-tag svelte-4rm2pb">${escape_html(log.plate)}</span></td><td class="svelte-4rm2pb"><span${attr_class(`bound-badge ${log.bound === "In" ? "in" : "out"}`, "svelte-4rm2pb")}>${escape_html(log.bound)}</span></td><td class="svelte-4rm2pb"><span${attr_class(`status-badge ${log.status === "Inside" ? "success" : "default"}`, "svelte-4rm2pb")}>${escape_html(log.status)}</span></td></tr>`);
							}
						} else {
							$$renderer.push("<!--[!-->");
							$$renderer.push(`<tr class="svelte-4rm2pb"><td colspan="6" class="empty-cell svelte-4rm2pb">No logs found for the selected filters.</td></tr>`);
						}
						$$renderer.push(`<!--]--></tbody></table></div> `);
						if (totalPages > 1) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="paginator svelte-4rm2pb"><button class="page-btn svelte-4rm2pb"${attr("disabled", currentPage <= 1, true)}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><polyline points="15 18 9 12 15 6" class="svelte-4rm2pb"></polyline></svg> Prev</button> <span class="page-info svelte-4rm2pb">Page ${escape_html(currentPage)} of ${escape_html(totalPages)}</span> <button class="page-btn svelte-4rm2pb"${attr("disabled", currentPage >= totalPages, true)}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><polyline points="9 18 15 12 9 6" class="svelte-4rm2pb"></polyline></svg> Next</button></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					}
					$$renderer.push(`<!--]--></div>`);
				} else if (tab === "Sticker Installation") {
					$$renderer.push("<!--[3-->");
					$$renderer.push(`<div class="controls-row svelte-4rm2pb"><div class="search-wrap svelte-4rm2pb"><svg class="search-icon svelte-4rm2pb" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8" class="svelte-4rm2pb"></circle><path d="m21 21-4.35-4.35" class="svelte-4rm2pb"></path></svg> <input type="text" placeholder="Search name, plate, vehicle…"${attr("value", installationSearch)} class="search-input svelte-4rm2pb"/> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div></div> <div class="install-info-banner svelte-4rm2pb"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><circle cx="12" cy="12" r="10" class="svelte-4rm2pb"></circle><line x1="12" y1="8" x2="12" y2="12" class="svelte-4rm2pb"></line><line x1="12" y1="16" x2="12.01" y2="16" class="svelte-4rm2pb"></line></svg> <span class="svelte-4rm2pb">This tab lists applicants whose sticker has been released by OSA and is
        ready for physical installation on the vehicle. Click <strong class="svelte-4rm2pb">Mark as Installed</strong> once the sticker has been placed on the vehicle.</span></div> <div class="cards-list svelte-4rm2pb">`);
					const each_array_6 = ensure_array_like(filteredInstallationVehicles());
					if (each_array_6.length !== 0) {
						$$renderer.push("<!--[-->");
						for (let $$index_6 = 0, $$length = each_array_6.length; $$index_6 < $$length; $$index_6++) {
							let app = each_array_6[$$index_6];
							{
								function children($$renderer) {
									$$renderer.push(`<div class="install-action-row svelte-4rm2pb"><div class="install-meta svelte-4rm2pb">`);
									if (app.sticker_released_at) {
										$$renderer.push("<!--[0-->");
										const releasedDate = new Date(app.sticker_released_at);
										const today = /* @__PURE__ */ new Date();
										const isOverdue = releasedDate.getDate() !== today.getDate() || releasedDate.getMonth() !== today.getMonth() || releasedDate.getFullYear() !== today.getFullYear();
										$$renderer.push(`<span class="install-date-label svelte-4rm2pb">Sticker Released:</span> <span class="install-date-value svelte-4rm2pb">${escape_html(releasedDate.toLocaleString("en-US", {
											dateStyle: "medium",
											timeStyle: "short"
										}))}</span> `);
										if (isOverdue && releasedDate < today) {
											$$renderer.push("<!--[0-->");
											$$renderer.push(`<div class="overdue-warning svelte-4rm2pb" style="color: #b91c1c; font-size: 0.8rem; font-weight: 600; margin-top: 0.35rem; display: flex; align-items: center; gap: 0.35rem; background: #fef2f2; padding: 0.4rem 0.6rem; border-radius: 4px; border: 1px solid #fca5a5; width: fit-content;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" class="svelte-4rm2pb"></path><line x1="12" y1="9" x2="12" y2="13" class="svelte-4rm2pb"></line><line x1="12" y1="17" x2="12.01" y2="17" class="svelte-4rm2pb"></line></svg> WARNING: Applicant did not visit for installation</div>`);
										} else $$renderer.push("<!--[-1-->");
										$$renderer.push(`<!--]-->`);
									} else $$renderer.push("<!--[-1-->");
									$$renderer.push(`<!--]--></div> <button${attr_class("action-btn btn-install svelte-4rm2pb", void 0, { "btn-loading": installationLoading === app.registration_id })}${attr("disabled", installationLoading === app.registration_id, true)}>`);
									if (installationLoading === app.registration_id) {
										$$renderer.push("<!--[0-->");
										$$renderer.push(`<svg class="btn-spinner svelte-4rm2pb" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2.5" stroke-dasharray="35 15" stroke-linecap="round" class="svelte-4rm2pb"></circle></svg> Installing…`);
									} else {
										$$renderer.push("<!--[-1-->");
										$$renderer.push(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-4rm2pb"><polyline points="20 6 9 17 4 12" class="svelte-4rm2pb"></polyline></svg> Mark as Installed`);
									}
									$$renderer.push(`<!--]--></button></div>`);
								}
								ApplicationCard($$renderer, {
									data: {
										id: app.registration_id || "-",
										name: `${app.first_name} ${app.last_name}`,
										role: app.role,
										campus: app.campus || "-",
										"year level": app.year_level || "-",
										email: app.user_email || "-",
										contact: app.mobile || "-",
										department: app.department_name || "-",
										"dept. email": app.department_email || "-",
										vehicle: app.vehicle_information?.brand || "-",
										"vehicle type": app.vehicle_information?.type || "-",
										color: app.vehicle_information?.color || "-",
										plate: app.vehicle_information?.plate_number || "-",
										owner: app.is_owner ? "Yes" : "No",
										status: app.status,
										crd: app.created_at,
										dpt: app.dept_val_at,
										osa: app.osa_val_at,
										sch: app.dist_sched,
										hdc: app.osa_dist_at,
										sec: app.security_checked_at,
										rel: app.sticker_released_at,
										ins: app.sticker_installed_at,
										exp: app.expires_at,
										rejection_reason: app.invalid_reason || null,
										is_change_vehicle: app.is_change_vehicle,
										qr_code: app.qr_code,
										qr_unique_code: app.qr_unique_code,
										documents: {
											id: toDocUrl(app.doc_id) || toDocUrl(app.vehicle_information?.school_id),
											enrollment: toDocUrl(app.doc_load) || toDocUrl(app.enrollment_form),
											or: toDocUrl(app.doc_or) || toDocUrl(app.vehicle_information?.or_document),
											cr: toDocUrl(app.doc_cr) || toDocUrl(app.vehicle_information?.cr_document),
											license: toDocUrl(app.doc_license) || toDocUrl(app.vehicle_information?.drivers_license),
											letter: toDocUrl(app.doc_letter) || toDocUrl(app.vehicle_information?.authorization_letter)
										}
									},
									showQR: true,
									children,
									$$slots: { default: true }
								});
							}
						}
					} else {
						$$renderer.push("<!--[!-->");
						$$renderer.push(`<div class="empty-state-install svelte-4rm2pb"><svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="svelte-4rm2pb"><path d="M9 11l3 3L22 4" class="svelte-4rm2pb"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" class="svelte-4rm2pb"></path></svg> <h3 class="svelte-4rm2pb">No Pending Installations</h3> <p class="svelte-4rm2pb">All stickers that have been released by OSA have been installed, or
            no stickers have been released yet.</p></div>`);
					}
					$$renderer.push(`<!--]--></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!---->`);
	});
}
//#endregion
export { _page as default };
