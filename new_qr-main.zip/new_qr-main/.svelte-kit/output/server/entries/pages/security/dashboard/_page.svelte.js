import { C as attr, a as head, c as stringify, d as html, i as ensure_array_like, n as attr_style, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/navigation.js";
import "../../../../chunks/liveSync.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/security/dashboard/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let userRole = derived(() => data.userRole || "security");
		derived(() => [
			{
				label: "Dashboard",
				href: "/security/dashboard"
			},
			{
				label: "Application Review",
				href: "/security"
			},
			{
				label: "Vehicle Log",
				href: "/security/logs"
			},
			{
				label: "Incident Report",
				href: "/security/complaints",
				badge: data.unreadComplaints
			},
			{
				label: "Settings",
				href: "/security/settings"
			}
		]);
		let statsData = derived(() => data.stats || {
			totalEntriesToday: 0,
			twoWheelers: 0,
			fourWheelers: 0,
			mainCampusPresence: 0,
			rnpCampusPresence: 0,
			paseoCampusPresence: 0,
			totalComplaints: 0
		});
		let roleBreakdownByCampus = derived(() => data.roleBreakdownByCampus || {});
		const roleColors = {
			student: "#3B82F6",
			faculty: "#4F46E5",
			staff: "#10B981",
			administrator: "#DC2626",
			concessionaire: "#EA580C",
			supplier: "#D97706",
			vps: "#854D0E",
			vip: "#D4AF37"
		};
		const roleLabels = {
			student: "Student",
			faculty: "Faculty",
			staff: "Staff",
			administrator: "Administrator",
			concessionaire: "Concessionaire",
			supplier: "Supplier",
			vps: "VPS",
			vip: "VIP"
		};
		function getCampusRoleStats(campusLabel) {
			const key = campusLabel === "MAIN CAMPUS" ? "Main Campus" : campusLabel;
			const breakdown = roleBreakdownByCampus()[key] || {};
			const roles = [
				"student",
				"faculty",
				"staff",
				"administrator",
				"concessionaire",
				"supplier",
				"vps",
				"vip"
			];
			let total = 0;
			roles.forEach((r) => {
				total += breakdown[r] || 0;
			});
			let accumulatedPct = 0;
			const items = roles.map((r) => {
				const count = breakdown[r] || 0;
				const pct = total > 0 ? count / total * 100 : 0;
				const offsetPct = accumulatedPct;
				accumulatedPct += pct;
				return {
					role: r,
					label: roleLabels[r] || r,
					count,
					pct,
					pctFormatted: pct % 1 === 0 ? pct.toFixed(0) : pct.toFixed(1),
					color: roleColors[r] || "#718096",
					offsetPct
				};
			});
			return {
				total,
				items
			};
		}
		let hourlyChart = derived(() => data.hourlyChart || Array(24).fill(0));
		let flaggedAlerts = derived(() => data.flaggedAlerts || []);
		const statCards = derived(() => [
			{
				label: "MAIN CAMPUS",
				value: statsData().mainCampusPresence || 0,
				desc: `2-Wheels: ${statsData().main2W || 0} • 4-Wheels: ${statsData().main4W || 0}`,
				capacity: statsData().mainCapacity,
				icon: `<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>`,
				color: "#8B1A3C",
				bg: "rgba(139,26,60,0.08)",
				event: statsData().mainEvent
			},
			{
				label: "RNP",
				value: statsData().rnpCampusPresence || 0,
				desc: `2-Wheels: ${statsData().rnp2W || 0} • 4-Wheels: ${statsData().rnp4W || 0}`,
				capacity: statsData().rnpCapacity,
				icon: `<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>`,
				color: "#D4A62A",
				bg: "rgba(212,166,42,0.1)",
				event: statsData().rnpEvent
			},
			{
				label: "PASEO",
				value: statsData().paseoCampusPresence || 0,
				desc: `2-Wheels: ${statsData().paseo2W || 0} • 4-Wheels: ${statsData().paseo4W || 0}`,
				capacity: statsData().paseoCapacity,
				icon: `<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>`,
				color: "#A21C46",
				bg: "rgba(162,28,70,0.08)",
				event: statsData().paseoEvent
			}
		]);
		const maxChartValue = derived(() => Math.max(...hourlyChart(), 1));
		head("134ssfa", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Security Dashboard | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Real-time security analytics and gate operations monitoring." class="svelte-134ssfa"/>`);
		});
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: data.userEmail,
			userRole: userRole(),
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Security Dashboard" });
				$$renderer.push(`<!----> <div class="dashboard-wrapper svelte-134ssfa"><div class="welcome-banner svelte-134ssfa"><div class="wb-content svelte-134ssfa"><h1 class="wb-title svelte-134ssfa">Welcome back, Security Officer!</h1> <p class="wb-sub svelte-134ssfa">Here's what's happening across all university campus gates today.</p></div> <div class="wb-icon-shield svelte-134ssfa"><svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1.75" class="svelte-134ssfa"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" class="svelte-134ssfa"></path></svg></div></div> <div class="stats-grid svelte-134ssfa"><!--[-->`);
				const each_array = ensure_array_like(statCards());
				for (let $$index_3 = 0, $$length = each_array.length; $$index_3 < $$length; $$index_3++) {
					let card = each_array[$$index_3];
					const roleStats = getCampusRoleStats(card.label);
					$$renderer.push(`<div class="stat-card svelte-134ssfa"${attr_style(`--card-color: ${stringify(card.color)}; --card-bg: ${stringify(card.bg)};`)}>`);
					if (card.event) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="event-badge svelte-134ssfa"><span class="event-dot svelte-134ssfa"></span> ${escape_html(card.event.name)} <div class="event-tooltip svelte-134ssfa"><strong class="svelte-134ssfa">Start:</strong> ${escape_html(new Date(card.event.start).toLocaleString([], {
							month: "short",
							day: "numeric",
							hour: "2-digit",
							minute: "2-digit"
						}))}<br class="svelte-134ssfa"/> <strong class="svelte-134ssfa">End:</strong> ${escape_html(new Date(card.event.end).toLocaleString([], {
							month: "short",
							day: "numeric",
							hour: "2-digit",
							minute: "2-digit"
						}))}</div></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <div class="stat-card-top svelte-134ssfa"><div class="stat-icon-box svelte-134ssfa"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svelte-134ssfa">${html(card.icon)}</svg></div> <div class="stat-details svelte-134ssfa"><div class="stat-value svelte-134ssfa">${escape_html(card.value)}</div> <div class="stat-label svelte-134ssfa">${escape_html(card.label)}</div> <div class="stat-desc svelte-134ssfa">${escape_html(card.desc)}</div></div></div> <div class="capacity-stats svelte-134ssfa"><div class="cap-item svelte-134ssfa"><span class="svelte-134ssfa">Capacity:</span> ${escape_html(card.capacity?.capacity ?? 0)}</div> <div class="cap-item svelte-134ssfa"><span class="svelte-134ssfa">Occupied:</span> <strong style="color:#e53e3e" class="svelte-134ssfa">${escape_html(card.capacity?.occupied ?? 0)}</strong></div> <div class="cap-item svelte-134ssfa"><span class="svelte-134ssfa">Unoccupied:</span> <strong style="color:#D4A62A" class="svelte-134ssfa">${escape_html(card.capacity?.available ?? card.capacity?.unoccupied ?? 0)}</strong></div></div> <div class="campus-role-section svelte-134ssfa"><div class="role-section-header svelte-134ssfa"><span class="role-section-title svelte-134ssfa">Entries by Role</span> <span class="role-section-total svelte-134ssfa">Total: <strong class="svelte-134ssfa">${escape_html(roleStats.total)}</strong></span></div> <div class="role-diagram-row svelte-134ssfa"><div class="role-donut-box svelte-134ssfa"><svg class="role-donut-svg svelte-134ssfa" viewBox="0 0 80 80"><circle cx="40" cy="40" r="30" fill="none" stroke="#f1f5f9" stroke-width="8" class="svelte-134ssfa"></circle>`);
					if (roleStats.total > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<!--[-->`);
						const each_array_1 = ensure_array_like(roleStats.items);
						for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
							let item = each_array_1[$$index];
							if (item.count > 0) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<circle cx="40" cy="40" r="30" fill="none"${attr("stroke", item.color)} stroke-width="8"${attr("stroke-dasharray", `${stringify(item.pct / 100 * 188.5)} 188.5`)}${attr("stroke-dashoffset", `-${stringify(item.offsetPct / 100 * 188.5)}`)} class="donut-segment svelte-134ssfa"></circle>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]-->`);
						}
						$$renderer.push(`<!--]-->`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></svg> <div class="role-donut-center svelte-134ssfa"><span class="donut-number svelte-134ssfa">${escape_html(roleStats.total)}</span> <span class="donut-unit svelte-134ssfa">Entries</span></div></div> <div class="role-details-list svelte-134ssfa"><!--[-->`);
					const each_array_2 = ensure_array_like(roleStats.items);
					for (let $$index_1 = 0, $$length = each_array_2.length; $$index_1 < $$length; $$index_1++) {
						let item = each_array_2[$$index_1];
						$$renderer.push(`<div class="role-detail-item svelte-134ssfa"><div class="role-detail-header svelte-134ssfa"><div class="role-name-wrap svelte-134ssfa"><span class="role-dot svelte-134ssfa"${attr_style(`background: ${stringify(item.color)};`)}></span> <span class="role-name svelte-134ssfa">${escape_html(item.label)}</span></div> <div class="role-metrics svelte-134ssfa"><span class="role-pct svelte-134ssfa"${attr_style(`color: ${stringify(item.color)};`)}>${escape_html(item.pctFormatted)}%</span> <span class="role-count svelte-134ssfa">(${escape_html(item.count)})</span></div></div> <div class="role-progress-track svelte-134ssfa"><div class="role-progress-fill svelte-134ssfa"${attr_style(`width: ${stringify(item.pct)}%; background: ${stringify(item.color)};`)}></div></div></div>`);
					}
					$$renderer.push(`<!--]--></div></div> <div class="role-stacked-bar svelte-134ssfa"${attr("title", roleStats.items.map((i) => `${i.label}: ${i.pctFormatted}%`).join(" | "))}>`);
					if (roleStats.total > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<!--[-->`);
						const each_array_3 = ensure_array_like(roleStats.items);
						for (let $$index_2 = 0, $$length = each_array_3.length; $$index_2 < $$length; $$index_2++) {
							let item = each_array_3[$$index_2];
							if (item.count > 0) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<div class="stacked-seg svelte-134ssfa"${attr_style(`width: ${stringify(item.pct)}%; background: ${stringify(item.color)};`)}${attr("title", `${stringify(item.label)}: ${stringify(item.pctFormatted)}% (${stringify(item.count)})`)}></div>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]-->`);
						}
						$$renderer.push(`<!--]-->`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<div class="stacked-seg svelte-134ssfa" style="width: 100%; background: #e2e8f0;" title="No entries recorded"></div>`);
					}
					$$renderer.push(`<!--]--></div></div></div>`);
				}
				$$renderer.push(`<!--]--></div> <div class="analytics-row svelte-134ssfa"><div class="card chart-card svelte-134ssfa"><div class="card-header svelte-134ssfa"><h2 class="svelte-134ssfa">Hourly Entry Traffic Today</h2></div> <div class="chart-content svelte-134ssfa"><div class="chart-bars svelte-134ssfa"><!--[-->`);
				const each_array_4 = ensure_array_like(hourlyChart());
				for (let i = 0, $$length = each_array_4.length; i < $$length; i++) {
					let value = each_array_4[i];
					$$renderer.push(`<div class="bar-col svelte-134ssfa"><div class="bar-fill-wrap svelte-134ssfa"><div class="bar-fill svelte-134ssfa"${attr_style(`height: ${stringify(value / maxChartValue() * 100)}%`)}${attr("title", `${stringify(i)}:00 — ${stringify(value)} entries`)}></div></div> <span class="bar-hour svelte-134ssfa">${escape_html(i)}</span></div>`);
				}
				$$renderer.push(`<!--]--></div> <div class="chart-axis-label svelte-134ssfa">Hour of the Day (0:00 – 23:00)</div></div></div> <div class="card flagged-alerts-card svelte-134ssfa"><div class="card-header svelte-134ssfa"><div class="header-left svelte-134ssfa"><h2 class="svelte-134ssfa">Flagged Alerts</h2></div> <span${attr_class("alerts-count-badge svelte-134ssfa", void 0, { "has-alerts": flaggedAlerts().length > 0 })}>${escape_html(flaggedAlerts().length)} Recorded</span></div> `);
				if (flaggedAlerts().length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="table-container svelte-134ssfa"><table class="flagged-table svelte-134ssfa"><thead class="svelte-134ssfa"><tr class="svelte-134ssfa"><th class="svelte-134ssfa">Date &amp; Time</th><th class="svelte-134ssfa">Alert / Reason</th><th class="svelte-134ssfa">Plate Number</th><th class="svelte-134ssfa">Driver / Role</th><th class="svelte-134ssfa">Campus</th><th class="svelte-134ssfa">Status</th></tr></thead><tbody class="svelte-134ssfa"><!--[-->`);
					const each_array_5 = ensure_array_like(flaggedAlerts());
					for (let $$index_5 = 0, $$length = each_array_5.length; $$index_5 < $$length; $$index_5++) {
						let alert = each_array_5[$$index_5];
						$$renderer.push(`<tr class="svelte-134ssfa"><td class="td-datetime svelte-134ssfa"><span class="date-text svelte-134ssfa">${escape_html(new Date(alert.time).toLocaleDateString("en-US", {
							month: "short",
							day: "numeric",
							year: "numeric"
						}))}</span> <span class="time-text svelte-134ssfa">${escape_html(new Date(alert.time).toLocaleTimeString([], {
							hour: "2-digit",
							minute: "2-digit"
						}))}</span></td><td class="svelte-134ssfa"><span${attr_class("reason-tag svelte-134ssfa", void 0, { "danger": alert.reason.toLowerCase().includes("not recognized") || alert.reason.toLowerCase().includes("duplicate") || alert.reason.toLowerCase().includes("denied") })}>${escape_html(alert.reason)}</span></td><td class="svelte-134ssfa"><span class="plate-code svelte-134ssfa">${escape_html(alert.plate)}</span></td><td class="svelte-134ssfa"><div class="user-cell svelte-134ssfa"><span class="user-name svelte-134ssfa">${escape_html(alert.name)}</span> <span class="user-role svelte-134ssfa">${escape_html(alert.role)}</span></div></td><td class="svelte-134ssfa"><span${attr_class("campus-tag svelte-134ssfa", void 0, {
							"rnp": alert.campus?.toLowerCase().includes("rnp"),
							"paseo": alert.campus?.toLowerCase().includes("paseo")
						})}><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" class="svelte-134ssfa"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" class="svelte-134ssfa"></path><circle cx="12" cy="10" r="3" class="svelte-134ssfa"></circle></svg> ${escape_html(alert.campus || "Main Campus")}</span></td><td class="svelte-134ssfa"><span class="status-badge-chip svelte-134ssfa">${escape_html(alert.status)}</span></td></tr>`);
					}
					$$renderer.push(`<!--]--></tbody></table></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="no-alerts-state svelte-134ssfa"><div class="svelte-134ssfa"><h4 class="svelte-134ssfa">No flagged alerts detected</h4> <p class="svelte-134ssfa">All recognized QR codes and gate entries are clean.</p></div></div>`);
				}
				$$renderer.push(`<!--]--></div></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
