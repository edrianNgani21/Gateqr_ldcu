import "../../../../chunks/server.js";
import { t as AdminSettingsView } from "../../../../chunks/AdminSettingsView.js";
//#region src/routes/security/settings/+page.svelte
function _page($$renderer, $$props) {
	let { data } = $$props;
	AdminSettingsView($$renderer, {
		data,
		userRole: "security",
		showSidebar: true,
		pageTitle: "Settings",
		roleLabel: "Security Administrator"
	});
}
//#endregion
export { _page as default };
