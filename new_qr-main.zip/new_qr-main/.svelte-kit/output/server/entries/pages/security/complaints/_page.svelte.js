import "../../../../chunks/internal.js";
import { C as attr, a as head, r as derived } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/liveSync.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/security/complaints/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let userRole = derived(() => data.userRole || "security");
		let complaints = [];
		let searchQuery = "";
		let statusFilter = "all";
		derived(() => {
			return complaints;
		});
		head("smirei", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Incident Reports — Security | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Security incident reports management dashboard for Liceo de Cagayan University."/>`);
		});
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: data.userEmail,
			userRole: userRole(),
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Incident Report" });
				$$renderer.push(`<!----> <div class="controls-row svelte-smirei"><div class="search-wrap svelte-smirei"><svg class="search-icon svelte-smirei" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg> <input type="text" placeholder="Search incident reports…"${attr("value", searchQuery)} class="search-input svelte-smirei"/> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <div class="filters svelte-smirei">`);
				$$renderer.select({
					value: statusFilter,
					class: "filter-select"
				}, ($$renderer) => {
					$$renderer.option({ value: "all" }, ($$renderer) => {
						$$renderer.push(`All Status`);
					});
					$$renderer.option({ value: "Pending" }, ($$renderer) => {
						$$renderer.push(`Pending`);
					});
					$$renderer.option({ value: "Resolved" }, ($$renderer) => {
						$$renderer.push(`Resolved`);
					});
				}, "svelte-smirei");
				$$renderer.push(`</div></div> `);
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="loading-state svelte-smirei"><svg class="loading-spinner svelte-smirei" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2.5" stroke-dasharray="35 15" stroke-linecap="round"></circle></svg> Loading incident reports…</div>`);
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
