import "../../../../chunks/internal.js";
import { C as attr, c as stringify, i as ensure_array_like, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/navigation.js";
import "../../../../chunks/liveSync.js";
//#region src/routes/security/capacity/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let userRole = derived(() => data.userRole || "security");
		let campuses = data.campuses;
		let loadingCampus = null;
		let editingCampus = null;
		let editCapacity = 0;
		let editEventName = "";
		let showHistory = {};
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: data.userEmail,
			userRole: userRole(),
			children: ($$renderer) => {
				$$renderer.push(`<div class="capacity-wrapper svelte-uq8gc0"><div class="header svelte-uq8gc0"><h1 class="svelte-uq8gc0">Parking Capacity Records</h1> <p class="svelte-uq8gc0">Total Count of Registered Vehicles per Campus and Parking Capacities</p></div> <div class="campus-grid svelte-uq8gc0"><!--[-->`);
				const each_array = ensure_array_like(campuses);
				for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
					let campus = each_array[$$index_1];
					$$renderer.push(`<div class="campus-card svelte-uq8gc0"><h2 class="svelte-uq8gc0">${escape_html(campus.name)}</h2> `);
					if (editingCampus === campus.name) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="edit-form svelte-uq8gc0"><div class="form-group svelte-uq8gc0"><label${attr("for", `cap-${stringify(campus.name)}`)} class="svelte-uq8gc0">Capacity Limit</label> <input${attr("id", `cap-${stringify(campus.name)}`)} type="number"${attr("value", editCapacity)} min="0" max="10000"${attr("disabled", loadingCampus === campus.name, true)} class="svelte-uq8gc0"/></div> <div class="form-group svelte-uq8gc0"><label${attr("for", `evt-${stringify(campus.name)}`)} class="svelte-uq8gc0">Event Name (Optional)</label> <input${attr("id", `evt-${stringify(campus.name)}`)} type="text" placeholder="e.g. Intramurals"${attr("value", editEventName)}${attr("disabled", loadingCampus === campus.name, true)} class="svelte-uq8gc0"/></div> `);
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> <div class="edit-actions svelte-uq8gc0"><button class="save-btn svelte-uq8gc0"${attr("disabled", loadingCampus === campus.name, true)}>${escape_html(loadingCampus === campus.name ? "Saving..." : "Save")}</button> <button class="cancel-btn svelte-uq8gc0"${attr("disabled", loadingCampus === campus.name, true)}>Cancel</button></div></div>`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<div class="event-display svelte-uq8gc0"><span class="label svelte-uq8gc0">Current Event:</span> <span class="value svelte-uq8gc0">${escape_html(campus.event_name || "None")}</span> `);
						if (campus.event_name) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="event-times svelte-uq8gc0"><div>${escape_html(new Date(campus.event_start).toLocaleString())}</div> <div>to ${escape_html(new Date(campus.event_end).toLocaleString())}</div></div> <button class="remove-event-btn svelte-uq8gc0">Remove Event</button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div> <div class="stats svelte-uq8gc0"><div class="stat svelte-uq8gc0"><span class="label svelte-uq8gc0">Capacity</span> <span class="value svelte-uq8gc0">${escape_html(campus.capacity)}</span></div> <div class="stat svelte-uq8gc0"><span class="label svelte-uq8gc0">Occupied</span> <span class="value occupied svelte-uq8gc0">${escape_html(campus.occupied)}</span></div> <div class="stat svelte-uq8gc0"><span class="label svelte-uq8gc0">Unoccupied</span> <span class="value available svelte-uq8gc0">${escape_html(campus.unoccupied ?? campus.available)}</span></div></div> <div class="wheels-stats svelte-uq8gc0"><span class="wheel-tag svelte-uq8gc0">2-Wheels: <strong class="svelte-uq8gc0">${escape_html(campus.wheels2 ?? 0)}</strong></span> <span class="wheel-sep svelte-uq8gc0">•</span> <span class="wheel-tag svelte-uq8gc0">4-Wheels: <strong class="svelte-uq8gc0">${escape_html(campus.wheels4 ?? 0)}</strong></span></div> <button class="set-btn svelte-uq8gc0">Update Settings</button>`);
					}
					$$renderer.push(`<!--]--> <div class="history-toggle svelte-uq8gc0" role="button" tabindex="0"><span>Event History</span> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"${attr_class("svelte-uq8gc0", void 0, { "rotated": showHistory[campus.name] })}><polyline points="6 9 12 15 18 9"></polyline></svg></div> `);
					if (showHistory[campus.name]) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="history-panel svelte-uq8gc0">`);
						if (campus.history && campus.history.length > 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<table class="history-table svelte-uq8gc0"><thead><tr><th class="svelte-uq8gc0">Event</th><th class="svelte-uq8gc0">Start</th><th class="svelte-uq8gc0">End</th></tr></thead><tbody><!--[-->`);
							const each_array_1 = ensure_array_like(campus.history);
							for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
								let h = each_array_1[$$index];
								$$renderer.push(`<tr class="svelte-uq8gc0"><td class="svelte-uq8gc0">${escape_html(h.event_name)}</td><td class="svelte-uq8gc0">${escape_html(new Date(h.start_date).toLocaleDateString())} ${escape_html(new Date(h.start_date).toLocaleTimeString([], {
									hour: "2-digit",
									minute: "2-digit"
								}))}</td><td class="svelte-uq8gc0">${escape_html(new Date(h.end_date).toLocaleDateString())} ${escape_html(new Date(h.end_date).toLocaleTimeString([], {
									hour: "2-digit",
									minute: "2-digit"
								}))}</td></tr>`);
							}
							$$renderer.push(`<!--]--></tbody></table>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<div class="no-history svelte-uq8gc0">No past events recorded.</div>`);
						}
						$$renderer.push(`<!--]--></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				}
				$$renderer.push(`<!--]--></div></div>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
