import { C as attr, a as head, c as stringify, r as derived, t as attr_class, w as escape_html } from "../../../../chunks/server.js";
import { t as AppShell } from "../../../../chunks/AppShell.js";
import "../../../../chunks/liveSync.js";
import { t as NavBar } from "../../../../chunks/NavBar.js";
//#region src/routes/security/logs/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		let userRole = derived(() => data.userRole || "security");
		let selectedDate = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		let boundFilter = "all";
		let selectedCampus = "";
		let searchQuery = "";
		let printModeActive = false;
		const allRoles = [
			"student",
			"faculty",
			"staff",
			"administrator",
			"concessionaire",
			"supplier",
			"vps",
			"vip"
		];
		let selectedRoles = [];
		let roleDropdownOpen = false;
		function formatRoleLabel(role) {
			const lower = (role || "").toLowerCase();
			if (lower === "vps") return "VPS";
			if (lower === "vip") return "VIP";
			if (lower === "administrator") return "Administrator";
			if (lower === "concessionaire" || lower === "concecioonaire") return "Concessionaire";
			return role.charAt(0).toUpperCase() + role.slice(1);
		}
		function getRoleDropdownLabel() {
			if (selectedRoles.length === 0 || selectedRoles.length === allRoles.length) return "All Roles";
			if (selectedRoles.length === 1) return formatRoleLabel(selectedRoles[0]);
			return formatRoleLabel(selectedRoles[0]);
		}
		async function fetchLogs() {}
		let selectedFeedCampus = "Main";
		let camError = {
			Main: false,
			Rnp: false,
			Paseo: false
		};
		let isCamSettingsOpen = false;
		let campusHosts = {
			Main: "http://192.168.1.50:5000",
			Rnp: "http://192.168.1.51:5001",
			Paseo: "http://192.168.1.52:5002"
		};
		let activeStreamUrl = derived(() => {
			const base = campusHosts[selectedFeedCampus] || "";
			if (!base) return "";
			return `${base.replace(/\/+$/, "")}/video_feed`;
		});
		head("txj713", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>Vehicle Log — Security | GateQR</title>`);
			});
			$$renderer.push(`<meta name="description" content="Gate entry and exit vehicle logs for Liceo de Cagayan University." class="svelte-txj713"/>`);
		});
		AppShell($$renderer, {
			showSidebar: true,
			userEmail: data.userEmail,
			userRole: userRole(),
			children: ($$renderer) => {
				NavBar($$renderer, { title: "Vehicle Log" });
				$$renderer.push(`<!----> <div class="page-container svelte-txj713"><div class="header-section svelte-txj713" style="justify-content: flex-end; margin-bottom: 1rem;"><div class="header-stats svelte-txj713">`);
				$$renderer.select({
					value: selectedCampus,
					onchange: () => {
						fetchLogs();
					},
					class: "select-control top-campus-select"
				}, ($$renderer) => {
					$$renderer.option({
						value: "",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`Select Campus`);
					}, "svelte-txj713");
					$$renderer.option({
						value: "Liceo Main",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`Liceo Main`);
					}, "svelte-txj713");
					$$renderer.option({
						value: "RNP",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`RNP`);
					}, "svelte-txj713");
					$$renderer.option({
						value: "PASEO",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`PASEO`);
					}, "svelte-txj713");
				}, "svelte-txj713");
				$$renderer.push(`</div></div> <div class="card svelte-txj713"><div class="controls-toolbar svelte-txj713"><div class="search-wrap svelte-txj713"><svg class="search-icon svelte-txj713" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8" class="svelte-txj713"></circle><path d="m21 21-4.35-4.35" class="svelte-txj713"></path></svg> <input type="text" placeholder="Search plate, name, vehicle…"${attr("value", searchQuery)} class="search-input svelte-txj713"/> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <div class="filters-row svelte-txj713">`);
				$$renderer.select({
					value: boundFilter,
					onchange: () => {
						fetchLogs();
					},
					class: "select-control"
				}, ($$renderer) => {
					$$renderer.option({
						value: "all",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`All (In &amp; Out)`);
					}, "svelte-txj713");
					$$renderer.option({
						value: "in",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`Entry Only`);
					}, "svelte-txj713");
					$$renderer.option({
						value: "out",
						class: ""
					}, ($$renderer) => {
						$$renderer.push(`Exit Only`);
					}, "svelte-txj713");
				}, "svelte-txj713");
				$$renderer.push(` <input type="date"${attr("value", selectedDate)} class="select-control date-input svelte-txj713"/> <div class="dropdown-wrap svelte-txj713"><button type="button" class="select-control dropdown-btn svelte-txj713" aria-haspopup="listbox"${attr("aria-expanded", roleDropdownOpen)}><span class="svelte-txj713">${escape_html(getRoleDropdownLabel())}</span> <svg${attr_class("dropdown-arrow svelte-txj713", void 0, { "rotated": roleDropdownOpen })} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9" class="svelte-txj713"></polyline></svg></button> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <button${attr_class("btn-action svelte-txj713", void 0, { "active": printModeActive })}><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-txj713"><polyline points="6 9 6 2 18 2 18 9" class="svelte-txj713"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" class="svelte-txj713"></path><rect x="6" y="14" width="12" height="8" class="svelte-txj713"></rect></svg> ${escape_html("Print Select")}</button> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div> `);
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="empty-campus-state svelte-txj713"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="svelte-txj713"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" class="svelte-txj713"></path></svg> <h3 class="svelte-txj713">Select a Campus</h3> <p class="svelte-txj713">Please select a specific campus from the dropdown above to view its real-time vehicle logs.</p></div>`);
				$$renderer.push(`<!--]--></div> <div class="card camera-feed-card svelte-txj713" id="cctv-camera-container"><div class="camera-card-header svelte-txj713"><div class="cam-header-left svelte-txj713"><div class="live-indicator svelte-txj713"><span class="live-dot svelte-txj713"></span> <span class="live-text svelte-txj713">LIVE CCTV</span></div> <div class="svelte-txj713"><h2 class="cam-title svelte-txj713">Campus Real-Time Gate Camera Feeds</h2> <p class="cam-subtitle svelte-txj713">Monitor live gate camera video streams across all university campuses on local network</p></div></div> <div class="cam-header-controls svelte-txj713"><div class="gate-toggle-group svelte-txj713"><button${attr_class("gate-btn svelte-txj713", void 0, { "active": true })}>Dual / Active View</button> <button${attr_class("gate-btn svelte-txj713", void 0, { "active": false })}>Entrance Cam</button> <button${attr_class("gate-btn svelte-txj713", void 0, { "active": false })}>Exit Cam</button></div> <button${attr_class("cam-action-btn svelte-txj713", void 0, { "active-btn": isCamSettingsOpen })} title="Configure Pi IP Addresses"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-txj713"><circle cx="12" cy="12" r="3" class="svelte-txj713"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" class="svelte-txj713"></path></svg> Pi Network</button> <button class="cam-action-btn svelte-txj713" title="Fullscreen View"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-txj713"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" class="svelte-txj713"></path></svg></button></div></div> <div class="campus-tabs-bar svelte-txj713"><button${attr_class("campus-tab-btn svelte-txj713", void 0, { "active": true })} style="--tab-color: #8B1A3C;"><span class="tab-badge svelte-txj713">GATE 1</span> MAIN CAMPUS FEED</button> <button${attr_class("campus-tab-btn svelte-txj713", void 0, { "active": false })} style="--tab-color: #D4A62A;"><span class="tab-badge svelte-txj713">GATE 2</span> RNP CAMPUS FEED</button> <button${attr_class("campus-tab-btn svelte-txj713", void 0, { "active": false })} style="--tab-color: #8B1A3C;"><span class="tab-badge svelte-txj713">GATE 3</span> PASEO CAMPUS FEED</button></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="cctv-viewer svelte-txj713"><div class="cctv-osd-top svelte-txj713"><div class="osd-cam-label svelte-txj713"><span class="osd-rec-dot svelte-txj713"></span> <strong class="svelte-txj713">${escape_html(selectedFeedCampus.toUpperCase())} CAMPUS</strong> <span class="osd-divider svelte-txj713">•</span> <span class="svelte-txj713">${escape_html("ACTIVE VIEW")}</span></div> <div class="osd-meta svelte-txj713"><span class="osd-res svelte-txj713">720P • 25 FPS</span> <span class="osd-ip svelte-txj713">${escape_html(campusHosts[selectedFeedCampus])}</span></div></div> <div class="video-display-area svelte-txj713">`);
				if (!camError[selectedFeedCampus]) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<img${attr("src", activeStreamUrl())}${attr("alt", `${stringify(selectedFeedCampus)} Campus Live Feed`)} class="live-stream-img svelte-txj713" onerror="this.__e=event"/>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (camError[selectedFeedCampus]) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="cam-offline-standby svelte-txj713"><div class="offline-icon-pulse svelte-txj713"><svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#D4A62A" stroke-width="1.75" class="svelte-txj713"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" class="svelte-txj713"></path><line x1="1" y1="1" x2="23" y2="23" class="svelte-txj713"></line></svg></div> <h3 class="svelte-txj713">Camera Feed Standby / Connecting...</h3> <p class="svelte-txj713">Waiting for connection from <strong class="svelte-txj713">${escape_html(selectedFeedCampus)} Campus</strong> Raspberry Pi stream:</p> <code class="svelte-txj713">${escape_html(activeStreamUrl())}</code> <div class="offline-help-text svelte-txj713">Ensure <code class="svelte-txj713">main.py</code> is running on the Raspberry Pi camera server and both devices are connected to the same Wi-Fi.</div> <div class="offline-btn-row svelte-txj713"><button class="btn-retry-feed svelte-txj713"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-txj713"><polyline points="23 4 23 10 17 10" class="svelte-txj713"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" class="svelte-txj713"></path></svg> Retry Stream</button> <button class="btn-config-ip svelte-txj713">Configure IP Address</button></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <div class="cctv-osd-bottom svelte-txj713"><div class="osd-time svelte-txj713">MONITORING ACTIVE • ${escape_html(selectedFeedCampus.toUpperCase())} GATE</div> <div class="osd-actions svelte-txj713"><button class="osd-btn svelte-txj713" title="Capture Snapshot"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-txj713"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" class="svelte-txj713"></path><circle cx="12" cy="13" r="4" class="svelte-txj713"></circle></svg> Snapshot</button> <button class="osd-btn svelte-txj713" title="Refresh Stream"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="svelte-txj713"><polyline points="23 4 23 10 17 10" class="svelte-txj713"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" class="svelte-txj713"></path></svg> Reconnect</button></div></div></div></div></div> `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
