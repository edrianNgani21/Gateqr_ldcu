import { t as supabase } from "../../../../chunks/supabase.js";
import { r as setCachedCapacity, t as getCachedCapacity } from "../../../../chunks/capacityCache.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/security/capacity/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "security") throw redirect(303, "/login");
	const cached = getCachedCapacity();
	if (cached) return {
		userEmail: locals.user.email,
		userRole: locals.user.role,
		campuses: cached
	};
	const campusesList = [
		"Main Campus",
		"RNP",
		"PASEO"
	];
	(/* @__PURE__ */ new Date()).toISOString();
	try {
		const [activeLogsRes, parkingCapRes, campusEventRes] = await Promise.all([
			supabase.from("vehicle_log").select(`
                    vehicle_log_id,
                    campus,
                    campus_gate,
                    logged_status,
                    vip_access,
                    guest_id,
                    registration_id,
                    vehicle_information:vehicle_information_id(type),
                    registration:registration_id(
                        role,
                        vehicle_information:vehicle_information_id(type)
                    )
                `).is("check_out", null),
			supabase.from("parking_capacity").select("*").order("date_time", { ascending: false }).limit(20),
			supabase.from("campus_event").select("*").order("created_at", { ascending: false }).limit(60)
		]);
		const activeLogs = activeLogsRes.data || [];
		const allParkingCap = parkingCapRes.data || [];
		const allEvents = campusEventRes.data || [];
		const countedByCampus = {
			"main": /* @__PURE__ */ new Set(),
			"rnp": /* @__PURE__ */ new Set(),
			"paseo": /* @__PURE__ */ new Set()
		};
		const countsByCampus = {
			"main": {
				occupied: 0,
				wheels2: 0,
				wheels4: 0
			},
			"rnp": {
				occupied: 0,
				wheels2: 0,
				wheels4: 0
			},
			"paseo": {
				occupied: 0,
				wheels2: 0,
				wheels4: 0
			}
		};
		activeLogs.forEach((log) => {
			if (log.check_out) return;
			const st = (log.logged_status || "").toLowerCase();
			if (st === "denied" || st === "exit" || st === "out" || st === "exited" || st === "exited_campus") return;
			const c = (log.campus || log.campus_gate || "").toLowerCase();
			let key = "main";
			if (c.includes("rnp")) key = "rnp";
			else if (c.includes("paseo")) key = "paseo";
			const vehicleKey = !log.registration_id || log.registration_id === 1 || Boolean(log.guest_id) || Boolean(log.vip_access) || st === "guest" || st === "vip" ? `log_${log.vehicle_log_id}` : `reg_${log.registration_id}`;
			if (!countedByCampus[key].has(vehicleKey)) {
				countedByCampus[key].add(vehicleKey);
				countsByCampus[key].occupied++;
				const vType = (log.vehicle_information?.type || log.registration?.vehicle_information?.type || "").toLowerCase();
				if (vType.includes("2") || vType.includes("motorcycle") || vType.includes("bike") || vType.includes("scooter")) countsByCampus[key].wheels2++;
				else countsByCampus[key].wheels4++;
			}
		});
		const nowMs = Date.now();
		const campuses = campusesList.map((name) => {
			const gate = name === "RNP" ? "rnp" : name === "PASEO" ? "paseo" : "main";
			const stats = countsByCampus[gate];
			const paData = allParkingCap.find((p) => p.campus && p.campus.toLowerCase() === name.toLowerCase() || p.campus_gate && p.campus_gate.toLowerCase() === gate);
			const campusEvents = allEvents.filter((e) => e.campus_gate && e.campus_gate.toLowerCase() === gate);
			const activeEvent = campusEvents.find((e) => {
				if (!e.is_active) return false;
				if (!e.end_date) return true;
				const endMs = new Date(e.end_date).getTime();
				return !isNaN(endMs) && endMs > nowMs;
			});
			const history = campusEvents.filter((e) => {
				if (!e.is_active) return true;
				if (!e.end_date) return false;
				const endMs = new Date(e.end_date).getTime();
				return !isNaN(endMs) && endMs <= nowMs;
			}).slice(0, 30);
			const capacity = paData?.parking_capacity ?? paData?.capacity ?? 200;
			const occupied = stats.occupied;
			const available = Math.max(0, capacity - occupied);
			return {
				name,
				capacity,
				occupied,
				available,
				unoccupied: available,
				wheels2: stats.wheels2,
				wheels4: stats.wheels4,
				event_name: activeEvent?.event_name ?? "",
				event_start: activeEvent?.start_date ?? "",
				event_end: activeEvent?.end_date ?? "",
				history
			};
		});
		setCachedCapacity(campuses);
		return {
			userEmail: locals.user.email,
			userRole: locals.user.role,
			campuses
		};
	} catch (e) {
		console.error("Error loading security capacity:", e);
		return {
			userEmail: locals.user.email,
			userRole: locals.user.role,
			campuses: campusesList.map((name) => ({
				name,
				capacity: 200,
				occupied: 0,
				available: 200,
				unoccupied: 200,
				wheels2: 0,
				wheels4: 0,
				event_name: "",
				event_start: "",
				event_end: "",
				history: []
			}))
		};
	}
};
//#endregion
export { load };
