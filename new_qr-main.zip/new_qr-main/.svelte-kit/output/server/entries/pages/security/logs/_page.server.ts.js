import { redirect } from "@sveltejs/kit";
//#region src/routes/security/logs/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user) throw redirect(303, "/login");
	if (locals.user.role !== "security") {
		if (locals.user.role === "osa") throw redirect(303, "/osa/dashboard");
		else if (locals.user.role === "dean") throw redirect(303, "/dean");
		else throw redirect(303, "/login");
	}
	return {
		userEmail: locals.user.email,
		userRole: locals.user.role
	};
};
//#endregion
export { load };
