import { t as supabase } from "../../../../chunks/supabase.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/security/complaints/+page.server.ts
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "security") throw redirect(302, "/login");
	try {
		const { count: unreadComplaints } = await supabase.from("incident_report").select("*", {
			count: "exact",
			head: true
		}).eq("status", "pending");
		return {
			userEmail: locals.user.email,
			userRole: locals.user.role,
			unreadComplaints: unreadComplaints || 0
		};
	} catch (error) {
		console.error("Error loading security complaints page:", error);
		return {
			userEmail: locals.user.email,
			userRole: locals.user.role,
			unreadComplaints: 0
		};
	}
};
//#endregion
export { load };
