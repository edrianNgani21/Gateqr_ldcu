import { t as supabase } from "../../../../chunks/supabase.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/security/settings/+page.server.ts
var userCache = /* @__PURE__ */ new Map();
var load = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "security") throw redirect(303, "/login");
	const cacheKey = locals.user.user_id || locals.user.email;
	const now = Date.now();
	const cached = userCache.get(cacheKey);
	if (cached && now - cached.timestamp < 15e3) return {
		userEmail: locals.user.email,
		userRole: "security",
		adminUser: cached.data
	};
	const { data: userRow } = await (locals.user.user_id ? supabase.from("users").select("user_id, email, user_type, identification, is_active, created_at, security_pin_hash").eq("user_id", locals.user.user_id) : supabase.from("users").select("user_id, email, user_type, identification, is_active, created_at, security_pin_hash").ilike("email", locals.user.email)).maybeSingle();
	const adminUser = {
		user_id: userRow?.user_id || locals.user.user_id,
		email: userRow?.email || locals.user.email,
		user_type: "Security Administrator",
		identification: userRow?.identification || "Admin",
		created_at: userRow?.created_at || null,
		is_active: userRow?.is_active ?? true,
		has_pin: !!userRow?.security_pin_hash
	};
	userCache.set(cacheKey, {
		data: adminUser,
		timestamp: now
	});
	return {
		userEmail: locals.user.email,
		userRole: "security",
		adminUser
	};
};
//#endregion
export { load };
