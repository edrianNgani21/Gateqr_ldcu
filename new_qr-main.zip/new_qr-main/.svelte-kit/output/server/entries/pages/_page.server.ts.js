import { t as supabase } from "../../chunks/supabase.js";
import { n as isApplicationFormOpen } from "../../chunks/applicationForm.js";
import { redirect } from "@sveltejs/kit";
//#region src/routes/+page.server.ts
var load = async ({ locals, url }) => {
	if (!locals.user) throw redirect(303, "/login");
	if (locals.user.role === "osa") throw redirect(303, "/osa/dashboard");
	else if (locals.user.role === "security") throw redirect(303, "/security");
	else if (locals.user.role === "dean") throw redirect(303, "/dean");
	else if (locals.user.role === "administrative") throw redirect(303, "/administrative");
	const { data: userRow } = await supabase.from("users").select("user_id").ilike("email", locals.user.email).maybeSingle();
	let isRenewal = false;
	let existingApplicationData = null;
	if (userRow?.user_id) {
		const { data: existingApp } = await supabase.from("registration").select(`
                *,
                department:department_id(
                    department_id,
                    academic_department,
                    administrative_department
                ),
                vehicle_information:vehicle_information_id(*)
            `).eq("user_id", userRow.user_id).not("status", "in", "(\"rejected\",\"revoked\")").order("created_at", { ascending: false }).limit(1).maybeSingle();
		if (existingApp) {
			const isExpired = existingApp.status === "expired" || existingApp.expires_at && new Date(existingApp.expires_at).getTime() < Date.now();
			if (url.searchParams.get("renew") === "true" && isExpired) {
				isRenewal = true;
				existingApplicationData = existingApp;
			} else throw redirect(303, "/status");
		}
	}
	const userEmail = locals.user.email;
	const applicationOpen = await isApplicationFormOpen();
	try {
		const { data: rows } = await supabase.from("department").select("*").eq("is_active", true).order("created_at", { ascending: true });
		const academicDepartments = [];
		const administrativeDepartments = [];
		(rows || []).forEach((r) => {
			const admin = r.administrative_department || r["Administrative Department"];
			const acad = r.academic_department || r["Academic Department"];
			if (admin) administrativeDepartments.push(admin);
			else if (acad) academicDepartments.push(acad);
			else if (r.department_name) academicDepartments.push(r.department_name);
		});
		const sortedAcad = Array.from(new Set(academicDepartments)).sort();
		const sortedAdmin = Array.from(new Set(administrativeDepartments)).sort();
		return {
			userEmail,
			applicationOpen,
			isRenewal,
			existingApplicationData,
			academicDepartments: sortedAcad,
			administrativeDepartments: sortedAdmin,
			departments: [...sortedAcad, ...sortedAdmin]
		};
	} catch (e) {
		return {
			userEmail,
			applicationOpen,
			isRenewal,
			existingApplicationData,
			academicDepartments: [],
			administrativeDepartments: [],
			departments: []
		};
	}
};
//#endregion
export { load };
