import "../../../../chunks/server.js";
import { t as AdminSettingsView } from "../../../../chunks/AdminSettingsView.js";
//#region src/routes/administrative/settings/+page.svelte
function _page($$renderer, $$props) {
	let { data } = $$props;
	AdminSettingsView($$renderer, {
		data,
		userRole: "administrative",
		showSidebar: true,
		pageTitle: "Settings",
		roleLabel: "Administrative Department Head"
	});
}
//#endregion
export { _page as default };
