import { t as private_env } from "../chunks/shared-server.js";
import { redirect } from "@sveltejs/kit";
import jwt from "jsonwebtoken";
//#region src/hooks.server.ts
var handle = async ({ event, resolve }) => {
	const token = event.cookies.get("gateqr_session");
	if (token) try {
		const decoded = jwt.verify(token, private_env.JWT_SECRET);
		event.locals.user = decoded;
	} catch (err) {
		event.locals.user = null;
		event.cookies.delete("gateqr_session", { path: "/" });
	}
	else event.locals.user = null;
	const url = event.url.pathname;
	if (url.startsWith("/osa")) {
		if (!event.locals.user || event.locals.user.role !== "osa") throw redirect(303, "/login");
	}
	if (url.startsWith("/security")) {
		if (!event.locals.user || event.locals.user.role !== "security") throw redirect(303, "/login");
	}
	if (url.startsWith("/dean") || url.startsWith("/administrative")) {
		if (!event.locals.user || event.locals.user.role !== "dean" && event.locals.user.role !== "administrative") throw redirect(303, "/login");
	}
	if (url.startsWith("/monitor")) {
		if (!event.locals.user || event.locals.user.role !== "security") throw redirect(303, "/login");
	}
	if (url.startsWith("/status") && !event.locals.user) throw redirect(303, "/login");
	return await resolve(event);
};
var handleError = ({ error, event }) => {
	console.error("[SERVER ERROR at " + event.url.pathname + "]:", error);
	return {
		message: error?.message || "Internal Error",
		stack: error?.stack
	};
};
//#endregion
export { handle, handleError };
