import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/gate/parking/+server.ts
function checkAuth(request) {
	return request.headers.get("X-Gate-Key") === private_env.PRIVATE_GATE_API_KEY;
}
var GET = async ({ request, locals }) => {
	const isGate = checkAuth(request);
	const isOsa = locals.user && (locals.user.role === "osa" || locals.user.role === "security");
	if (!isGate && !isOsa) return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { data: settingsData } = await supabase.from("parking_capacity").select("parking_capacity").order("date_time", { ascending: false }).limit(1).maybeSingle();
		const parking_capacity = settingsData?.parking_capacity ?? 0;
		const { data: lastParkingData } = await supabase.from("parking_capacity").select("slot_occupied, slot_unoccupied, date_time").order("date_time", { ascending: false }).limit(1).maybeSingle();
		const current_occupied = lastParkingData?.slot_occupied || 0;
		const current_unoccupied = lastParkingData?.slot_unoccupied || parking_capacity;
		const last_updated = lastParkingData?.date_time || null;
		const availability_percentage = parking_capacity > 0 ? Math.round(current_unoccupied / parking_capacity * 100) : 0;
		return json({
			parking_capacity,
			slot_occupied: current_occupied,
			slot_unoccupied: current_unoccupied,
			availability_percentage,
			last_updated,
			is_full: current_unoccupied === 0,
			is_available: current_unoccupied > 0
		});
	} catch (error) {
		console.error("[Gate] Parking availability error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { GET };
