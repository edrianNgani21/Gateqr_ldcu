import { t as supabase } from "../../../../../../chunks/supabase.js";
import { t as sendEmail } from "../../../../../../chunks/email.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/security/complaints/[id]/+server.ts
var PATCH = async ({ params, request, locals }) => {
	if (!locals.user || locals.user.role !== "security") return json({ error: "Unauthorized - Security access only" }, { status: 403 });
	try {
		const { id } = params;
		const { schedule, status, resolved_by, send_email } = await request.json();
		const { data: complaint, error: queryError } = await supabase.from("incident_report").select(`
                *,
                user:user_id(
                    email
                )
            `).eq("complaint_id", id).single();
		if (queryError || !complaint) return json({ error: "Complaint not found" }, { status: 404 });
		const updateData = {};
		if (schedule !== void 0) updateData.schedule = schedule;
		if (status !== void 0) updateData.status = status;
		if (status === "resolved") updateData.resolved_at = (/* @__PURE__ */ new Date()).toISOString();
		if (Object.keys(updateData).length > 0) {
			const { error: updateError } = await supabase.from("incident_report").update(updateData).eq("complaint_id", id);
			if (updateError) throw updateError;
		}
		if (schedule && schedule !== complaint.schedule && send_email) {
			new Date(schedule).toLocaleString("en-US", {
				weekday: "long",
				year: "numeric",
				month: "long",
				day: "numeric",
				hour: "2-digit",
				minute: "2-digit"
			});
			await sendEmail(complaint.user?.email, "Complaint Schedule Update", `Meeting Scheduled — The security office has scheduled a meeting with you. Please check your complaint details below.`, `<p>Meeting Scheduled — The security office has scheduled a meeting with you. Please check your complaint details below.</p>`, locals.user.email);
		}
		if (status === "resolved" && complaint.status !== "resolved") await sendEmail(complaint.user?.email, "Complaint Resolved", `Your complaint has been marked as resolved by the Security office.`, `<p>Your complaint has been marked as resolved by the Security office.</p>`);
		return json({ message: "Complaint updated successfully" });
	} catch (error) {
		console.error("Error updating complaint:", error);
		return json({ error: "Failed to update complaint" }, { status: 500 });
	}
};
var DELETE = async ({ params, locals }) => {
	if (!locals.user) return json({ error: "Unauthorized" }, { status: 401 });
	try {
		const { id } = params;
		const { data: complaint, error: queryError } = await supabase.from("incident_report").select(`
                *,
                user:user_id(
                    email
                )
            `).eq("complaint_id", id).single();
		if (queryError || !complaint) return json({ error: "Complaint not found" }, { status: 404 });
		if (locals.user.role !== "security") {
			if (complaint.user?.email !== locals.user.email) return json({ error: "Unauthorized" }, { status: 403 });
		}
		const { error: deleteError } = await supabase.from("incident_report").delete().eq("complaint_id", id);
		if (deleteError) throw deleteError;
		return json({ message: "Complaint deleted successfully" });
	} catch (error) {
		console.error("Error deleting complaint:", error);
		return json({ error: "Failed to delete complaint" }, { status: 500 });
	}
};
//#endregion
export { DELETE, PATCH };
