import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/gate/lookup/+server.ts
function checkAuth(request) {
	return request.headers.get("X-Gate-Key") === private_env.PRIVATE_GATE_API_KEY;
}
var GET = async ({ request, url }) => {
	if (!checkAuth(request)) return json({ error: "Unauthorized" }, { status: 403 });
	const qr = url.searchParams.get("qr");
	if (!qr) return json({ error: "Missing qr parameter" }, { status: 400 });
	try {
		let reg = null;
		const { data: uniqueCodeRows } = await supabase.from("registration").select(`
                *,
                user:user_id(email),
                department:department_id(department_id, academic_department, administrative_department),
                vehicle_information:vehicle_information_id(
                    plate_number,
                    brand,
                    color,
                    type
                )
            `).eq("qr_unique_code", qr).maybeSingle();
		if (uniqueCodeRows) reg = {
			...uniqueCodeRows,
			user_email: uniqueCodeRows.user?.email,
			department_name: uniqueCodeRows.department?.academic_department || uniqueCodeRows.department?.administrative_department || "-"
		};
		else {
			const regIdMatch = qr.match(/^REG-(\d+)$/i);
			if (regIdMatch) {
				const autoId = parseInt(regIdMatch[1]);
				const { data: rows } = await supabase.from("registration").select(`
                        *,
                        user:user_id(email),
                        department:department_id(department_id, academic_department, administrative_department),
                        vehicle_information:vehicle_information_id(
                            plate_number,
                            brand,
                            color,
                            type
                        )
                    `).eq("registration_id", autoId).single();
				if (rows) reg = {
					...rows,
					user_email: rows.user?.email,
					department_name: rows.department?.academic_department || rows.department?.administrative_department || "-"
				};
			} else {
				const { data: rows } = await supabase.from("registration").select(`
                        *,
                        user:user_id(email),
                        department:department_id(department_id, academic_department, administrative_department),
                        vehicle_information:vehicle_information_id(
                            plate_number,
                            brand,
                            color,
                            type
                        )
                    `).eq("registration_id", qr).single();
				if (rows) reg = {
					...rows,
					user_email: rows.user?.email,
					department_name: rows.department?.academic_department || rows.department?.administrative_department || "-"
				};
			}
		}
		if (!reg) return json({ registered: false }, { status: 404 });
		const { data: activeChange } = await supabase.from("modification_request").select("status").eq("registration_id", reg.registration_id).eq("status", "approved").maybeSingle();
		if (activeChange) return json({
			registered: false,
			error: "QR Code is deactivated pending new vehicle sticker release."
		}, { status: 403 });
		const { data: logRows } = await supabase.from("vehicle_log").select("vehicle_log_id, check_in, check_out").eq("registration_id", reg.registration_id).order("check_in", { ascending: false }).limit(1).single();
		let lastLog = null;
		let logged_status = "Outside";
		if (logRows) {
			const log = logRows;
			lastLog = {
				log_id: log.vehicle_log_id,
				type: log.check_out ? "out" : "in",
				date: new Date(log.check_in).toISOString().slice(0, 10),
				time: new Intl.DateTimeFormat("en-US", {
					hour: "2-digit",
					minute: "2-digit",
					hour12: false
				}).format(new Date(log.check_in))
			};
			logged_status = log.check_out ? "Outside" : "Inside";
		}
		return json({
			registered: true,
			registration: reg,
			lastLog,
			logged_status
		});
	} catch (error) {
		console.error("[Gate] Lookup error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { GET };
