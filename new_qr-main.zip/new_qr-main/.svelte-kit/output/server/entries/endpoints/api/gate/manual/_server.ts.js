import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { n as uploadToStorage } from "../../../../../chunks/storage.js";
import { json } from "@sveltejs/kit";
import crypto from "crypto";
//#region src/routes/api/gate/manual/+server.ts
function checkAuth(request) {
	return request.headers.get("X-Gate-Key") === private_env.PRIVATE_GATE_API_KEY;
}
function generateTicketNo() {
	const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	let result = "";
	for (let i = 0; i < 6; i++) result += chars.charAt(Math.floor(Math.random() * 36));
	return `GUEST-${result}`;
}
async function saveImage(pic_base64, type) {
	try {
		const base64Data = pic_base64.replace(/^data:image\/\w+;base64,/, "");
		const buffer = Buffer.from(base64Data, "base64");
		const filename = `gate/guest_${type}_${Date.now()}_${crypto.randomBytes(4).toString("hex")}.jpg`;
		return await uploadToStorage(filename, buffer, "image/jpeg");
	} catch (err) {
		console.error("[Gate] Error saving guest image to Supabase Storage:", err);
		return null;
	}
}
var POST = async ({ request }) => {
	if (!checkAuth(request)) return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { type, ticket_no, name, mobile, make_model, plate, id_number, purpose, reason, pic_base64, logged_status, campus } = await request.json();
		const rawCampus = campus || "Main Campus";
		let entryCampus = "Main Campus";
		if (rawCampus.toLowerCase().includes("rnp")) entryCampus = "RNP";
		else if (rawCampus.toLowerCase().includes("paseo")) entryCampus = "PASEO";
		if (!type || type !== "in" && type !== "out") return json({ error: "Invalid type (must be in or out)" }, { status: 400 });
		const picUrl = pic_base64 ? await saveImage(pic_base64, type) : null;
		if (type === "in") {
			if (!make_model || !plate) return json({ error: "make_model and plate are required for in" }, { status: 400 });
			let newTicketNo = ticket_no;
			if (!newTicketNo) {
				let isUnique = false;
				while (!isUnique) {
					newTicketNo = generateTicketNo();
					const { data: rows } = await supabase.from("guestlog").select("guest_id").eq("ticket_no", newTicketNo).maybeSingle();
					if (!rows) isUnique = true;
				}
			}
			const { error: insertError } = await supabase.from("guestlog").insert({
				ticket_no: newTicketNo,
				name: name || null,
				mobile: mobile || null,
				make_model,
				plate,
				id_number: id_number || null,
				purpose: purpose || reason || null,
				reason: reason || null,
				in: (/* @__PURE__ */ new Date()).toISOString(),
				pic_in: picUrl
			});
			if (insertError) throw insertError;
			const { data: settingsData } = await supabase.from("parking_capacity").select("parking_capacity").eq("campus", entryCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
			const parking_capacity = settingsData?.parking_capacity ?? 500;
			const { data: lastParkingData } = await supabase.from("parking_capacity").select("slot_occupied, slot_unoccupied").eq("campus", entryCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
			const current_occupied = lastParkingData?.slot_occupied || 0;
			const current_unoccupied = lastParkingData?.slot_unoccupied || parking_capacity;
			const new_occupied = current_occupied + 1;
			const new_unoccupied = Math.max(0, current_unoccupied - 1);
			const { data: vehicleLog } = await supabase.from("vehicle_log").select("vehicle_log_id").order("vehicle_log_id", { ascending: false }).limit(1).maybeSingle();
			const vehicle_log_id = vehicleLog?.vehicle_log_id || null;
			const { error: parkingError } = await supabase.from("parking_capacity").insert({
				vehicle_log_id,
				campus: entryCampus,
				parking_capacity,
				slot_occupied: new_occupied,
				slot_unoccupied: new_unoccupied,
				date_time: (/* @__PURE__ */ new Date()).toISOString()
			});
			if (parkingError) console.error("[Gate] Parking record error:", parkingError);
			return json({
				success: true,
				ticket_no: newTicketNo,
				message: "Guest entry recorded"
			});
		} else {
			if (!ticket_no) return json({ error: "ticket_no is required for out" }, { status: 400 });
			const { data: rows } = await supabase.from("guestlog").select("guest_id").eq("ticket_no", ticket_no).is("out", null).order("in", { ascending: false }).limit(1).maybeSingle();
			if (rows) {
				const { error: updateError } = await supabase.from("guestlog").update({
					out: (/* @__PURE__ */ new Date()).toISOString(),
					pic_out: picUrl,
					logged_status_out: logged_status || null
				}).eq("guest_id", rows.guest_id);
				if (updateError) throw updateError;
				const { data: settingsData } = await supabase.from("parking_capacity").select("parking_capacity").eq("campus", entryCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
				const parking_capacity = settingsData?.parking_capacity ?? 500;
				const { data: lastParkingData } = await supabase.from("parking_capacity").select("slot_occupied, slot_unoccupied").eq("campus", entryCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
				const current_occupied = lastParkingData?.slot_occupied || 0;
				const current_unoccupied = lastParkingData?.slot_unoccupied || parking_capacity;
				const new_occupied = Math.max(0, current_occupied - 1);
				const new_unoccupied = Math.min(parking_capacity, current_unoccupied + 1);
				const { data: vehicleLog } = await supabase.from("vehicle_log").select("vehicle_log_id").order("vehicle_log_id", { ascending: false }).limit(1);
				const vehicle_log_id = vehicleLog?.[0]?.vehicle_log_id || null;
				const { error: parkingError } = await supabase.from("parking_capacity").insert({
					vehicle_log_id,
					campus: entryCampus,
					parking_capacity,
					slot_occupied: new_occupied,
					slot_unoccupied: new_unoccupied,
					date_time: (/* @__PURE__ */ new Date()).toISOString()
				});
				if (parkingError) console.error("[Gate] Parking record error:", parkingError);
			} else {
				const { data: inRows } = await supabase.from("guestlog").select("make_model, plate").eq("ticket_no", ticket_no).order("in", { ascending: false }).limit(1).maybeSingle();
				const mm = inRows?.make_model || "Unknown";
				const pl = inRows?.plate || "Unknown";
				const { error: insertError } = await supabase.from("guestlog").insert({
					ticket_no,
					name: name || null,
					mobile: mobile || null,
					make_model: mm,
					plate: pl,
					purpose: purpose || reason || null,
					reason: reason || null,
					in: (/* @__PURE__ */ new Date()).toISOString(),
					out: (/* @__PURE__ */ new Date()).toISOString(),
					pic_out: picUrl,
					logged_status_out: logged_status || null
				});
				if (insertError) throw insertError;
				const { data: settingsData } = await supabase.from("parking_capacity").select("parking_capacity").eq("campus", entryCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
				const parking_capacity = settingsData?.parking_capacity ?? 500;
				const { data: lastParkingData } = await supabase.from("parking_capacity").select("slot_occupied, slot_unoccupied").eq("campus", entryCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
				const current_occupied = lastParkingData?.slot_occupied || 0;
				const current_unoccupied = lastParkingData?.slot_unoccupied || parking_capacity;
				const new_occupied = Math.max(0, current_occupied - 1);
				const new_unoccupied = Math.min(parking_capacity, current_unoccupied + 1);
				const { data: vehicleLog } = await supabase.from("vehicle_log").select("vehicle_log_id").order("vehicle_log_id", { ascending: false }).limit(1).maybeSingle();
				const vehicle_log_id = vehicleLog?.vehicle_log_id || null;
				const { error: parkingError } = await supabase.from("parking_capacity").insert({
					vehicle_log_id,
					campus: entryCampus,
					parking_capacity,
					slot_occupied: new_occupied,
					slot_unoccupied: new_unoccupied,
					date_time: (/* @__PURE__ */ new Date()).toISOString()
				});
				if (parkingError) console.error("[Gate] Parking record error:", parkingError);
			}
			return json({
				success: true,
				message: "Guest exit recorded"
			});
		}
	} catch (error) {
		console.error("[Gate] Manual entry error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { POST };
