import { json } from "@sveltejs/kit";
//#region src/routes/api/auth/logout/+server.ts
var POST = async ({ cookies }) => {
	cookies.delete("gateqr_session", { path: "/" });
	return json({ message: "Logged out successfully" });
};
//#endregion
export { POST };
