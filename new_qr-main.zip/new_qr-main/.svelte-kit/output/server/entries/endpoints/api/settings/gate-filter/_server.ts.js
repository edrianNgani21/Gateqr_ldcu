import { t as supabase } from "../../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/settings/gate-filter/+server.ts
async function GET({}) {
	try {
		const { data, error } = await supabase.from("parking_capacity").select("gate_access_filter, gate_access_filter_reason").eq("id", 1).single();
		if (error) return json({
			gate_access_filter: "all",
			gate_access_filter_reason: null
		});
		return json({
			gate_access_filter: data?.gate_access_filter || "all",
			gate_access_filter_reason: data?.gate_access_filter_reason
		});
	} catch (error) {
		console.error("Get gate filter error:", error);
		return json({ error: "Failed to get gate filter" }, { status: 500 });
	}
}
async function PUT({ request }) {
	try {
		const { gate_access_filter, gate_access_filter_reason } = await request.json();
		if (!gate_access_filter) return json({ error: "gate_access_filter is required" }, { status: 400 });
		if (![
			"all",
			"students",
			"employees",
			"visitors",
			"concessionaires"
		].includes(gate_access_filter)) return json({ error: "Invalid gate_access_filter value" }, { status: 400 });
		const { error: updateError } = await supabase.from("parking_capacity").update({
			gate_access_filter,
			gate_access_filter_reason: gate_access_filter_reason || null
		}).eq("id", 1);
		if (updateError) throw updateError;
		return json({ message: "Gate access filter updated successfully" });
	} catch (error) {
		console.error("Update gate filter error:", error);
		return json({ error: "Failed to update gate filter" }, { status: 500 });
	}
}
//#endregion
export { GET, PUT };
