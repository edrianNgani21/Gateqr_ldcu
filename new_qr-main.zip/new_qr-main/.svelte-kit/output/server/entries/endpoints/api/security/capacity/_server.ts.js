import { t as supabase } from "../../../../../chunks/supabase.js";
import { n as invalidateCapacityServerCache } from "../../../../../chunks/capacityCache.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/security/capacity/+server.ts
var POST = async ({ request, locals }) => {
	if (!locals.user || locals.user.role !== "security") return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { campus, parking_capacity, event_name, start_date, end_date, remove_event, check_expired } = await request.json();
		if (check_expired) {
			invalidateCapacityServerCache();
			const nowIso = (/* @__PURE__ */ new Date()).toISOString();
			await supabase.from("campus_event").update({ is_active: false }).eq("is_active", true).lt("end_date", nowIso);
			return json({ success: true });
		}
		if (!campus) return json({ error: "Invalid input data" }, { status: 400 });
		const gate = campus === "RNP" ? "rnp" : campus === "PASEO" ? "paseo" : "main";
		if (remove_event) {
			await supabase.from("campus_event").update({ is_active: false }).eq("campus_gate", gate).eq("is_active", true);
			const { data: latestPa } = await supabase.from("parking_capacity").select("parking_availability_id").or(`campus.eq.${campus},campus_gate.eq.${gate}`).order("date_time", { ascending: false }).limit(1).maybeSingle();
			if (latestPa) await supabase.from("parking_capacity").update({ event_name: null }).eq("parking_availability_id", latestPa.parking_availability_id);
			invalidateCapacityServerCache();
			return json({ success: true });
		}
		if (typeof parking_capacity !== "number") return json({ error: "Invalid capacity" }, { status: 400 });
		const isEventEnded = Boolean(event_name && end_date && new Date(end_date).getTime() <= Date.now());
		const effectiveEventName = !isEventEnded && event_name ? event_name : null;
		if (event_name && start_date && end_date) {
			await supabase.from("campus_event").update({ is_active: false }).eq("campus_gate", gate).eq("is_active", true);
			await supabase.from("campus_event").insert([{
				user_id: locals.user.user_id,
				campus_gate: gate,
				event_name,
				start_date,
				end_date,
				is_active: !isEventEnded
			}]);
		}
		const { data: lastData } = await supabase.from("parking_capacity").select("*").or(`campus.eq.${campus},campus_gate.eq.${gate}`).order("date_time", { ascending: false }).limit(1).maybeSingle();
		const occupied = lastData?.slot_occupied ?? lastData?.occupied ?? 0;
		const available = Math.max(0, parking_capacity - occupied);
		const nowIso = (/* @__PURE__ */ new Date()).toISOString();
		if (lastData) {
			const { error } = await supabase.from("parking_capacity").update({
				parking_capacity,
				capacity: parking_capacity,
				slot_occupied: occupied,
				occupied,
				slot_unoccupied: available,
				available,
				campus,
				campus_gate: gate,
				event_name: effectiveEventName,
				date_time: nowIso,
				recorded_at: nowIso
			}).eq("parking_availability_id", lastData.parking_availability_id);
			if (error) throw error;
		} else {
			let vehicle_log_id = null;
			const { data: vehicleLog } = await supabase.from("vehicle_log").select("vehicle_log_id").order("vehicle_log_id", { ascending: false }).limit(1).maybeSingle();
			if (vehicleLog?.vehicle_log_id) vehicle_log_id = vehicleLog.vehicle_log_id;
			else {
				const { data: anyPa } = await supabase.from("parking_capacity").select("vehicle_log_id").not("vehicle_log_id", "is", null).limit(1).maybeSingle();
				if (anyPa?.vehicle_log_id) vehicle_log_id = anyPa.vehicle_log_id;
				else vehicle_log_id = null;
			}
			const { error } = await supabase.from("parking_capacity").insert([{
				vehicle_log_id,
				campus,
				campus_gate: gate,
				parking_capacity,
				capacity: parking_capacity,
				slot_occupied: occupied,
				occupied,
				slot_unoccupied: available,
				available,
				event_name: effectiveEventName,
				date_time: nowIso,
				recorded_at: nowIso
			}]);
			if (error) {
				const { data: anyRecord } = await supabase.from("parking_capacity").select("*").limit(1).maybeSingle();
				if (anyRecord) {
					const { error: updateError } = await supabase.from("parking_capacity").insert([{
						vehicle_log_id: anyRecord.vehicle_log_id,
						campus,
						parking_capacity,
						slot_occupied: occupied,
						slot_unoccupied: available,
						event_name: effectiveEventName
					}]);
					if (updateError) {
						if (updateError.code === "23502" || updateError.code === "23503") return json({ error: "DATABASE ERROR: You must run \"ALTER TABLE parking_capacity ALTER COLUMN vehicle_log_id DROP NOT NULL;\" in your Supabase SQL Editor to initialize capacity!" }, { status: 400 });
						throw updateError;
					}
				} else {
					if (error.code === "23502" || error.code === "23503") return json({ error: "DATABASE ERROR: You must run \"ALTER TABLE parking_capacity ALTER COLUMN vehicle_log_id DROP NOT NULL;\" in your Supabase SQL Editor to initialize capacity!" }, { status: 400 });
					throw error;
				}
			}
		}
		invalidateCapacityServerCache();
		return json({ success: true });
	} catch (error) {
		console.error("Error updating capacity:", error);
		return json({ error: error.message || "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { POST };
