import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/gate/lookup-plate/+server.ts
function checkAuth(request) {
	return request.headers.get("X-Gate-Key") === private_env.PRIVATE_GATE_API_KEY;
}
var GET = async ({ request, url }) => {
	if (!checkAuth(request)) return json({ error: "Unauthorized" }, { status: 403 });
	const plate = url.searchParams.get("plate");
	const name = url.searchParams.get("name");
	if (!plate && !name) return json({ error: "Missing plate or name parameter" }, { status: 400 });
	try {
		let data;
		if (plate) {
			const { data: plateData, error: plateError } = await supabase.from("guestlog").select("*").eq("plate", plate).is("out", null).order("in", { ascending: false }).limit(1).maybeSingle();
			if (!plateError && plateData) data = plateData;
		}
		if (!data && name) {
			const { data: nameData, error: nameError } = await supabase.from("guestlog").select("*").ilike("name", `%${name}%`).is("out", null).order("in", { ascending: false }).limit(1).maybeSingle();
			if (!nameError && nameData) data = nameData;
		}
		if (data) return json({
			found: true,
			visitor: {
				guest_id: data.guest_id,
				ticket_no: data.ticket_no,
				name: data.name,
				mobile: data.mobile,
				make_model: data.make_model,
				plate: data.plate,
				id_number: data.id_number,
				purpose: data.purpose,
				reason: data.reason,
				in_time: data.in,
				logged_status: data.logged_status
			}
		});
		else return json({
			found: false,
			message: "No active guest found with the provided information"
		});
	} catch (error) {
		console.error("[Gate] Lookup error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { GET };
