import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { n as uploadToStorage } from "../../../../../chunks/storage.js";
import { json } from "@sveltejs/kit";
import crypto from "crypto";
//#region src/routes/api/gate/exit/+server.ts
function checkAuth(request) {
	return request.headers.get("X-Gate-Key") === private_env.PRIVATE_GATE_API_KEY;
}
var POST = async ({ request }) => {
	if (!checkAuth(request)) return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { registration_id, pic_base64, logged_status, campus } = await request.json();
		if (!registration_id) return json({ error: "Missing registration_id" }, { status: 400 });
		const { data: regData } = await supabase.from("registration").select("vehicle_information_id").eq("registration_id", registration_id).single();
		if (!regData) return json({ error: "Registration not found" }, { status: 404 });
		const { data: activeChange } = await supabase.from("modification_request").select("status").eq("registration_id", registration_id).eq("status", "approved").maybeSingle();
		if (activeChange) return json({ error: "QR Code is deactivated pending new vehicle sticker release." }, { status: 403 });
		const vehicle_information_id = regData.vehicle_information_id;
		let picUrl = null;
		if (pic_base64) try {
			const base64Data = pic_base64.replace(/^data:image\/\w+;base64,/, "");
			const buffer = Buffer.from(base64Data, "base64");
			const filename = `gate/out_${registration_id}_${Date.now()}_${crypto.randomBytes(4).toString("hex")}.jpg`;
			picUrl = await uploadToStorage(filename, buffer, "image/jpeg");
		} catch (err) {
			console.error("[Gate] Error saving exit image to Supabase Storage:", err);
		}
		const { data: rows, error: queryError } = await supabase.from("vehicle_log").select("vehicle_log_id, campus_gate").eq("registration_id", registration_id).is("check_out", null).order("check_in", { ascending: false }).limit(1).single();
		const rawExitCampus = (rows?.campus_gate || campus || "main").toString().toLowerCase();
		let gateVal = "main";
		if (rawExitCampus.includes("rnp")) gateVal = "rnp";
		else if (rawExitCampus.includes("paseo")) gateVal = "paseo";
		const exitCampus = gateVal === "rnp" ? "RNP" : gateVal === "paseo" ? "PASEO" : "Main Campus";
		if (rows && !queryError) {
			const { error: updateError } = await supabase.from("vehicle_log").update({
				check_out: (/* @__PURE__ */ new Date()).toISOString(),
				logged_status: "exited_campus"
			}).eq("vehicle_log_id", rows.vehicle_log_id);
			if (updateError) throw updateError;
			const vehicle_log_id = rows.vehicle_log_id;
			const { data: settingsData } = await supabase.from("parking_capacity").select("parking_capacity").eq("campus", exitCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
			const parking_capacity = settingsData?.parking_capacity ?? 500;
			const { data: lastParkingData } = await supabase.from("parking_capacity").select("slot_occupied, slot_unoccupied").eq("campus", exitCampus).order("date_time", { ascending: false }).limit(1).maybeSingle();
			let current_occupied = lastParkingData?.slot_occupied;
			if (current_occupied === void 0 || current_occupied === null) {
				const { data: insideLogs } = await supabase.from("vehicle_log").select("campus, registration:registration_id(campus)").is("check_out", null);
				current_occupied = (insideLogs || []).filter((l) => {
					const c = (l.campus || l.registration?.campus || "").toLowerCase();
					if (exitCampus === "RNP") return c.includes("rnp");
					if (exitCampus === "PASEO") return c.includes("paseo");
					return !c.includes("rnp") && !c.includes("paseo");
				}).length;
			}
			const new_occupied = Math.max(0, current_occupied - 1);
			const new_unoccupied = Math.min(parking_capacity, Math.max(0, parking_capacity - new_occupied));
			const { error: parkingError } = await supabase.from("parking_capacity").insert({
				vehicle_log_id,
				campus: exitCampus,
				parking_capacity,
				slot_occupied: new_occupied,
				slot_unoccupied: new_unoccupied,
				date_time: (/* @__PURE__ */ new Date()).toISOString()
			});
			if (parkingError) console.error("[Gate] Parking capacity exit insert error:", parkingError);
		} else {
			const { error: insertError } = await supabase.from("vehicle_log").insert({
				registration_id,
				vehicle_information_id,
				check_out: (/* @__PURE__ */ new Date()).toISOString(),
				pic_out: picUrl,
				logged_status_out: logged_status || null
			});
			if (insertError) throw insertError;
		}
		return json({
			success: true,
			message: "Exit recorded"
		});
	} catch (error) {
		console.error("[Gate] Exit error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { POST };
