import { t as generateStyledQRBuffer } from "../../../../chunks/qr.js";
import QRCode from "qrcode";
//#region src/routes/api/qr/+server.ts
var GET = async ({ url }) => {
	const code = url.searchParams.get("code") || url.searchParams.get("text") || "PENDING";
	const role = url.searchParams.get("role") || "student";
	try {
		const buffer = await generateStyledQRBuffer(code, role);
		return new Response(new Uint8Array(buffer), {
			status: 200,
			headers: {
				"Content-Type": "image/png",
				"Cache-Control": "public, max-age=86400, s-maxage=86400"
			}
		});
	} catch (styledErr) {
		console.warn("[QR API] Styled generation fallback to standard QR:", styledErr);
		try {
			const fallbackBuffer = await QRCode.toBuffer(code, {
				width: 320,
				margin: 2,
				color: {
					dark: "#000000",
					light: "#ffffff"
				}
			});
			return new Response(new Uint8Array(fallbackBuffer), {
				status: 200,
				headers: {
					"Content-Type": "image/png",
					"Cache-Control": "public, max-age=86400"
				}
			});
		} catch (fallbackErr) {
			console.error("[QR API] Failed to generate QR code:", fallbackErr);
			return new Response("Failed to generate QR code", { status: 500 });
		}
	}
};
//#endregion
export { GET };
