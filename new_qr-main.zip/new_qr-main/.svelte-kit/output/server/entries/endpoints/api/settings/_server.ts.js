import { t as supabase } from "../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/settings/+server.ts
var GET = async ({ locals }) => {
	if (!(locals.user && (locals.user.role === "osa" || locals.user.role === "security"))) return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { data: row } = await supabase.from("parking_capacity").select("parking_capacity, max_capacity").order("date_time", { ascending: false }).limit(1).maybeSingle();
		const capacity = row?.parking_capacity ?? row?.max_capacity ?? 500;
		return json({
			max_capacity: capacity,
			parking_capacity: capacity
		});
	} catch (error) {
		console.error("[Settings] GET error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
var PUT = async ({ request, locals }) => {
	if (!(locals.user && (locals.user.role === "osa" || locals.user.role === "security"))) return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const body = await request.json();
		const newCap = typeof body.parking_capacity === "number" ? body.parking_capacity : body.max_capacity;
		if (typeof newCap !== "number") return json({ error: "parking_capacity must be a number" }, { status: 400 });
		const { data: latest } = await supabase.from("parking_capacity").select("parking_availability_id").order("date_time", { ascending: false }).limit(1).maybeSingle();
		if (latest?.parking_availability_id) {
			const { error: updateError } = await supabase.from("parking_capacity").update({
				parking_capacity: newCap,
				max_capacity: newCap
			}).eq("parking_availability_id", latest.parking_availability_id);
			if (updateError) throw updateError;
		} else {
			const { error: insertError } = await supabase.from("parking_capacity").insert({
				parking_capacity: newCap,
				max_capacity: newCap,
				vehicle_log_id: 1
			});
			if (insertError) throw insertError;
		}
		return json({
			success: true,
			max_capacity: newCap,
			parking_capacity: newCap
		});
	} catch (error) {
		console.error("[Settings] PUT error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { GET, PUT };
