import { t as supabase } from "../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
import bcrypt from "bcryptjs";
//#region src/routes/api/deans/+server.ts
async function createNotification(userId, notificationType, message, actorId, actionType, targetEntityType, targetEntityId) {
	try {
		await supabase.from("notification").insert({
			user_id: userId,
			notification_type: notificationType,
			message,
			activity: message,
			actor_id: actorId || null,
			action_type: actionType || null,
			target_entity_type: targetEntityType || null,
			target_entity_id: targetEntityId || null,
			is_read: false
		});
	} catch (e) {
		console.error("Failed to create notification:", e);
	}
}
var GET = async ({ locals }) => {
	if (!locals.user || locals.user.role !== "osa") return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { data: rows } = await supabase.from("users").select("*").or("identification.eq.faculty,user_type.eq.dean").order("created_at", { ascending: false });
		const deans = rows?.map((dean) => ({
			user_id: dean.user_id,
			email: dean.email,
			department_id: dean.department_id,
			created_at: dean.created_at
		})) || [];
		return json({ deans });
	} catch (error) {
		console.error("Failed to fetch deans:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
var POST = async ({ request, locals }) => {
	if (!locals.user || locals.user.role !== "osa") return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { email, department_id, password } = await request.json();
		if (!email) return json({ error: "Email is required" }, { status: 400 });
		if (!password || typeof password !== "string" || password.trim().length < 6) return json({ error: "Password is required and must be at least 6 characters" }, { status: 400 });
		const password_hash = bcrypt.hashSync(password.trim(), 10);
		const { data: existingUser } = await supabase.from("users").select("user_id, user_type, identification, department_id").ilike("email", email.trim().toLowerCase()).maybeSingle();
		let userId;
		if (existingUser) {
			const { error: updateUserError } = await supabase.from("users").update({
				user_type: "dean",
				identification: "faculty",
				department_id: department_id || null,
				password_hash,
				is_active: true
			}).eq("user_id", existingUser.user_id);
			if (updateUserError) throw updateUserError;
			userId = existingUser.user_id;
		} else {
			const { data: newUser, error: createUserError } = await supabase.from("users").insert({
				email: email.trim().toLowerCase(),
				user_type: "dean",
				identification: "faculty",
				department_id: department_id || null,
				password_hash,
				is_active: true
			}).select("user_id").single();
			if (createUserError) throw createUserError;
			userId = newUser.user_id;
		}
		if (locals.user?.user_id) await createNotification(locals.user.user_id, "dean_added", `Dean account assigned successfully for ${email.toLowerCase()}.`, locals.user.user_id, "create_dean", "users", userId);
		return json({ message: "Dean account created successfully" }, { status: 201 });
	} catch (error) {
		console.error("Failed to create dean:", error);
		return json({ error: error?.message || "Internal Server Error" }, { status: 500 });
	}
};
var PUT = async ({ request, locals }) => {
	if (!locals.user || locals.user.role !== "osa") return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { user_id, email, department_id, password } = await request.json();
		if (!user_id) return json({ error: "User ID is required" }, { status: 400 });
		const { data: currentDean, error: fetchError } = await supabase.from("users").select("user_id, email, department_id").eq("user_id", user_id).single();
		if (fetchError) throw fetchError;
		const updates = {
			user_type: "dean",
			identification: "faculty"
		};
		if (email && email !== currentDean.email) updates.email = email.trim().toLowerCase();
		if (department_id !== void 0) updates.department_id = department_id || null;
		if (password && typeof password === "string" && password.trim().length >= 6) updates.password_hash = bcrypt.hashSync(password.trim(), 10);
		const { error: updateUserError } = await supabase.from("users").update(updates).eq("user_id", user_id);
		if (updateUserError) throw updateUserError;
		return json({ message: "Dean updated successfully" });
	} catch (error) {
		console.error("Failed to update dean:", error);
		return json({ error: error?.message || "Internal Server Error" }, { status: 500 });
	}
};
var DELETE = async ({ request, locals }) => {
	if (!locals.user || locals.user.role !== "osa") return json({ error: "Unauthorized" }, { status: 403 });
	try {
		const { user_id } = await request.json();
		if (!user_id) return json({ error: "User ID is required" }, { status: 400 });
		const { error: deleteUserError } = await supabase.from("users").delete().eq("user_id", user_id);
		if (deleteUserError) throw deleteUserError;
		return json({ message: "Dean account deleted successfully" });
	} catch (error) {
		console.error("Failed to delete dean:", error);
		return json({ error: error?.message || "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { DELETE, GET, POST, PUT };
