import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { json } from "@sveltejs/kit";
//#region src/routes/api/gate/logs/+server.ts
var GET = async ({ request, url, locals }) => {
	const isGate = request.headers.get("X-Gate-Key") === private_env.GATE_API_KEY;
	const isOsa = locals.user && (locals.user.role === "osa" || locals.user.role === "security");
	if (!isGate && !isOsa) return json({ error: "Unauthorized" }, { status: 403 });
	const dateParam = url.searchParams.get("date") || "";
	const search = (url.searchParams.get("search") || "").trim().toLowerCase();
	const boundFilter = url.searchParams.get("bound") || "all";
	const page = Math.max(1, parseInt(url.searchParams.get("page") || "1"));
	const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get("limit") || "25")));
	const rolesFilter = url.searchParams.get("roles")?.split(",").filter(Boolean) || [];
	const campusFilter = url.searchParams.get("campus");
	try {
		let dateFilter = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		const dateParams = [];
		if (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)) {
			dateFilter = dateParam;
			dateParams.push(dateParam);
		}
		const tomorrow = new Date(new Date(dateFilter).getTime() + 864e5).toISOString().split("T")[0];
		let regRows = [];
		let { data, error } = await supabase.from("vehicle_log").select(`
                vehicle_log_id,
                vehicle_information:vehicle_information_id(plate_number),
                registration:registration_id(first_name, last_name, role),
                guest:guest_id(guest_id, plate_number, id_number, purpose, timestamp),
                guest_id,
                check_in,
                check_out,
                logged_status,
                vip_access,
                reason,
                campus,
                created_at
            `).gte("check_in", dateFilter).lt("check_in", tomorrow);
		if ((!data || data.length === 0) && !error) {
			const { data: createdData } = await supabase.from("vehicle_log").select(`
                    vehicle_log_id,
                    vehicle_information:vehicle_information_id(plate_number),
                    registration:registration_id(first_name, last_name, role),
                    guest:guest_id(guest_id, plate_number, id_number, purpose, timestamp),
                    guest_id,
                    check_in,
                    check_out,
                    logged_status,
                    vip_access,
                    reason,
                    campus,
                    created_at
                `).gte("created_at", dateFilter).lt("created_at", tomorrow);
			if (createdData) data = createdData;
		}
		if (data) regRows = data;
		const logs = [];
		const normalizedRolesFilter = rolesFilter.map((r) => r.toLowerCase().trim());
		regRows.forEach((row) => {
			const inDate = new Date(row.check_in || row.created_at || Date.now());
			const isInside = !(row.check_out !== null && String(row.check_out).trim() !== "" && String(row.check_out).trim() !== "null") && String(row.logged_status || "").toLowerCase() !== "exited" && String(row.logged_status || "").toLowerCase() !== "out" && String(row.logged_status || "").toLowerCase() !== "exited_campus";
			const statusDisplay = isInside ? "INSIDE CAMPUS" : "EXITED";
			const st = String(row.logged_status || "").toLowerCase();
			const guestRecord = Array.isArray(row.guest) ? row.guest[0] : row.guest;
			const isVip = Boolean(row.vip_access) || Boolean(row.is_vip) || st === "vip" || st.includes("vip");
			const isGuest = Boolean(guestRecord) || st === "guest" || st.includes("guest");
			let rawRole = (row.registration?.role || "").toLowerCase().trim();
			let role = "Driver";
			if (rawRole === "vps") role = "VPS";
			else if (rawRole === "vip") role = "VIP";
			else if (rawRole === "concessionaire" || rawRole === "concessionnaire") role = "Concessionaire";
			else if (rawRole === "administrator" || rawRole === "admin") role = "Administrator";
			else if (rawRole) role = rawRole.charAt(0).toUpperCase() + rawRole.slice(1);
			let driverName = `${row.registration?.first_name || ""} ${row.registration?.last_name || ""}`.trim() || "Driver";
			let plate = row.vehicle_information?.plate_number || "No Plate";
			if (isVip) {
				role = "VIP";
				driverName = "VIP Access";
				plate = "VIP";
			} else if (isGuest) {
				role = "Guest";
				if (guestRecord) {
					driverName = guestRecord.purpose ? `Guest (${guestRecord.purpose})` : guestRecord.id_number ? `Guest (ID: ${guestRecord.id_number})` : "Guest";
					plate = guestRecord.plate_number || "Guest Vehicle";
				} else {
					driverName = "Guest";
					plate = "Guest Vehicle";
				}
			}
			if (normalizedRolesFilter.length > 0) {
				const rLower = role.toLowerCase().trim();
				if (!normalizedRolesFilter.some((selected) => {
					const sLower = selected.toLowerCase().trim();
					if (sLower === rLower) return true;
					if (sLower === "employee" && (rLower === "staff" || rLower === "faculty" || rLower === "employee")) return true;
					if (sLower === "staff" && (rLower === "staff" || rLower === "employee")) return true;
					if (sLower === "administrator" && (rLower === "administrator" || rLower === "admin")) return true;
					if (sLower === "concessionaire" && (rLower === "concessionaire" || rLower === "concessionnaire")) return true;
					if (sLower === "visitor" && (rLower === "visitor" || rLower === "guest")) return true;
					return false;
				})) return;
			}
			if (campusFilter && campusFilter.trim() !== "") {
				const cf = campusFilter.toLowerCase().trim();
				const targetCampus = cf.includes("main") ? "main" : cf.includes("rnp") ? "rnp" : cf.includes("paseo") ? "paseo" : cf;
				const rowCampus = (row.campus || row.registration?.campus || "").toLowerCase().trim();
				if (!(targetCampus === "main" ? rowCampus.includes("main") || rowCampus === "" : rowCampus.includes(targetCampus))) return;
			}
			if (boundFilter === "all" || boundFilter === "in" && isInside || boundFilter === "out" && !isInside) {
				const displayCampus = row.campus || row.registration?.campus || "Main Campus";
				logs.push({
					vehicle_log_id: row.vehicle_log_id,
					plate,
					driver_name: driverName,
					role,
					is_vip: isVip,
					is_guest: isGuest,
					guest_details: guestRecord ? {
						guest_id: guestRecord.guest_id,
						plate_number: guestRecord.plate_number,
						id_number: guestRecord.id_number,
						purpose: guestRecord.purpose,
						timestamp: guestRecord.timestamp
					} : isGuest ? {
						guest_id: row.guest_id || null,
						plate_number: plate,
						id_number: "N/A",
						purpose: row.reason || "Visitor",
						timestamp: row.check_in || row.created_at
					} : null,
					campus: displayCampus || "Main Campus",
					bound: isInside ? "in" : "out",
					check_in: row.check_in,
					check_out: row.check_out,
					logged_status: statusDisplay,
					created_at: row.created_at,
					timestamp: inDate.getTime()
				});
			}
		});
		logs.sort((a, b) => b.timestamp - a.timestamp);
		let filtered = logs;
		if (search) {
			const terms = search.split(/\s+/).filter(Boolean);
			filtered = logs.filter((l) => {
				const searchableFields = [
					String(l.vehicle_log_id),
					String(l.plate),
					String(l.driver_name),
					String(l.role),
					String(l.logged_status),
					String(l.campus)
				].join(" ").toLowerCase();
				return terms.every((term) => searchableFields.includes(term));
			});
		}
		const total = filtered.length;
		const totalPages = Math.max(1, Math.ceil(total / limit));
		const safePage = Math.min(page, totalPages);
		const sliced = filtered.slice((safePage - 1) * limit, safePage * limit);
		return json({
			logs: sliced,
			total,
			page: safePage,
			totalPages,
			limit
		});
	} catch (error) {
		console.error("[Gate] Logs error:", error);
		return json({ error: "Internal Server Error" }, { status: 500 });
	}
};
//#endregion
export { GET };
