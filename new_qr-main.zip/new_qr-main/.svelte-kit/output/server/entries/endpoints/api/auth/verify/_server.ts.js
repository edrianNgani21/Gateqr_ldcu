import { t as private_env } from "../../../../../chunks/shared-server.js";
import { t as supabase } from "../../../../../chunks/supabase.js";
import { n as verifyOtp } from "../../../../../chunks/otp.js";
import { json } from "@sveltejs/kit";
import jwt from "jsonwebtoken";
//#region src/routes/api/auth/verify/+server.ts
var POST = async ({ request, cookies }) => {
	try {
		const body = await request.json();
		const rawEmail = body.email;
		const otp = body.otp;
		if (!rawEmail || !otp) return json({ error: "Email and 6-digit verification code are required" }, { status: 400 });
		const email = rawEmail.trim().toLowerCase();
		const verifyResult = verifyOtp(email, otp);
		if (!verifyResult.valid) return json({ error: verifyResult.reason || "Invalid verification code" }, { status: 400 });
		const { data: userList, error: queryError } = await supabase.from("users").select("user_id, email, user_type, identification, department_id, is_active").ilike("email", email).limit(1);
		if (queryError) {
			console.error("[Verify] Database error querying user:", queryError);
			return json({ error: "Database error. Please try again." }, { status: 500 });
		}
		let user = userList && userList.length > 0 ? userList[0] : null;
		if (user) {
			if (user.is_active === false) return json({ error: "Account is deactivated. Please contact OSA administration." }, { status: 403 });
		} else {
			const { data: newUser, error: createError } = await supabase.from("users").insert({
				email,
				user_type: "applicant",
				identification: "student",
				is_active: true
			}).select("user_id, email, user_type, identification, department_id, is_active").single();
			if (createError || !newUser) {
				console.error("[Verify] Failed to create user:", createError);
				return json({ error: "Failed to create applicant profile" }, { status: 500 });
			}
			user = newUser;
		}
		const { data: regList } = await supabase.from("registration").select("registration_id, status").eq("user_id", user.user_id).order("created_at", { ascending: false }).limit(1);
		const hasExistingApplication = regList && regList.length > 0;
		const redirectUrl = hasExistingApplication ? "/status" : "/";
		const token = jwt.sign({
			email: user.email,
			role: "applicant",
			user_type: "Applicants",
			department_id: null,
			user_id: user.user_id
		}, private_env.JWT_SECRET, { expiresIn: "7d" });
		cookies.set("gateqr_session", token, {
			path: "/",
			httpOnly: true,
			secure: process.env.NODE_ENV === "production",
			sameSite: "lax",
			maxAge: 604800
		});
		console.log(`[Verify] OTP successfully verified for ${user.email} -> ${redirectUrl}`);
		return json({
			success: true,
			message: "Email verified successfully",
			role: "applicant",
			redirectUrl,
			hasExistingApplication
		});
	} catch (error) {
		console.error("[Verify Error]:", error);
		return json({ error: "An unexpected error occurred during OTP verification" }, { status: 500 });
	}
};
//#endregion
export { POST };
