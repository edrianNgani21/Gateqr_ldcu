import * as server from '../entries/pages/osa/_page.server.ts.js';

export const index = 12;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/osa/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/osa/+page.server.ts";
export const imports = ["_app/immutable/nodes/12.BGV_o4lc.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Cunm1v_v.js","_app/immutable/chunks/Bao1sJBs.js","_app/immutable/chunks/BFbPbdln.js","_app/immutable/chunks/Buaha7Qg.js","_app/immutable/chunks/CnJdtZHl.js","_app/immutable/chunks/SO5JeItD.js","_app/immutable/chunks/ZYDH7GWM.js"];
export const stylesheets = ["_app/immutable/assets/AppShell._47E6fQk.css","_app/immutable/assets/NavBar.5VMX8Qtd.css","_app/immutable/assets/ApplicationCard.DKpiWnID.css","_app/immutable/assets/ActionBar.BkfPXD_q.css","_app/immutable/assets/12.DgjjqQwZ.css"];
export const fonts = [];
