import * as server from '../entries/pages/administrative/_page.server.ts.js';

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/administrative/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/administrative/+page.server.ts";
export const imports = ["_app/immutable/nodes/4.DAQTfg-l.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Bao1sJBs.js","_app/immutable/chunks/Cunm1v_v.js","_app/immutable/chunks/BFbPbdln.js","_app/immutable/chunks/Buaha7Qg.js"];
export const stylesheets = ["_app/immutable/assets/AppShell._47E6fQk.css","_app/immutable/assets/4.S-pTVpNI.css"];
export const fonts = [];
