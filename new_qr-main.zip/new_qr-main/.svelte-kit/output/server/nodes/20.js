

export const index = 20;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/otp/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/20.CcIov0p4.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Cunm1v_v.js","_app/immutable/chunks/BFbPbdln.js"];
export const stylesheets = ["_app/immutable/assets/20.BhmjPNI_.css"];
export const fonts = [];
