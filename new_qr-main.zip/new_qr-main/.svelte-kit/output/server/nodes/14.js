import * as server from '../entries/pages/osa/admin/manage/_page.server.ts.js';

export const index = 14;
export { server };
export const server_id = "src/routes/osa/admin/manage/+page.server.ts";
export const imports = [];
export const stylesheets = [];
export const fonts = [];
