import * as server from '../entries/pages/administrative/settings/_page.server.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/administrative/settings/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/administrative/settings/+page.server.ts";
export const imports = ["_app/immutable/nodes/5.DcwrJBHn.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/C9PVEUQU.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/Bao1sJBs.js","_app/immutable/chunks/Cunm1v_v.js","_app/immutable/chunks/BFbPbdln.js","_app/immutable/chunks/CnJdtZHl.js"];
export const stylesheets = ["_app/immutable/assets/AppShell._47E6fQk.css","_app/immutable/assets/NavBar.5VMX8Qtd.css","_app/immutable/assets/AdminSettingsView.DgeB8sJm.css"];
export const fonts = [];
