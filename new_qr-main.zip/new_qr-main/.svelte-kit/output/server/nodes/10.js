

export const index = 10;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/login/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/10.CftKLrWe.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/BFbPbdln.js"];
export const stylesheets = ["_app/immutable/assets/10.DfYBqCgl.css"];
export const fonts = [];
