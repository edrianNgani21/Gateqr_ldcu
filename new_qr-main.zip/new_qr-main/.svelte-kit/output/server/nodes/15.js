import * as server from '../entries/pages/osa/change-requests/_page.server.ts.js';

export const index = 15;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/osa/change-requests/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/osa/change-requests/+page.server.ts";
export const imports = ["_app/immutable/nodes/15.Dr_qQmb_.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Bao1sJBs.js","_app/immutable/chunks/Cunm1v_v.js","_app/immutable/chunks/BFbPbdln.js","_app/immutable/chunks/CnJdtZHl.js"];
export const stylesheets = ["_app/immutable/assets/AppShell._47E6fQk.css","_app/immutable/assets/NavBar.5VMX8Qtd.css","_app/immutable/assets/15.DD7NgRM7.css"];
export const fonts = [];
