import * as server from '../entries/pages/osa/admin/_page.server.ts.js';

export const index = 13;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/osa/admin/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/osa/admin/+page.server.ts";
export const imports = ["_app/immutable/nodes/13.JDgTkLUS.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Bao1sJBs.js","_app/immutable/chunks/Cunm1v_v.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/CnJdtZHl.js"];
export const stylesheets = ["_app/immutable/assets/AppShell._47E6fQk.css","_app/immutable/assets/NavBar.5VMX8Qtd.css","_app/immutable/assets/13.v39aQg0j.css"];
export const fonts = [];
