export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["liceo-logo.png","robots.txt","rodelsa-image.png"]),
	mimeTypes: {".png":"image/png",".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.BlH7xAUd.js",app:"_app/immutable/entry/app.CiI43Dev.js",imports:["_app/immutable/entry/start.BlH7xAUd.js","_app/immutable/chunks/DpQo4V1O.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/entry/app.CiI43Dev.js","_app/immutable/chunks/By7p0prW.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:true},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js')),
			__memo(() => import('./nodes/9.js')),
			__memo(() => import('./nodes/10.js')),
			__memo(() => import('./nodes/11.js')),
			__memo(() => import('./nodes/12.js')),
			__memo(() => import('./nodes/13.js')),
			__memo(() => import('./nodes/14.js')),
			__memo(() => import('./nodes/15.js')),
			__memo(() => import('./nodes/16.js')),
			__memo(() => import('./nodes/17.js')),
			__memo(() => import('./nodes/18.js')),
			__memo(() => import('./nodes/19.js')),
			__memo(() => import('./nodes/20.js')),
			__memo(() => import('./nodes/21.js')),
			__memo(() => import('./nodes/22.js')),
			__memo(() => import('./nodes/23.js')),
			__memo(() => import('./nodes/24.js')),
			__memo(() => import('./nodes/25.js')),
			__memo(() => import('./nodes/26.js')),
			__memo(() => import('./nodes/27.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/administrative",
				pattern: /^\/administrative\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/administrative/settings",
				pattern: /^\/administrative\/settings\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/api/administrative/applications",
				pattern: /^\/api\/administrative\/applications\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/administrative/applications/_server.ts.js'))
			},
			{
				id: "/api/apply",
				pattern: /^\/api\/apply\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/apply/_server.ts.js'))
			},
			{
				id: "/api/auth/login",
				pattern: /^\/api\/auth\/login\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/login/_server.ts.js'))
			},
			{
				id: "/api/auth/logout",
				pattern: /^\/api\/auth\/logout\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/logout/_server.ts.js'))
			},
			{
				id: "/api/auth/register",
				pattern: /^\/api\/auth\/register\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/register/_server.ts.js'))
			},
			{
				id: "/api/auth/settings",
				pattern: /^\/api\/auth\/settings\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/settings/_server.ts.js'))
			},
			{
				id: "/api/auth/verify",
				pattern: /^\/api\/auth\/verify\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/verify/_server.ts.js'))
			},
			{
				id: "/api/change-information/request",
				pattern: /^\/api\/change-information\/request\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/change-information/request/_server.ts.js'))
			},
			{
				id: "/api/change-vehicle/approve",
				pattern: /^\/api\/change-vehicle\/approve\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/change-vehicle/approve/_server.ts.js'))
			},
			{
				id: "/api/change-vehicle/request",
				pattern: /^\/api\/change-vehicle\/request\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/change-vehicle/request/_server.ts.js'))
			},
			{
				id: "/api/complaints",
				pattern: /^\/api\/complaints\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/complaints/_server.ts.js'))
			},
			{
				id: "/api/complaints/[id]",
				pattern: /^\/api\/complaints\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/complaints/_id_/_server.ts.js'))
			},
			{
				id: "/api/deans",
				pattern: /^\/api\/deans\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/deans/_server.ts.js'))
			},
			{
				id: "/api/dean/applications",
				pattern: /^\/api\/dean\/applications\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/dean/applications/_server.ts.js'))
			},
			{
				id: "/api/departments",
				pattern: /^\/api\/departments\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/departments/_server.ts.js'))
			},
			{
				id: "/api/departments/admin",
				pattern: /^\/api\/departments\/admin\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/departments/admin/_server.ts.js'))
			},
			{
				id: "/api/gate/entry",
				pattern: /^\/api\/gate\/entry\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/entry/_server.ts.js'))
			},
			{
				id: "/api/gate/exit",
				pattern: /^\/api\/gate\/exit\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/exit/_server.ts.js'))
			},
			{
				id: "/api/gate/logs",
				pattern: /^\/api\/gate\/logs\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/logs/_server.ts.js'))
			},
			{
				id: "/api/gate/lookup-plate",
				pattern: /^\/api\/gate\/lookup-plate\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/lookup-plate/_server.ts.js'))
			},
			{
				id: "/api/gate/lookup",
				pattern: /^\/api\/gate\/lookup\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/lookup/_server.ts.js'))
			},
			{
				id: "/api/gate/manual",
				pattern: /^\/api\/gate\/manual\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/manual/_server.ts.js'))
			},
			{
				id: "/api/gate/parking",
				pattern: /^\/api\/gate\/parking\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/parking/_server.ts.js'))
			},
			{
				id: "/api/gate/stats",
				pattern: /^\/api\/gate\/stats\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/stats/_server.ts.js'))
			},
			{
				id: "/api/gate/vip",
				pattern: /^\/api\/gate\/vip\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/gate/vip/_server.ts.js'))
			},
			{
				id: "/api/monitor/actions",
				pattern: /^\/api\/monitor\/actions\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/monitor/actions/_server.ts.js'))
			},
			{
				id: "/api/monitor/revoke",
				pattern: /^\/api\/monitor\/revoke\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/monitor/revoke/_server.ts.js'))
			},
			{
				id: "/api/notifications",
				pattern: /^\/api\/notifications\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/notifications/_server.ts.js'))
			},
			{
				id: "/api/notifications/create",
				pattern: /^\/api\/notifications\/create\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/notifications/create/_server.ts.js'))
			},
			{
				id: "/api/notifications/mark-all-read",
				pattern: /^\/api\/notifications\/mark-all-read\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/notifications/mark-all-read/_server.ts.js'))
			},
			{
				id: "/api/notifications/[notificationId]/read",
				pattern: /^\/api\/notifications\/([^/]+?)\/read\/?$/,
				params: [{"name":"notificationId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/notifications/_notificationId_/read/_server.ts.js'))
			},
			{
				id: "/api/osa/admin",
				pattern: /^\/api\/osa\/admin\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/osa/admin/_server.ts.js'))
			},
			{
				id: "/api/osa/application-form",
				pattern: /^\/api\/osa\/application-form\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/osa/application-form/_server.ts.js'))
			},
			{
				id: "/api/osa/applications",
				pattern: /^\/api\/osa\/applications\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/osa/applications/_server.ts.js'))
			},
			{
				id: "/api/osa/bulk-actions",
				pattern: /^\/api\/osa\/bulk-actions\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/osa/bulk-actions/_server.ts.js'))
			},
			{
				id: "/api/qr",
				pattern: /^\/api\/qr\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/qr/_server.ts.js'))
			},
			{
				id: "/api/security/capacity",
				pattern: /^\/api\/security\/capacity\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/security/capacity/_server.ts.js'))
			},
			{
				id: "/api/security/complaints",
				pattern: /^\/api\/security\/complaints\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/security/complaints/_server.ts.js'))
			},
			{
				id: "/api/security/complaints/[id]",
				pattern: /^\/api\/security\/complaints\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/security/complaints/_id_/_server.ts.js'))
			},
			{
				id: "/api/security/sticker-install",
				pattern: /^\/api\/security\/sticker-install\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/security/sticker-install/_server.ts.js'))
			},
			{
				id: "/api/settings",
				pattern: /^\/api\/settings\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/settings/_server.ts.js'))
			},
			{
				id: "/api/settings/gate-filter",
				pattern: /^\/api\/settings\/gate-filter\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/settings/gate-filter/_server.ts.js'))
			},
			{
				id: "/api/settings/registration",
				pattern: /^\/api\/settings\/registration\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/settings/registration/_server.ts.js'))
			},
			{
				id: "/complaints",
				pattern: /^\/complaints\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/dean",
				pattern: /^\/dean\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/dean/settings",
				pattern: /^\/dean\/settings\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/entry",
				pattern: /^\/entry\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/monitor",
				pattern: /^\/monitor\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/osa",
				pattern: /^\/osa\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/osa/admin",
				pattern: /^\/osa\/admin\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/osa/admin/manage",
				pattern: /^\/osa\/admin\/manage\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/osa/change-requests",
				pattern: /^\/osa\/change-requests\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/osa/dashboard",
				pattern: /^\/osa\/dashboard\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/osa/deans",
				pattern: /^\/osa\/deans\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/osa/departments",
				pattern: /^\/osa\/departments\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/osa/settings",
				pattern: /^\/osa\/settings\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/otp",
				pattern: /^\/otp\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 20 },
				endpoint: null
			},
			{
				id: "/security",
				pattern: /^\/security\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/security/capacity",
				pattern: /^\/security\/capacity\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/security/complaints",
				pattern: /^\/security\/complaints\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/security/dashboard",
				pattern: /^\/security\/dashboard\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/security/logs",
				pattern: /^\/security\/logs\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/security/settings",
				pattern: /^\/security\/settings\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/status",
				pattern: /^\/status\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 27 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
